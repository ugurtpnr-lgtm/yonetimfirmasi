<template>
  <div class="header-component-container">
    <headerDiv>
      <div v-if="$route.name === 'iletisim'
                  || $route.name === 'firma-girisi'
                  || $route.name === 'teklif-al-basarili'
                  || $route.name === 'firma-firsatlar-ve-teklifler'
                  || $route.name === 'firma-bilgileri-duzenle'
                  || $route.name === 'firma-bakiye-yukle-havale'
                  || $route.name === 'firma-bakiye-yukle-kredi-karti'"
           class="page-6-header">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <NuxtLink to="/" class="navbar-brand">
                  <h4><span>Yönetim</span> Firması</h4>
                </NuxtLink>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarText">
                    <ul class="navbar-nav ml-auto">
                        <li v-if="!$store.state.isLoggedIn" class="nav-item  ">
                            <NuxtLink class="nav-link nav-item-blue" to="/firma-girisi">
                              <img src="/images/icons/acount-icon.png" alt="account-icon" class="image-fluid ">
                              YÖNETİM FİRMASIYIM
                            </NuxtLink>
                        </li>
                        <li v-else class="nav-item  ">
                              <NuxtLink
                                class="nav-link nav-item-blue"
                                to="/cikis-yap"
                                v-if="$route.name === 'firma-firsatlar-ve-teklifler' ||
                                        $route.name === 'firma-bilgileri-duzenle'"
                              >
                                ÇIKIŞ YAP
                              </NuxtLink>
                              <NuxtLink
                                class="nav-link nav-item-blue"
                                to="/firma/firsatlar-ve-teklifler"
                                v-else
                              >
                                FİRMA PANELİ
                              </NuxtLink>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link nav-item-grey" href="https://yonetimfirmasi.com/blog">BLOG</a>
                        </li>

                        <li class="nav-item ">
                            <NuxtLink to="/iletisim" class="nav-link">İLETİŞİM</NuxtLink>
                        </li>
                        <li
                          class="nav-item"
                          v-if="$route.name !== 'firma-firsatlar-ve-teklifler' && $route.name !== 'firma-bilgileri-duzenle'"
                        >
                            <NuxtLink class="btn nav-link nav-item-blue" to="/teklif-al/asama-1">HEMEN TEKLİF AL</NuxtLink>
                        </li>


                    </ul>

                </div>
            </nav>
            </div>
      </div>
      <div v-else>
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
              <NuxtLink to="/" class="navbar-brand">
                <h4><span>Yönetim</span> Firması</h4>
              </NuxtLink>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarText">
                    <ul class="navbar-nav ml-auto">
                        <li v-if="!$store.state.isLoggedIn" class="nav-item  ">
                            <NuxtLink class="nav-link nav-item-blue" to="/firma-girisi">
                              <img src="/images/icons/acount-icon.png" alt="account-icon" class="image-fluid ">
                              YÖNETİM FİRMASIYIM
                            </NuxtLink>
                        </li>
                        <li v-else class="nav-item  ">
                              <NuxtLink
                                class="nav-link nav-item-blue"
                                to="/cikis-yap"
                                v-if="$route.name === 'firma-firsatlar-ve-teklifler' ||
                                        $route.name === 'firma-bilgileri-duzenle'"
                              >
                                ÇIKIŞ YAP
                              </NuxtLink>
                              <NuxtLink
                                class="nav-link nav-item-blue"
                                to="/firma/firsatlar-ve-teklifler"
                                v-else
                              >
                                FİRMA PANELİ
                              </NuxtLink>
                        </li>

                        <li class="nav-item ">
                            <a class="nav-link" href="https://yonetimfirmasi.com/blog">BLOG </a>
                        </li>
                        <li class="nav-item ">
                            <NuxtLink to="/iletisim" class="nav-link">İLETİŞİM</NuxtLink>
                        </li>
                        <li
                          class="nav-item"
                          v-if="$route.name !== 'firma-firsatlar-ve-teklifler' && $route.name !== 'firma-bilgileri-duzenle'"
                        >
                            <NuxtLink class="btn nav-link nav-item-blue" to="/teklif-al/asama-1">HEMEN TEKLİF AL</NuxtLink>
                        </li>


                    </ul>

                </div>
            </nav>
            </div>
      </div>
    </headerDiv>
  </div>
</template>

<script>
export default {
  name: 'MbHeaderComponent',

  data() {
    return {
      classes: {
        headerWrapperDiv: ''
      }
    }
  },

  mounted() {
    let _this = this
  },

  methods: {
    checkRoute() {
      if(this.$route.name === 'iletisim') {
        this.classes.headerWrapperDiv = 'page-6-header'
      }
    }
  }
}
</script>
