<template>
  <div>
    <masked-input
      v-model="inputValue"
      class="form-control"
      type="text"
      placeholder="(5xx) xxx xx xx"
      mask="(111) 111 11 11"
    />
  </div>
</template>

<script>

export default {
  name: 'maskedInputComponent',

  data() {
    return {
      inputValue: ''
    }
  },

  watch: {
    inputValue: function(val) {
      this.$emit('input', val)
    }
  }
}
</script>
