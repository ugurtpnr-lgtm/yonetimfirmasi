<template>
  <div class="footer-component-container">
    <footerDiv>
      <div class="card-logos d-flex flex-row-reverse container mb-4">
        <img alt="card payment logos" class="cc-logos" src="/images/icons/cc-logos.svg" />
      </div>
      <div class="container d-flex">
        <ul class="d-flex footer-icons">
          <li>
            <a target="_blank" href="https://www.facebook.com/yonetimfirmasi/?ti=as">
              <img src="/images/icons/icon-fb.png" alt="fb-icon" class="img-fluid">
            </a>
          </li>
          <li>
            <a target="_blank" href="https://twitter.com/YonetimFirmasi">
              <img src="/images/icons/icon-twitter.png" alt="twitter-icon" class="img-fluid">
            </a>
          </li>
          <li>
            <a target="_blank" href="https://instagram.com/yonetimfirmasi?utm_medium=copy_link">
              <img src="/images/icons/icon-insta.png" alt="insta-icon" class="img-fluid">
            </a>
          </li>
        </ul>
        <ul class="footer-text-links ml-auto d-md-flex">
          <li><a href="https://yonetimfirmasi.com/blog">Blog</a> </li>
          <li> <NuxtLink to="/kisisel-verilerin-korunmasi">KVKK</NuxtLink> </li>
          <li> <NuxtLink to="/mesafeli-satis-sozlesmesi">Mesafeli Satış Sözleşmesi</NuxtLink> </li>
          <li> <NuxtLink to="/teslimat-ve-iade-sartlari">İade Şartları</NuxtLink> </li>
          <li> <NuxtLink to="/hakkimizda">Hakkımızda</NuxtLink> </li>
          <li> <NuxtLink to="/iletisim">İletişim</NuxtLink> </li>
        </ul>
      </div>
      <div v-if="!isMobilViewState" class="footer-bottom d-flex">
        <p>YonetimFirmasi.com 2021. All Rights Reserved</p>
        <img src="/images/icons/copyright-icon.png" alt="copyright-icon" class="img-fluid">
        <p>&nbsp;| Developed by ArjinTech</p>
      </div>
      <div v-else class="footer-bottom">
        <p>YonetimFirmasi.com 2021. All Rights Reserved</p>
        <p><img src="/images/icons/copyright-icon.png" alt="copyright-icon" class="img-fluid">&nbsp;| Developed by ArjinTech</p>
      </div>
    </footerDiv>
    <script type="text/javascript" src="/js/jquery-3.2.1.slim.min.js"></script>
    <script type="text/javascript" src="/js/jquery.min.js"></script>
    <script type="text/javascript" src="/js/popper.min.js"></script>
    <script type="text/javascript" src="/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="/js/swiper-bundle.min.js"></script>
    <script type="text/javascript" src="/js/custom.js"></script>
  </div>
</template>

<script>
export default {
  name: 'MbFooterComponent',

  data() {
    return {
      isMobilViewState: false
    }
  },

  mounted() {
    this.isMobilView()
  },

  methods: {
    isMobilView() {
      this.isMobilViewState = window.screen.width <= 768
    }
  }
}
</script>

<style>
.cc-logos {
  width: 250px;
}
</style>
