import { createStore } from "vuex"

const store = createStore({
   state: {
      apiBaseUrl: 'https://api.yonetimfirmasi.com/api',
      appName: 'YonetimFirmasi Admin Panel',
      userData: {
         userName: null,
         userID: null,
         isAdmin: false,
         accessToken: '',
         encryptedAccessToken: '',
         expireInSeconds: 0,
         authTimeStamp: 0,
         info: {},
      },
      logoutRequest: false,
   },

   mutations: {
      setUserData(state, payload) {
         localStorage.yfDashboardUserAccessToken = payload.accessToken
         localStorage.yfDashboardUserEncryptedAccessToken = payload.encryptedAccessToken
         state.userData = payload
      },

      setLogoutRequest(state, payload) {
         state.logoutRequest = true
         setTimeout(() => {
            state.logoutRequest = false
         }, 200)
      },
   },

   getters: {
    getLogoutRequest: state => state.logoutRequest
   }
})

export default store
