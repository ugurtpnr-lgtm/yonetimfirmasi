<template>
  <div></div>
</template>

<script>
export default {
  mounted() {
    localStorage.yfDashboardUserID = ''
    localStorage.yfDashboardAccessToken = ''
    localStorage.yfDashboardRefreshToken = ''
    localStorage.yfDashboardExpiresInSeconds = ''
    localStorage.yfDashboardRoleID = ''
    localStorage.yfDashboardAuthenticationInformationId = ''

    this.$store.commit('setLogoutRequest', true)
    window.location.href = window.location.href.split('logout')[0]
  }
}
</script>
