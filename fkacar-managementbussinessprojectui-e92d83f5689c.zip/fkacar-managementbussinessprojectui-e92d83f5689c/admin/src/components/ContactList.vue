<template>
  <div id="single-user-stats-container">
    <div class="row">
      <div class="col-md-12">
        <el-card>
          <template #header>
            <div class="card-header">
              <h4>İletişim Formu Listesi</h4>
            </div>
          </template>
          <div class="row pb-3">
            <div class="col-sm-9 pb-3 pl-4">
              <!--<strong class="text-muted">Filtering: {{ filterModel.filterText }} ({{ tableData.length }} records)</strong>-->
            </div>
            <div class="col-sm-1 text-right">
              <!--<el-button
                  icon="el-icon-sort"
                  type="primary"
                  size="small"
                  @click="filterTable"
              >
                Filter
              </el-button>-->
            </div>
          </div>
          <el-table
            :data="tableData"
            border
            height="500"
            style="width: 100%"
            :default-sort = "{prop: 'date', order: 'descending'}"
            v-loading="isTableDataLoading"
          >
            <el-table-column type="expand">
              <template #default="props">
                <p>Mesaj: {{ props.row.messageContent }}</p>
              </template>
            </el-table-column>
            <el-table-column
              label="#"
              width="50">
              <template #default="scope">
                {{ scope.$index + 1 }}
              </template>
            </el-table-column>
            <el-table-column
              prop="creationTime"
              label="Tarih"
              sortable
            >
            </el-table-column>
            <el-table-column
              prop="nameSurname"
              label="Ad Soyad"
              sortable
            >
            </el-table-column>
            <el-table-column
              label="E-Posta Adresi"
              sortable
            >
              <template #default="scope">
                <a :href="`mailto:${scope.row.email}`" >
                  {{ scope.row.email }}
                </a>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </div>
    </div>
    <!-- dialogs -->
    <!-- dialogs end -->
  </div>
</template>

<script>
import dateFormat from 'dateformat'
import axios from "axios";

export default {
  name: 'UsersUnApprovedPage',

  data() {
    return {
      tableData: [],
      isTableDataLoading: false,
      showFilterTableDialog: false,
      showReviewDialog: false,
      isUserAdmin: false,
    }
  },

  mounted() {
    this.generateTableData()
  },

  methods: {
    async getContactList() {
      let _this = this
      this.isTableDataLoading = true

      return await axios.get(this.$store.state.apiBaseUrl + '/Contact/GetList', {
          headers: {
            Authorization: 'Bearer ' + this.$store.state.userData.accessToken,
          }
        })
        .then(res => {
          _this.isTableDataLoading = false

          return res.data.data.map(contact => {
              return {
                contactID: contact.id,
                email: contact.email,
                nameSurname: contact.nameSurname,
                messageContent: contact.messageContent,
                creationTime: dateFormat(contact.creationTime, "yyyy/mm/dd"),
                creationTimeUnformatted: contact.creationTime
              }
            })
        })
        .catch(err => {
          console.error(err)
          _this.isTableDataLoading = false
          return []
        })
    },

    async generateTableData() {
      const data = await this.getContactList()
      data.sort((a,b) => new Date(b.creationTimeUnformatted) - new Date(a.creationTimeUnformatted))
      this.tableData = data
    },
  }
}
</script>
