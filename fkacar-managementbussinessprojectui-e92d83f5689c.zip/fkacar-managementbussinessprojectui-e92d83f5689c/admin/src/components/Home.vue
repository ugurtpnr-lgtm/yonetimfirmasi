<template>
  <div style="padding:0" v-loading="isLoading" class="container-fluid" id="home-container">
    <transition name="fade">
      <login @onLogin="onLogin" v-if="!isLoggedIn" />
    </transition>
    <transition name="fade">
      <dashboard v-if="showDashboard" />
    </transition>
  </div>
</template>

<script>
import Login from './Login.vue'
import Dashboard from './Dashboard.vue'
import axios from "axios";

export default {
  name: 'Home',
  components: {
    Login,
    Dashboard,
  },

  data() {
    return {
      isLoggedIn: false,
      showDashboard: false,
      isLoading: false,
    }
  },

  async mounted() {
    if(localStorage.yfDashboardAccessToken) {
      this.isLoading = true

      await this.getCurrentUserInfo(localStorage.yfDashboardUserID,
        localStorage.yfDashboardAccessToken,
        localStorage.yfDashboardRefreshToken,
        localStorage.yfDashboardExpiresInSeconds,
        localStorage.yfDashboardRoleID
      )

      this.checkIsLoggedIn()
    }
  },

  methods: {
    checkIsLoggedIn() {
      let _this = this
      if(this.$store.state.userData.userID) {
        this.isLoggedIn = true
        setTimeout(() => {
          _this.showDashboard = true
        }, 2000)
        this.isLoading = false
        return
      }

      this.isLoggedIn = false
      this.isLoading = false
    },

    onLogin() {
      this.checkIsLoggedIn()
    },

    async getCurrentUserInfo(userID, accessToken, refreshToken, expires, roleID) {
      let _this = this
      return await axios.get(this.$store.state.apiBaseUrl + '/User/Get?UserId=' + userID, {
          headers: {
            Authorization: 'Bearer ' + accessToken,
          }
        })
        .then((res) => {
          _this.$store.commit('setUserData', {
              auth: true,
              accessToken: accessToken,
              refreshToken: refreshToken,
              encryptedAccessToken: accessToken,
              expireInSeconds: expires,
              userID: userID,
              authTimeStamp: Math.floor(Date.now() / 1000),
              roleId: roleID,
              info: res.data.data,
          })

          return res.data.data
        })
        .catch((err) => {
          console.error(err)
          return false
        })
    }
  }
}
</script>

<style>
body {
  background: whitesmoke;
}

.fade-enter-active, .fade-leave-active {
  transition: opacity 1s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}

.card-header {
  background-color: transparent !important;
  padding: 0 !important;
  border-bottom: none !important;
}

.el-button--primary {
  color: #fff !important;
  background-color: #409eff !important;
  border-color: #409eff !important;
}

.el-button--primary:focus, .el-button--primary:hover {
    background: #66b1ff !important;
    border-color: #66b1ff !important;
    color: #fff !important;
}
</style>
