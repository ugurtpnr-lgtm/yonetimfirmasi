<template>
  <div id="dashboard-home-container">
    <div style="display:none" id="webcam"></div>
    <div class="row">
      <div class="col-md-6 mt-4">
        <el-card>
          <template #header>
            <div class="card-header">
              <h5>Sunucu</h5>
            </div>
          </template>
          <div class="text-center" style="width:100%;padding:14%">
            <h1 style="color:#00c90a">Aktif</h1>
          </div>
        </el-card>
      </div>
      <div class="col-md-6 mt-4">
        <el-card>
          <template #header>
            <div class="card-header">
              <h5>Toplam Kayıtlı Firma</h5>
            </div>
          </template>
          <div class="text-center" style="width:100%;padding:14%">
            <h1>{{ stats.companyCount }}</h1>
          </div>
        </el-card>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import dateFormat from 'dateformat'

export default {
  name: 'DashboardHome',

  data() {
    return {
      stats: {
        companyCount: '?',
      },
    }
  },

  mounted() {
    this.checkLogin()
    this.getStats()
  },

  methods: {
    checkLogin() {
      let _this = this
      console.log('userData', this.$store.state.userData)
      axios
        .get(
          this.$store.state.apiBaseUrl +
          "/User/Get?UserId=" + this.$store.state.userData.info.userId,
          {
            headers: {
              Authorization:
                "Bearer " + this.$store.state.userData.accessToken,
            },
          }
        )
        .then((res) => {
          console.log(res)
        })
        .catch((err) => {
          if(err) {
            console.log('Auth error: ' + err)
            _this.$router.push({
              path: "/login",
            })
          }
        })
    },

    getStats() {
      let _this = this

      axios
        .get(
          this.$store.state.apiBaseUrl +
          "/Account/GetCompanyCount",
          {
            headers: {
              Authorization:
                "Bearer " + this.$store.state.userData.accessToken,
            },
          }
        )
        .then(res => {
          _this.stats.companyCount = res.data
        })
        .catch(err => {
          console.log(err)
        })
    }
  }
}
</script>
