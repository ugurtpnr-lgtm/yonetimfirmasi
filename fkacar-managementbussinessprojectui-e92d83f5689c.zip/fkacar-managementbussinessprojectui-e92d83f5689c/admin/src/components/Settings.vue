<template>
  <div id="dashboard-home-container">
    <div style="display:none" id="webcam"></div>
    <div class="row">
      <div class="col-md-12 mt-4">
        <el-card>
          <template #header>
            <div class="card-header">
              <h5>Şifre Değiştir</h5>
            </div>
          </template>
          <div class="text-center" style="width:100%">
            <div class="row">
              <div class="col-md-4 offset-md-4">
                <div class="form-group">
                  <label>Yeni Şifre</label>
                  <el-input placeholder="Yeni şifreniz..." v-model="password"></el-input>
                </div>
                <div class="form-group">
                  <label>Şifre (Tekrar)</label>
                  <el-input placeholder="Şifrenizi yeniden giriniz..." v-model="rePassword"></el-input>
                </div>
                <div class="form-group mt-4">
                   <el-button @click="updatePassword" type="primary" icon="el-icon-refresh">Güncelle</el-button>
                </div>
              </div>
            </div>
          </div>
        </el-card>
      </div>
      <div class="col-md-12 mt-3">
        <el-card>
          <template #header>
            <div class="card-header">
              <h5>Teklif Fiyatı</h5>
            </div>
          </template>
          <div class="text-center" style="width:100%">
            <div class="row">
              <div class="col-md-4 offset-md-4">
                <div class="form-group">
                  <label>Güncel Fiyat (TL)</label>
                  <el-input placeholder="Güncel fiyat" v-model="currentPrice" disabled="true" />
                </div>
                <div class="form-group">
                  <label>Yeni Fiyat (TL)</label>
                  <el-input-number style="width: 100%" v-model="newPrice" :min="1" :max="9999999"></el-input-number>
                </div>
                <div class="form-group mt-4">
                  <el-button @click="updatePrice" type="primary" icon="el-icon-refresh">Fiyatı Güncelle</el-button>
                </div>
              </div>
            </div>
          </div>
        </el-card>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import dateFormat from 'dateformat'

export default {
  name: 'Settings',

  data() {
    return {
      password: '',
      rePassword: '',
      currentPrice: '',
      newPrice: 1,
      stats: {
        visitors: '?',
        images: '?'
      },
    }
  },

  mounted() {
    this.getStats()
    this.getPrice()
  },

  methods: {
    getStats() {
      let _this = this
      console.log('userData', this.$store.state.userData)
      axios
        .get(
          this.$store.state.apiBaseUrl +
          "/User/Get?UserId=" + this.$store.state.userData.info.userId,
          {
            headers: {
              Authorization:
                "Bearer " + this.$store.state.userData.accessToken,
            },
          }
        )
        .then((res) => {
          console.log(res)
        })
        .catch((err) => {
          if(err) {
            console.log('Auth error: ' + err)
            _this.$router.push({
              path: "/login",
            })
          }
        })
    },

    getPrice() {
      let _this = this

      axios
        .get(this.$store.state.apiBaseUrl + '/PriceInformation/Get?id=1', {
          headers: {
            Authorization: "Bearer " + this.$store.state.userData.accessToken,
          },
        })
        .then(res => {
          _this.currentPrice = res.data.data.price
        })
    },

    updatePassword() {
      let _this = this;

      if (this.password !== this.rePassword) {
        this.$message({
            type: 'error',
            message: 'HATA: Şifreler birbiriyle eşleşmiyor!'
          })
        return;
      }

      axios
        .post(
          this.$store.state.apiBaseUrl + "/Account/UpdatePasswordEmail",
          {
            authenticationInformationId:
              localStorage.yfDashboardAuthenticationInformationId,
            password: this.password,
          },
          {
            headers: {
              Authorization: "Bearer " + this.$store.state.userData.accessToken,
            },
          }
        )
        .then((res) => {
          _this.$message({
            type: 'success',
            message: 'Şifre güncellendi.'
          })
        })
        .catch((err) => {
          _this.$message({
            type: 'error',
            message: 'HATA: Beklenmedik bir hata meydana geldi!'
          })
        });
    },

    updatePrice() {
      let _this = this

      axios
          .post(this.$store.state.apiBaseUrl + '/PriceInformation/Update', {
            id: 1,
            currencyCodeId: 1,
            price: this.newPrice,
            isActive: true
          }, {
            headers: {
              Authorization: "Bearer " + this.$store.state.userData.accessToken,
            },
          })
          .then(res => {
            _this.$message({
              type: 'success',
              message: 'Fiyat güncellendi.'
            })
          })
          .catch(err => {
            _this.$message({
              type: 'error',
              message: 'HATA: Beklenmedik bir hata meydana geldi!'
            })
          })
    }
  }
}
</script>
