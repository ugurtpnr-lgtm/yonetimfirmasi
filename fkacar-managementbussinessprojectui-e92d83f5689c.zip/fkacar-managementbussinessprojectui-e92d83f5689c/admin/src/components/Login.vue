<template>
  <div class="login-container">
    <div class="row">
      <div class="col-md-4"></div>
      <div style="margin-left:4.5%" class="col-md-3 text-center">
        <div class="card text-left mt-5">
          <div class="card-body">
            <div class="form-group">
              <label>E-Posta</label>
              <el-input
                  placeholder="E-Posta..."
                  v-model="userName"
                  clearable
              />
            </div>
            <div class="form-group">
              <label>Şifre</label>
              <el-input
                  placeholder="Şifre..."
                  v-model="password"
                  clearable
                  show-password
              />
            </div>
            <el-button
                @click="logIn"
                type="success"
                class="mt-4"
                round
                :loading="isLoading"
                style="width:100%"
            >
              GİRİŞ YAP
            </el-button>
          </div>
        </div>
      </div>
       <div class="col-md-4"></div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Login',
  data() {
    return {
      userName: '',
      password: '',
      isLoading: false
    }
  },

  mounted() {
    document.addEventListener('keyup', this.keyUpListener)
  },

  methods: {
    keyUpListener(e) {
      if(e.code === 'Enter') {
        this.logIn()
      }
    },

    async logIn() {
      this.isLoading = true
      let userData = await this.authenticateUser()
      this.isLoading = false

      if(userData.auth) {
        this.$store.commit('setUserData', userData)
        localStorage.yfDashboardUserID = userData.userID
        localStorage.yfDashboardAccessToken = userData.accessToken
        localStorage.yfDashboardRefreshToken = userData.refreshToken
        localStorage.yfDashboardExpiresInSeconds = userData.expireInSeconds
        localStorage.yfDashboardRoleID = userData.roleId
        localStorage.yfDashboardAuthenticationInformationId = userData.authenticationInformationId

        this.$emit('onLogin', true)
        document.removeEventListener('keyup', this.keyUpListener)
        return
      }

      this.$message({
            type: 'error',
            message: 'Giriş başarısız!'
          })
    },

    async authenticateUser() {
      let _this = this
      let userData = {
        auth: false,
        accessToken: '',
        encryptedAccessToken: '',
        expireInSeconds: 0,
        userId: 0,
        timeStamp: 0,
      }

      await axios.post(this.$store.state.apiBaseUrl + '/Account/SignIn', {
        email: this.userName,
        password: this.password,
      })
      .then(async (res) => {
        console.log(res)
        userData.auth = true
        userData.accessToken = res.data.token
        userData.refreshToken = res.data.refreshToken
        userData.encryptedAccessToken = res.data.token
        userData.expireInSeconds = res.data.expiration
        userData.userID = res.data.userId
        userData.authTimeStamp = Math.floor(Date.now() / 1000)
        userData.roleId = res.data.roleId
        userData.authenticationInformationId = res.data.authenticationInformationId

        const userInfo = await _this.getCurrentUserInfo(userData.accessToken, userData.userID)
        userData.isAdmin = userData.roleId === '00000000-0000-0000-0000-000000000001'

        if(!userData.isAdmin) userData.auth = false

        userData.info = userInfo
      })
      .catch((err) => {
        userData.auth = false
        console.error(err);
      });

      return userData
    },

    async getCurrentUserInfo(accessToken, userID) {
      return await axios.get(this.$store.state.apiBaseUrl + '/User/Get?UserId=' + userID, {
          headers: {
            Authorization: 'Bearer ' + accessToken,
          }
        })
        .then((res) => {
          return res.data.data
        })
        .catch((err) => {
          console.error(err)
          return false
        })
    }
  }
}
</script>

<style scoped>

</style>
