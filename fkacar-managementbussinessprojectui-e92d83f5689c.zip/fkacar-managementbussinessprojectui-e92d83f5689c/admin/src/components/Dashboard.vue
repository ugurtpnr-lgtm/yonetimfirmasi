<template>
  <div id="dashboard-container">
    <div class="row" style="margin-right: 0">
      <div style="padding-right:0" class="col-md-2">
        <el-menu
            default-active="1"
            class="el-menu-vertical"
            background-color="#545c64"
            text-color="#fff"
            style="height:120vh"
            active-text-color="#ffd04b"
            @select="onSelectMenu"
        >
          <el-menu-item index="1">
            <i class="el-icon-menu"></i>
            <span>Panel</span>
          </el-menu-item>
          <el-menu-item index="2">
            <i class="el-icon-s-data"></i>
            <span>Onay Bekleyen Firmalar</span>
          </el-menu-item>
          <el-menu-item index="3">
            <i class="el-icon-s-data"></i>
            <span>Onaylanmış Firmalar</span>
          </el-menu-item>
          <el-menu-item index="4">
            <i class="el-icon-s-data"></i>
            <span>Teklifler</span>
          </el-menu-item>
          <el-menu-item index="5">
            <i class="el-icon-s-data"></i>
            <span>İletişim Formu Listesi</span>
          </el-menu-item>
          <el-menu-item index="6">
            <i class="el-icon-s-tools"></i>
            <span>Ayarlar</span>
          </el-menu-item>
          <el-menu-item index="7">
            <i class="el-icon-switch-button"></i>
            <span>Çıkış Yap</span>
          </el-menu-item>
        </el-menu>
      </div>
      <div style="padding-left:0" class="col-md-10">
        <div class="card text-left">
          <div style="height:120vh" class="card-body">
            <router-view />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Dashboard',
  data() {
    return {
      isUserAdmin: false,
      menuItems: [
        {
          index: '1',
          component: '/admin'
        },
          {
          index: '2',
          component: '/admin/users-unapproved'
        },
          {
          index: '3',
          component: '/admin/users-approved'
        },
        {
          index: '4',
          component: '/admin/offers'
        },
          {
          index: '5',
          component: '/admin/contact-list'
        },
        {
          index: '6',
          component: '/admin/settings'
        },
          {
          index: '7',
          component: '/admin/logout'
        }
      ]
    }
  },

  mounted() {
    this.isUserAdmin = this.$store.state.userData.isAdmin
  },

  methods: {
    onSelectMenu(index) {
      const component = this.menuItems.find(item => item.index === index).component
      this.$router.push(component)
    }
  }
}
</script>
