<template>
  <div id="single-user-stats-container">
    <div class="row">
      <div class="col-md-12">
        <el-card>
          <template #header>
            <div class="card-header">
              <h4>Onay Bekleyen Firmalar</h4>
            </div>
          </template>
          <div class="row pb-3">
            <div class="col-sm-9 pb-3 pl-4">
              <!--<strong class="text-muted">Filtering: {{ filterModel.filterText }} ({{ tableData.length }} records)</strong>-->
            </div>
            <div class="col-sm-1 text-right">
              <!--<el-button
                  icon="el-icon-sort"
                  type="primary"
                  size="small"
                  @click="filterTable"
              >
                Filter
              </el-button>-->
            </div>
          </div>
          <el-table
            :data="tableData"
            border
            height="500"
            style="width: 100%"
            :default-sort = "{prop: 'date', order: 'descending'}"
            v-loading="isTableDataLoading"
          >
            <el-table-column type="expand">
              <template #default="props">
                <p>Yetkili İsim: {{ props.row.name }}</p>
                <p>Yetkili E-Posta: {{ props.row.email }}</p>
                <p>Yetkili Telefon: {{ props.row.phoneNumber }}</p>
                <p>Vergi Numarası: {{ props.row.taxNumber }}</p>
              </template>
            </el-table-column>
            <el-table-column
              label="#"
              width="50">
              <template #default="scope">
                {{ scope.$index + 1 }}
              </template>
            </el-table-column>
            <el-table-column
              prop="creationTime"
              label="Kayıt Tarihi"
              sortable
            >
            </el-table-column>
            <el-table-column
              prop="companyName"
              label="Firma Adı"
              sortable
            >
            </el-table-column>
            <el-table-column
              prop="taxAdministration"
              label="Vergi Dairesi"
              sortable
            >
            </el-table-column>
            <el-table-column
              prop="locations"
              label="Lokasyonlar"
              sortable
            >
            </el-table-column>
            <el-table-column
              label="Operations"
              width="100"
            >
              <template #default="scope">
                <!--<el-button
                  size="mini"
                  @click="onReview(scope.$index, scope.row)"
                >
                  İncele
                </el-button>-->
                <el-button
                  size="mini"
                  type="primary"
                  @click="onApprove(scope.$index, scope.row)"
                >
                  Onayla
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </div>
    </div>
    <!-- dialogs -->
    <el-dialog title="Filter" v-model="showFilterTableDialog">
      <div class="row">
        <div class="col-sm-8 offset-sm-2">
          <el-date-picker
            v-model="filterModel.timeRange"
            type="datetimerange"
            range-separator="-"
            start-placeholder="Start date"
            end-placeholder="End date"
            style="width: 100%"
          />
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showFilterTableDialog = false">Cancel</el-button>
        </span>
      </template>
    </el-dialog>
    <el-dialog title="Firma Bilgileri" v-model="showReviewDialog">
      <div class="row">
        <div class="col-sm-12">
          <div>
            <!-- -->
          </div>
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showReviewDialog = false">Cancel</el-button>
        </span>
      </template>
    </el-dialog>
    <!-- dialogs end -->
  </div>
</template>

<script>
import dateFormat from 'dateformat'
import axios from "axios";
import fileDownload from  'js-file-download'

export default {
  name: 'UsersUnApprovedPage',

  data() {
    return {
      tableData: [],
      isTableDataLoading: false,
      showFilterTableDialog: false,
      showReviewDialog: false,
      isUserAdmin: false,
      userSelectDataSource: [],
      filterModel: {
        timeRange: '',
        filterText: 'Last 100 visitors',
        userID: 'all',
      }
    }
  },

  mounted() {
    this.generateTableData()
  },

  watch: {
    'filterModel.timeRange': function (val) {
      this.filterModel.filterText = dateFormat(this.filterModel.timeRange[0], "yyyy/mm/dd HH:MM:ss")
      this.filterModel.filterText += ' - ' + dateFormat(this.filterModel.timeRange[1], "yyyy/mm/dd HH:MM:ss")
      this.showFilterTableDialog = false
      this.generateTableData()
    },

    'filterModel.userID': function(val) {
      this.generateTableData()
    }
  },

  methods: {
    async getCompanies() {
      let _this = this
      this.isTableDataLoading = true

      return await axios.post(this.$store.state.apiBaseUrl + '/User/Search', {
            isActive: false
          }, {
          headers: {
            Authorization: 'Bearer ' + this.$store.state.userData.accessToken,
          }
        })
        .then(res => {
          _this.isTableDataLoading = false

          return res.data.data.map(company => {
              return {
                userID: company.id,
                name: company.name + ' ' + company.surname,
                companyName: company.companyName,
                phoneNumber: company.phoneNumber,
                taxAdministrationId: company.taxAdministrationId,
                taxAdministration: '',
                taxNumber: company.taxNumber,
                isActive: company.isActive,
                cityIdList: company.cityIdList,
                locations: '',
                email: company.email,
                creationTime: dateFormat(company.creationTime, "yyyy/mm/dd"),
                creationTimeUnformatted: company.creationTime
              }
            })
        })
        .catch(err => {
          console.error(err)
          _this.isTableDataLoading = false
          return []
        })
    },

    async generateTableData() {
      const data = await this.getCompanies()
      data.sort((a,b) => new Date(b.creationTimeUnformatted) - new Date(a.creationTimeUnformatted))
      this.tableData = data
      await this.getTaxAdmin()
      await this.generateServiceLocations()
    },

    async getTaxAdmin() {
      let _this = this

      for(let i = 0; i < this.tableData.length; i++) {
        const company = this.tableData[i]

        if(!company.taxAdministrationId)
          continue

        await axios.get(this.$store.state.apiBaseUrl + '/TaxAdministration?id=' + company.taxAdministrationId )
          .then(res =>  {
            _this.tableData.find(item => item.userID === company.userID).taxAdministration = res.data.data.name
            return res.data.data.name
          })
      }
    },

    async generateServiceLocations() {
      let _this = this

      for(let i = 0; i < this.tableData.length; i++) {
        const company = this.tableData[i]
        let locationText = ``

        if(!company.cityIdList.length)
          continue

        for(let z = 0; z < company.cityIdList.length; z++) {
          const city = company.cityIdList[z]

          await axios.get(this.$store.state.apiBaseUrl + '/City?CityId=' + city)
            .then(res =>  {
              locationText += `${res.data.data.name}, `
              return res.data.data.name
            })
        }

        _this.tableData.find(item => item.userID === company.userID).locations = locationText.slice(0, -2)
      }
    },

    filterTable() {
      this.showFilterTableDialog = true
    },

    async onReview(rowIndex, row) {

    },

    onApprove(rowIndex, row) {
      let _this = this

      this.$confirm('Bu firmayı onaylamak istediğinize emin misiniz?', 'Uyarı', {
          confirmButtonText: 'Onayla',
          cancelButtonText: 'İptal',
          type: 'warning'
        }).then(() => {
          _this.approveCompany(row.userID)
          _this.tableData = _this.tableData.filter(user => user.userID !== row.userID)

          _this.$message({
            type: 'success',
            message: 'Firma onaylandı!'
          });
        }).catch(() => {
          _this.$message({
            type: 'info',
            message: 'Onaylama işlemi iptal edildi.'
          });
        });
    },

    approveCompany(userID) {
      axios.post(this.$store.state.apiBaseUrl + '/User/UserStatusUpdate', {
        userId: userID,
        status: true
      }, {
        headers: {
          Authorization: 'Bearer ' + this.$store.state.userData.accessToken,
        }
      })
       .then(res => console.log(res))
       .catch(err => console.log(err))
    }
  }
}
</script>
