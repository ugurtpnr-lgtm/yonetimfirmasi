<template>
  <div id="offers-container">
    <div class="row">
      <div class="col-md-12">
        <el-card>
          <template #header>
            <div class="card-header">
              <h4>Teklifler</h4>
            </div>
          </template>
          <div class="row pb-3">
            <div class="col-sm-9 pb-3 pl-4">
              <!--<strong class="text-muted">Filtering: {{ filterModel.filterText }} ({{ tableData.length }} records)</strong>-->
            </div>
            <div class="col-sm-1 text-right">
              <!--<el-button
                  icon="el-icon-sort"
                  type="primary"
                  size="small"
                  @click="filterTable"
              >
                Filter
              </el-button>-->
            </div>
          </div>
          <el-table
            :data="tableData"
            border
            height="500"
            style="width: 100%"
            :default-sort = "{prop: 'date', order: 'descending'}"
            v-loading="isTableDataLoading"
          >
            <el-table-column type="expand">
              <template #default="props">
                <p><b>Teklif Tipi:</b> {{ props.row.offerTypeId ===
                                "95299a76-4e07-4c62-8b1f-08d908f142de"
                                  ? "Apartman Yönetimi"
                                  : props.row.offerTypeId ===
                                    "19a5c618-8a66-46a7-8b20-08d908f142de"
                                  ? "Site Yönetimi"
                                  : props.row.offerTypeId ===
                                    "8beb1200-142e-4d80-8b21-08d908f142de"
                                  ? "İş Merkezi Yönetimi"
                                  : "" }}</p>
                <p>
                  <b>Hangi Hizmetler Gerekiyor:</b> <br>
                  <span
                    v-for="service in props.row.offerServiceTypes"
                    :key="service.id"
                    style="display: block;width: 100%;"
                    class="pl-4"
                  >
                    - {{ service.name }}
                  </span>
                </p>
                <p><b>Mahalle:</b> {{ props.row.neighborhoodName }}</p>
                <p><b>Cadde:</b> {{ props.row.mainStreetName }}</p>
                <p><b>Sokak:</b> {{ props.row.streetName }}</p>
                <p><b>Apartman / Site İsmi:</b> {{ props.row.apartmentName }}</p>
                <p><b>Blok Sayısı:</b> {{ props.row.blockNo }}</p>
                <p><b>Bağımsız Bölüm Sayısı:</b> {{ props.row.numberOfEpisod }}</p>
                <p><b>Çalışan Sayısı:</b> {{ props.row.numberOfPerson }}</p>
                <p><b>İletişim Tercihi:</b> {{ props.row.contactType === 1 ? "E-Posta" : "Telefon" }}</p>
                <p><b>E-Posta:</b> {{ props.row.email }}</p>
                <p><b>Telefon:</b> {{ props.row.telephone }}</p>
                <p><b>Müşteri Açıklaması:</b> {{ props.row.message }}</p>
                <br><br>
                <p>
                  <b>Verilen Teklifler:</b>
                  <br>
                  <span v-for="offer in props.row.userOffers"
                        :key="'offer_' + offer.userOfferId"
                        class="pb-2 pt-2 pl-4"
                        style="display: block;border-bottom: 1px solid #bcbcbc;"
                  >
                    <span><b>- Fiyat:</b> {{ offer.price }}</span><br>
                    <span><b>- Açıklama:</b> {{ offer.description }}</span><br>
                    <span><b>- Firma:</b> {{ offer.userName }}</span><br>
                  </span>
                </p>
              </template>
            </el-table-column>
            <el-table-column
              label="#"
              width="50">
              <template #default="scope">
                {{ scope.$index + 1 }}
              </template>
            </el-table-column>
            <el-table-column
              prop="creationTimeFormatted"
              label="Tarih"
              sortable
            >
            </el-table-column>
            <el-table-column
              prop="nameSurname"
              label="Müşteri İsmi"
              sortable
            >
            </el-table-column>
            <el-table-column
              prop="cityName"
              label="Şehir"
              sortable
            >
            </el-table-column>
            <el-table-column
              prop="townName"
              label="Semt / İlçe"
              sortable
            >
            </el-table-column>
            <el-table-column
              label="Verilen Teklif Sayısı"
            >
              <template #default="props">
                {{ props.row.userOffers.length }}
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </div>
    </div>
    <!-- dialogs -->
    <el-dialog title="Filter" v-model="showFilterTableDialog">
      <div class="row">
        <div class="col-sm-8 offset-sm-2">
          <el-date-picker
            v-model="filterModel.timeRange"
            type="datetimerange"
            range-separator="-"
            start-placeholder="Start date"
            end-placeholder="End date"
            style="width: 100%"
          />
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showFilterTableDialog = false">Cancel</el-button>
        </span>
      </template>
    </el-dialog>
    <el-dialog title="Firma Bilgileri" v-model="showReviewDialog">
      <div class="row">
        <div class="col-sm-12">
          <div>
            <!-- -->
          </div>
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showReviewDialog = false">Cancel</el-button>
        </span>
      </template>
    </el-dialog>
    <!-- dialogs end -->
  </div>
</template>

<script>
import dateFormat from 'dateformat'
import axios from "axios";
import fileDownload from  'js-file-download'

export default {
  name: 'UsersUnApprovedPage',

  data() {
    return {
      tableData: [],
      isTableDataLoading: false,
      showFilterTableDialog: false,
      showReviewDialog: false,
      isUserAdmin: false,
      userSelectDataSource: [],
      filterModel: {
        timeRange: '',
        filterText: 'Last 100 visitors',
        userID: 'all',
      }
    }
  },

  mounted() {
    this.generateTableData()
  },

  watch: {
    'filterModel.timeRange': function (val) {
      this.filterModel.filterText = dateFormat(this.filterModel.timeRange[0], "yyyy/mm/dd HH:MM:ss")
      this.filterModel.filterText += ' - ' + dateFormat(this.filterModel.timeRange[1], "yyyy/mm/dd HH:MM:ss")
      this.showFilterTableDialog = false
      this.generateTableData()
    },

    'filterModel.userID': function(val) {
      this.generateTableData()
    }
  },

  methods: {
    async getOffers() {
      let _this = this
      this.isTableDataLoading = true

      return await axios.post(this.$store.state.apiBaseUrl + '/UserOffer/UserOfferList', {}, {
          headers: {
            Authorization: 'Bearer ' + this.$store.state.userData.accessToken,
          }
        })
        .then(res => {
          _this.isTableDataLoading = false

          return res.data.data.map(company => {
              return {
                ...company,
                cityName: '',
                townName: '',
                neighborhoodName: '',
                creationTimeFormatted: dateFormat(company.creationTime, "yyyy/mm/dd"),
                creationTimeUnformatted: company.creationTime,
              }
            })
        })
        .catch(err => {
          console.error(err)
          _this.isTableDataLoading = false
          return []
        })
    },

    async generateTableData() {
      const data = await this.getOffers()
      data.sort((a,b) => new Date(b.creationTimeUnformatted) - new Date(a.creationTimeUnformatted))
      this.tableData = data
      this.getAddresses()
    },

    async getAddresses() {
      for (let i = 0; i < this.tableData.length; i++) {
        this.tableData[i].cityName = await this.getCity(this.tableData[i].cityId)
        this.tableData[i].neighborhoodName = await this.getNeighborhood(this.tableData[i].neighborhoodId)
        this.tableData[i].townName = await this.getTown(this.tableData[i].townId)
      }
    },

    getTown(townId) {
      return axios
        .get(this.$store.state.apiBaseUrl + "/Town?TownId=" + townId)
        .then((res) => {
          return res.data.data.name
        });
    },

    async getCity(cityId) {
      return await axios
        .get(this.$store.state.apiBaseUrl + "/City?CityId=" + cityId)
        .then((res) => {
          return res.data.data.name
        });
    },

    getNeighborhood(neighborhoodId) {
      return axios
        .get(
          this.$store.state.apiBaseUrl +
            "/Neighborhood?id=" +
            neighborhoodId
        )
        .then((res) => {
          return res.data.data.name
        });
    },

    filterTable() {
      this.showFilterTableDialog = true
    },
  }
}
</script>
