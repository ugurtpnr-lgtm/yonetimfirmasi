import { createWebHistory, createRouter } from "vue-router"
import DashboardHome from "./../components/DashboardHome.vue"
import UsersApproved from "./../components/UsersApproved"
import UsersUnApproved from "./../components/UsersUnApproved"
import Offers from "./../components/Offers"
import ContactList from "./../components/ContactList"
import Settings from "./../components/Settings.vue"
import Logout from "./../components/Logout.vue"

const routes = [
  {
    path: "/admin",
    name: "DashboardHome",
    component: DashboardHome,
  },
  {
    path: "/admin/users-approved",
    name: "UsersApproved",
    component: UsersApproved,
  },
  {
    path: "/admin/users-unapproved",
    name: "UsersUnApproved",
    component: UsersUnApproved,
  },
  {
    path: "/admin/contact-list",
    name: "ContactList",
    component: ContactList,
  },
  {
    path: "/admin/settings",
    name: "Settings",
    component: Settings,
  },
  {
    path: "/admin/offers",
    name: "Offers",
    component: Offers,
  },
    {
    path: "/admin/logout",
    name: "Logout",
    component: Logout,
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
