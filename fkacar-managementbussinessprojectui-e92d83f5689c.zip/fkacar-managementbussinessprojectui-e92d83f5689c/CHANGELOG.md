### makeOfferSubmit bugs fixed (HEAD -> master)
>Sat, 15 Jan 2022 09:32:45 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
components/shared/MbFooterComponent.vue
pages/firma/firsatlar-ve-teklifler.vue
### htmlContent script tag bug fixed (origin/master, origin/HEAD)
>Fri, 7 Jan 2022 09:19:44 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
nuxt.config.js
package.json
pages/firma/bakiye-yukle/kredi-karti.vue
plugins/vue-append.js
yarn.lock
### threeDStyle height updated
>Thu, 6 Jan 2022 08:54:38 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
pages/firma/bakiye-yukle/kredi-karti.vue
### 3d visual bug fixed
>Wed, 5 Jan 2022 19:37:21 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
pages/firma/bakiye-yukle/kredi-karti.vue
### buggs fixed
>Wed, 5 Jan 2022 09:17:48 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
pages/firma/bakiye-yukle/kredi-karti.vue
### 3d payment completed
>Wed, 5 Jan 2022 08:58:04 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
pages/firma/bakiye-yukle/kredi-karti.vue
pages/firma/firsatlar-ve-teklifler.vue
### developed 3ds payment process
>Fri, 31 Dec 2021 11:11:21 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
components/shared/MbFooterComponent.vue
pages/firma/bakiye-yukle/kredi-karti.vue
pages/firma/firsatlar-ve-teklifler.vue
pages/mesafeli-satis-sozlesmesi.vue
### added logos and pages for iyzico appeal
>Sat, 11 Sep 2021 14:32:53 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
components/shared/MbFooterComponent.vue
pages/firma/bakiye-yukle/kredi-karti.vue
pages/hakkimizda.vue
pages/mesafeli-satis-sozlesmesi.vue
pages/teslimat-ve-iade-sartlari.vue
static/images/icons/cc-logos.svg
static/images/icons/iyzico-payment-logo.svg
### expirationTime enums replaced by day count
>Sun, 29 Aug 2021 16:32:24 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
pages/teklif-al/asama-3.vue
### developed expiration time selectbox
>Sat, 28 Aug 2021 08:12:06 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
pages/teklif-al/asama-3.vue
### offerPriceInfo visual developments
>Fri, 27 Aug 2021 08:52:45 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
pages/firma/firsatlar-ve-teklifler.vue
### admin panel api base url replaced
>Fri, 27 Aug 2021 07:24:55 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
admin/src/store/store.js
### api base url replaced
>Fri, 27 Aug 2021 07:23:03 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
store/index.js
### update price information area developed
>Thu, 26 Aug 2021 10:20:25 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
admin/src/components/Settings.vue
### roleId changed
>Thu, 26 Aug 2021 09:15:41 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
admin/src/components/Login.vue
### credit card payment development
>Thu, 26 Aug 2021 08:54:37 +0300

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





CHANGELOG.md
nuxt.config.js
package.json
pages/firma/bakiye-yukle/havale.vue
pages/firma/bakiye-yukle/kredi-karti.vue
pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
pages/uye-ol.vue
static/css/style.css
yarn.lock
### images optimized
>Wed, 9 Jun 2021 01:15:24 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
static/images/Apartman-Yonetimi-Header.jpg
static/images/Detaylar arrow-down.png
static/images/EK_img.png
static/images/Group 1269.png
static/images/box-img-1.png
static/images/box-img-2.png
static/images/box-img-3.png
static/images/hero-bg.png
static/images/hero-icon-1.png
static/images/hero-icon-2.png
static/images/hero-icon-3.png
static/images/hero-icon-4.png
static/images/hero-icon-5.png
static/images/hero-icons.png
static/images/hero-subpages-bg.png
static/images/hero-subpages-main-img.png
static/images/img-icon-1.png
static/images/img-icon-2.png
static/images/img-icon-3.png
static/images/img1.png
static/images/main-sec-bg.png
static/images/man-lady.png
static/images/man.png
static/images/page-1-main-img.png
static/images/page2-main-sec-img.png
static/images/page3-main-img.png
static/images/page5-main-img.png
static/images/page6-img.png
static/images/page7-head-img.png
static/images/page7-main-sec-bg.png
static/images/page7-main-sec-img.png
static/images/page8-main-img.png
static/images/page9-head-img.png
static/images/sec-main-img-side.png
static/images/sec-main-img.png
static/images/woman.png
### nameSurname imageholder toUpperCase bug fixed
>Wed, 9 Jun 2021 00:52:21 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
pages/firma/firsatlar-ve-teklifler.vue
### Offers page developed
>Sat, 29 May 2021 17:40:42 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
admin/public/offers/index.html
admin/src/components/ContactList.vue
admin/src/components/Dashboard.vue
admin/src/components/Offers.vue
admin/src/components/UsersApproved.vue
admin/src/components/UsersUnApproved.vue
admin/src/router/index.js
### Buggs fixed
>Fri, 21 May 2021 20:26:28 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
admin/public/contact-list/index.html
admin/public/settings/index.html
admin/public/users-approved/index.html
admin/public/users-unapproved/index.html
admin/src/components/DashboardHome.vue
pages/firma/bilgileri-duzenle.vue
pages/uye-ol.vue
### Fixed CityIdList formData
>Wed, 19 May 2021 21:38:57 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
pages/firma/bilgileri-duzenle.vue
### Logo fixed
>Wed, 19 May 2021 20:01:14 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
pages/firma/bilgileri-duzenle.vue
### Logo fixed
>Wed, 19 May 2021 19:19:11 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
### Buggs fixed
>Wed, 19 May 2021 10:08:16 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
admin/src/components/ContactList.vue
admin/src/components/UsersApproved.vue
admin/src/components/UsersUnApproved.vue
pages/iletisim.vue
### Updated
>Tue, 18 May 2021 20:05:55 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
components/shared/MbFooterComponent.vue
pages/firma-girisi.vue
pages/uye-ol.vue
### Developed smsVerificationPage
>Mon, 17 May 2021 22:29:40 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
admin/src/components/Dashboard.vue
admin/src/router/index.js
admin/vue.config.js
components/shared/MaskedInputComponent.vue
nuxt.config.js
package.json
pages/sms-dogrulama.vue
pages/uye-ol.vue
plugins/v-mask.js
yarn.lock
### Developed admin panel, buggs fixed, new features added
>Thu, 13 May 2021 13:49:23 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
admin/public/index.html
admin/src/components/ContactList.vue
admin/src/components/Dashboard.vue
admin/src/components/DashboardHome.vue
admin/src/components/Home.vue
admin/src/components/Login.vue
admin/src/components/Logout.vue
admin/src/components/Settings.vue
admin/src/components/UsersApproved.vue
admin/src/components/UsersUnApproved.vue
admin/src/router/index.js
components/shared/MbHeaderComponent.vue
nuxt.config.js
pages/firma/bilgileri-duzenle.vue
pages/iletisim.vue
pages/index.vue
pages/uye-ol.vue
static/css/responsive.css
static/css/style.css
### Home page title changed, blog links changed
>Thu, 13 May 2021 10:00:33 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
components/shared/MbHeaderComponent.vue
pages/index.vue
### Buggs fixed, blog menu link added
>Mon, 10 May 2021 22:03:27 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
components/shared/MbHeaderComponent.vue
layouts/default.vue
pages/firma-girisi.vue
pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
pages/iletisim.vue
pages/index.vue
pages/kisisel-verilerin-korunmasi.vue
pages/sifremi-unuttum.vue
pages/teklif-al/asama-1.vue
pages/teklif-al/asama-2.vue
pages/teklif-al/asama-3.vue
pages/teklif-al/basarili.vue
pages/uye-ol.vue
### Developed admin panel login feature
>Sun, 9 May 2021 23:57:58 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
admin/src/components/DashboardHome.vue
admin/src/components/Home.vue
admin/src/components/Login.vue
admin/src/components/Logout.vue
admin/src/store/store.js
### Added update cityIdList feature to userUpdate
>Sun, 9 May 2021 22:53:26 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
### Removed company infos from kvkk
>Sun, 9 May 2021 21:42:45 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
pages/kisisel-verilerin-korunmasi.vue
### Added roleId to register request body
>Sun, 9 May 2021 21:33:24 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
pages/uye-ol.vue
### service-locations-box overflow bug fixed
>Sun, 9 May 2021 19:49:06 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
pages/uye-ol.vue
### Added company infos to KVKK
>Sun, 9 May 2021 19:40:33 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
pages/kisisel-verilerin-korunmasi.vue
### Developed admin dashboard structure
>Sun, 9 May 2021 19:04:03 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
admin/.gitignore
admin/babel.config.js
admin/package-lock.json
admin/package.json
admin/public/favicon.ico
admin/public/index.html
admin/src/App.vue
admin/src/components/ContactList.vue
admin/src/components/Dashboard.vue
admin/src/components/DashboardHome.vue
admin/src/components/Home.vue
admin/src/components/Login.vue
admin/src/components/Logout.vue
admin/src/components/UsersApproved.vue
admin/src/components/UsersUnApproved.vue
admin/src/element-variables.scss
admin/src/main.js
admin/src/plugins/element.js
admin/src/router/index.js
admin/src/store/store.js
admin/static.json
admin/vue.config.js
### /Account/SignUp taxAdministrationId parameter changed
>Sun, 9 May 2021 18:14:11 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
pages/uye-ol.vue
### Buggs fixed, extra features developed
>Sun, 9 May 2021 18:10:44 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
components/shared/MbHeaderComponent.vue
pages/firma-girisi.vue
pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
pages/sifremi-unuttum.vue
pages/uye-ol.vue
static/css/Campton-Bold.woff2
static/css/Campton-Book.woff2
static/css/Campton-Light.woff2
static/css/Campton-Medium.woff2
### Buggs fixed, forgot password feature developed, password validation developed, kvkk text confirmation feature developed
>Sun, 9 May 2021 15:38:19 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
components/shared/MbFooterComponent.vue
pages/firma-girisi.vue
pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
pages/iletisim.vue
pages/index.vue
pages/kisisel-verilerin-korunmasi.vue
pages/sifremi-unuttum.vue
pages/teklif-al/asama-2.vue
pages/teklif-al/asama-3.vue
pages/teklif-al/basarili.vue
pages/uye-ol.vue
store/index.js
### Added change-log-init script
>Wed, 5 May 2021 11:41:53 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
changelog-init.bat
post-commit
### Added files to auto changelog
>Wed, 5 May 2021 11:08:13 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
README.md
### Added files to auto changelog
>Wed, 5 May 2021 11:04:47 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
README.md
### Added auto changelog
>Wed, 5 May 2021 10:35:56 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





CHANGELOG.md
package.json
yarn.lock
### Made visual improvements
>Mon, 3 May 2021 21:50:18 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
pages/teklif-al/asama-1.vue
pages/teklif-al/asama-3.vue
pages/uye-ol.vue
static/css/style.css
### Buggs fixed
>Sun, 2 May 2021 20:47:40 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





pages/firma-girisi.vue
pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
### 
>Sun, 2 May 2021 13:22:11 +0300

>Author: Can Kara (can.kara@nozzlesoft.com)

>Commiter: Can Kara (can.kara@nozzlesoft.com)





store/index.js
### 
>Sun, 2 May 2021 13:22:02 +0300

>Author: Can Kara (can.kara@nozzlesoft.com)

>Commiter: Can Kara (can.kara@nozzlesoft.com)





pages/firma/bilgileri-duzenle.vue
store/index.js
### user put request id parameter updated
>Sun, 2 May 2021 10:10:38 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





pages/firma/bilgileri-duzenle.vue
### Logout page developed, logo upload feature developed, bugs fixed
>Sat, 1 May 2021 23:15:31 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





components/shared/MbHeaderComponent.vue
pages/cikis-yap.vue
pages/firma-girisi.vue
pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
store/index.js
### Bugs fixed
>Sat, 1 May 2021 20:34:03 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





pages/firma/firsatlar-ve-teklifler.vue
store/index.js
### price decimal convert edildi.
>Sat, 1 May 2021 16:43:27 +0300

>Author: Can Kara (can.kara@nozzlesoft.com)

>Commiter: Can Kara (can.kara@nozzlesoft.com)





package-lock.json
pages/firma/firsatlar-ve-teklifler.vue
store/index.js
### API integrations developed
>Sat, 1 May 2021 13:02:54 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





package.json
pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
pages/teklif-al/asama-1.vue
pages/teklif-al/asama-2.vue
pages/teklif-al/asama-3.vue
pages/uye-ol.vue
yarn.lock
### Developed UI
>Sat, 1 May 2021 02:50:09 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





pages/firma/firsatlar-ve-teklifler.vue
pages/iletisim.vue
pages/teklif-al/asama-3.vue
static/css/Campton-Black.woff
static/css/Campton-BlackItalic.woff
static/css/Campton-Bold.woff
static/css/Campton-BoldItalic.woff
static/css/Campton-Book.woff
static/css/Campton-BookItalic.woff
static/css/Campton-ExtraBold.woff
static/css/Campton-ExtraBoldItalic.woff
static/css/Campton-ExtraLight.woff
static/css/Campton-ExtraLightItalic.woff
static/css/Campton-Light.woff
static/css/Campton-LightItalic.woff
static/css/Campton-Medium.woff
static/css/Campton-MediumItalic.woff
static/css/Campton-SemiBold.woff
static/css/Campton-SemiBoldItalic.woff
static/css/Campton-Thin.woff
static/css/Campton-ThinItalic.woff
### Developed login enter feature, teklif al asama 3 bug fixed
>Fri, 30 Apr 2021 10:04:15 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





pages/firma-girisi.vue
pages/teklif-al/asama-3.vue
### Developed make offer feature, bugs fixed
>Thu, 29 Apr 2021 23:55:09 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





components/shared/MbFooterComponent.vue
components/shared/MbHeaderComponent.vue
layouts/default.vue
pages/iletisim.vue
pages/teklif-al/asama-1.vue
pages/teklif-al/asama-2.vue
pages/teklif-al/asama-3.vue
pages/uye-ol.vue
store/index.js
### Developed login, register and check logged in features
>Sun, 25 Apr 2021 16:53:15 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





nuxt.config.js
pages/firma-girisi.vue
pages/firma/firsatlar-ve-teklifler.vue
pages/uye-ol.vue
store/index.js
### API connections setted
>Sun, 25 Apr 2021 13:42:45 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





nuxt.config.js
package.json
pages/firma-girisi.vue
pages/firma/bakiye-yukle/havale.vue
pages/firma/bakiye-yukle/kredi-karti.vue
pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
pages/iletisim.vue
pages/index.vue
pages/teklif-al/asama-1.vue
pages/teklif-al/asama-2.vue
pages/teklif-al/asama-3.vue
pages/teklif-al/basarili.vue
pages/uye-ol.vue
store/README.md
store/index.js
yarn.lock
### Developed new UI structure
>Sun, 25 Apr 2021 01:47:03 +0300

>Author: Fatih Kaçar (fatih.kacar@nozzlesoft.com)

>Commiter: Fatih Kaçar (fatih.kacar@nozzlesoft.com)





.editorconfig
.gitignore
assets/README.md
components/shared/MbFooterComponent.vue
components/shared/MbHeaderComponent.vue
layouts/README.md
layouts/default.vue
middleware/README.md
nuxt.config.js
package.json
pages/firma-girisi.vue
pages/firma/bakiye-yukle/havale.vue
pages/firma/bakiye-yukle/kredi-karti.vue
pages/firma/bilgileri-duzenle.vue
pages/firma/firsatlar-ve-teklifler.vue
pages/iletisim.vue
pages/index.vue
pages/teklif-al/asama-1.vue
pages/teklif-al/asama-2.vue
pages/teklif-al/asama-3.vue
pages/teklif-al/basarili.vue
pages/uye-ol.vue
plugins/README.md
static/css/bootstrap.min.css
static/css/responsive.css
static/css/style.css
static/css/swiper-bundle.min.css
static/fonts/Campton-Bold.woff
static/fonts/Campton-Bold.woff2
static/fonts/Campton-Book.woff
static/fonts/Campton-Book.woff2
static/fonts/Campton-Light.woff
static/fonts/Campton-Light.woff2
static/fonts/Campton-Medium.woff
static/fonts/Campton-Medium.woff2
static/fonts/Campton-SemiBold.woff
static/fonts/Campton-SemiBold.woff2
static/fonts/TTCommons-DemiBold.woff
static/fonts/TTCommons-DemiBold.woff2
static/fonts/demo.html
static/images/Apartman-Yonetimi-Header.jpg
static/images/Detaylar arrow-down.png
static/images/EK_img.png
static/images/Group 1269.png
static/images/box-img-1.png
static/images/box-img-2.png
static/images/box-img-3.png
static/images/hero-bg.png
static/images/hero-icon-1.png
static/images/hero-icon-2.png
static/images/hero-icon-3.png
static/images/hero-icon-4.png
static/images/hero-icon-5.png
static/images/hero-icons.png
static/images/hero-subpages-bg.png
static/images/hero-subpages-main-img.png
static/images/icons/COPY.png
static/images/icons/account-icon.png
static/images/icons/acount-icon.png
static/images/icons/appartment -icon.png
static/images/icons/calendar.png
static/images/icons/coin.svg
static/images/icons/copyright-icon.png
static/images/icons/credit-card-front.png
static/images/icons/credit-card.png
static/images/icons/edit.svg
static/images/icons/email-icon.svg
static/images/icons/eye.svg
static/images/icons/forward-arrow-icon.png
static/images/icons/forward-icon.png
static/images/icons/icon-fb.png
static/images/icons/icon-insta.png
static/images/icons/icon-twitter.png
static/images/icons/left-side-arrow.png
static/images/icons/map-marker-alt.png
static/images/icons/market-icon.png
static/images/icons/page2-icon1.png
static/images/icons/page2-icon2.png
static/images/icons/page2-icon3.png
static/images/icons/page2-icon4.png
static/images/icons/page2-icon5.png
static/images/icons/paper-plane.svg
static/images/icons/phone-icon.svg
static/images/icons/phone.png
static/images/icons/sign-in.svg
static/images/icons/site-icon.png
static/images/icons/sticky-note.png
static/images/icons/sticky-note.svg
static/images/icons/submit-arrow.png
static/images/icons/tag.png
static/images/icons/upload.svg
static/images/icons/user-plus.svg
static/images/img-icon-1.png
static/images/img-icon-2.png
static/images/img-icon-3.png
static/images/img1.png
static/images/main-sec-bg.png
static/images/man-lady.png
static/images/man.png
static/images/page-1-main-img.png
static/images/page2-main-sec-img.png
static/images/page3-main-img.png
static/images/page5-main-img.png
static/images/page6-img.png
static/images/page7-head-img.png
static/images/page7-main-sec-bg.png
static/images/page7-main-sec-img.png
static/images/page8-main-img.png
static/images/page9-head-img.png
static/images/sec-main-img-side.png
static/images/sec-main-img.png
static/images/woman.png
static/js/bootstrap.min.js
static/js/custom.js
static/js/jquery-3.2.1.slim.min.js
static/js/jquery.min.js
static/js/popper.min.js
static/js/swiper-bundle.min.js
store/README.md
yarn.lock
### README.md edited online with Bitbucket
>Fri, 23 Apr 2021 14:12:40 +0000

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





README.md
### Initial commit
>Fri, 23 Apr 2021 14:12:12 +0000

>Author: Fatih Kaçar (info@fatihkacar.com)

>Commiter: Fatih Kaçar (info@fatihkacar.com)





.gitignore
README.md
