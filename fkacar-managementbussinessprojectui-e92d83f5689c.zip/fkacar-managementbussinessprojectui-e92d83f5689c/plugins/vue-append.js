import Vue from 'vue'
import VueAppend from 'vue-append'

Vue.use(VueAppend)
