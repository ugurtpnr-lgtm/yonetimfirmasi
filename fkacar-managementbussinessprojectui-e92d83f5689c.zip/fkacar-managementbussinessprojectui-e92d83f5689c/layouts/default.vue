<template>
  <div>
    <mb-header-component />
    <transition name="page-change">
      <Nuxt
        :keep-alive="$route.name === 'teklif-al-asama-1' ||
                      $route.name === 'teklif-al-asama-2' ||
                       $route.name === 'teklif-al-asama-3'"
      />
    </transition>
    <mb-footer-component />
  </div>
</template>

<script>
import MbHeaderComponent from '../components/shared/MbHeaderComponent'
import MbFooterComponent from '../components/shared/MbFooterComponent'

export default {
  transition: 'page-change',
  components: {
    MbHeaderComponent,
    MbFooterComponent
  }
}
</script>

<style>
  .page-change-enter-active, .page-change-leave-active { transition: opacity .5s; }
  .page-change-enter, .page-change-leave-active { opacity: 0; }
</style>
