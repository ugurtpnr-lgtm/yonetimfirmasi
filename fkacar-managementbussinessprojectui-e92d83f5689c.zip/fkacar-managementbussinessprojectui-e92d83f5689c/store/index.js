export const state = () => ({
  titleSuffix: 'YonetimFirmasi.com',
  apiBaseUrl: 'https://api.yonetimfirmasi.com/api',
  offerModel: [],
  isLoggedIn: false,
})

export const mutations = {
  setTitleSuffix(state, payload) {
    state.titleSuffix = payload
  },

  setOfferModel(state, payload) {
    state.offerModel = payload
  },

  setIsLoggedIn(state, payload) {
    state.isLoggedIn = payload
  },
}
