<template>
</template>

<script>
export default {
  name: 'logOutPage',

  mounted() {
    localStorage.yonetimFirmasiAccessToken = ''
    localStorage.yonetimFirmasiRefreshToken = ''
    localStorage.yonetimFirmasiTokenExpiration = ''
    localStorage.yonetimFirmasiUserId = ''
    localStorage.yonetimFirmasiAuthenticationInformationId = ''
    this.$store.commit('setIsLoggedIn', false)
    this.$router.push({
      path: '/firma-girisi'
    })
  }
}
</script>
