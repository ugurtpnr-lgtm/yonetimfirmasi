<template>
  <div id="sms-verification-page-container">
    <div class="hero-page-1">
      <div class="container ">
        <div class="row">
          <div class="col col-6 hero-page-1-text">
            <h1>SMS Doğrula</h1>
          </div>
          <div class="col col-6 hero-page-1-img ml-auto">
            <img src="/images/page7-head-img.png" alt="subpages-hero-img" class="img-fluid">
          </div>
        </div>
      </div>
      <hr>
    </div>
    <section class="page7-main-sec">
      <div class="container">
        <div class="row ">
          <div class="col-md-6">
            <div class="row">
              <div class="col-md-8">
                <div class="form-group">
                  <div class="sticky-notes">
                    <label> Doğrulama Kodu</label>
                    <input
                      class="form-control"
                      type="text"
                      placeholder="xxxxxx"
                      v-model="smsVerificationCode"
                      v-mask="'##########'"
                    >
                  <p style="font-size: 13px;margin-top: 3px" class="text-muted text-sm p-1">Lütfen cep telefonunuza gönderilen SMS doğrulama kodunu giriniz.</p>
                </div>
              </div>
            </div>
            <div class="col-md-4" />
            <div class="col-md-12 mt-5">
                <a @click="onVerify" class="btn">
                  Doğrula
                  <img src="/images/icons/submit-arrow.png" alt="submit-arrow" class="img-fluid">
                </a>
              </div>
            </div>
          </div>
          <div class="col-md-6 sec7-img">
            <img src="/images/page7-main-sec-img.png" alt="main-img" class="img-fluid">
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import {POSITION} from "vue-toastification";

const pageName = 'SMS Doğrulama'

export default {
  name: 'smsVerificationPage',

  head() {
    return {
      title: this.getTitle,
    }
  },

  data() {
    return {
      smsVerificationCode: ''
    }
  },

  mounted() {
    window.scrollTo({ top: 190, behavior: "smooth" })
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },

  methods: {
    onVerify() {
      let _this = this

      this.$axios.post(this.$store.state.apiBaseUrl + '/Account/ActivationCodeCheck?smsActivationCode=' + this.smsVerificationCode, {

      })
      .then(res => {
          _this.$toast.success('Telefon numaranız başarıyla doğrulandı. Lütfen bekleyiniz...', { position: POSITION.BOTTOM_RIGHT })
          setTimeout(() => {
            _this.$router.push({
                path: '/firma-girisi'
            })
          }, 3000)
        })
        .catch(err => {
          console.log(err)
          _this.$toast.error('HATA: Girdiğiniz kod yanlıştır!', { position: POSITION.BOTTOM_RIGHT })
        })
    }
  }
}
</script>
