<template>
  <div class="mb-company-home-page-container">
    <section class="page12-main-sec">
      <div class="container">
        <div class="page9-heading">
          <div class="row">
            <div class="col-md-9 col-12 col-left d-flex">
              <div class="image-holder">
                <div
                  style="
                    border: 1px solid #dddddd;
                    vertical-align: middle;
                    width: 100px;
                    height: 100px;
                    border-radius: 50%;
                    text-align: center;
                    padding-top: 18px;
                    font-weight: 900;
                    color: #636363;
                    font-size: 2.7vw;
                    margin-right: 15px;
                  "
                  class="image-holder"
                >
                  <div class="logo-content" v-if="!companyInfo.companyLogo">
                    {{ companyInfo.companyName[0] }}
                  </div>
                  <div class="logo-content" v-else>
                    <img
                      alt="logo"
                      class="img-fluid"
                      :src="'data:image/jpeg;base64,' + companyInfo.companyLogo"
                      style="width: 50%;margin-right: 0"
                    >
                  </div>
                  <!-- {{ companyInfo.companyName[0] }} -->
                </div>
              </div>
              <ul>
                <li>
                  {{ companyInfo.companyName }}
                </li>
                <li class="d-flex align-items-center complex-li">
                  <div class="d-flex complex-div">
                    <img
                      src="/images/icons/coin.svg"
                      alt="icon"
                      class="img-fluid mr-9 .iconimg"
                    />
                    Kullanılabilir Bakiye:<span
                      >&nbsp;&nbsp;&nbsp;&nbsp;{{ funds }} ₺</span
                    >
                  </div>
                  <NuxtLink class="btn" to="/firma/bakiye-yukle/kredi-karti">
                    BAKİYE YÜKLE
                    <img src="/images/icons/forward-icon.png" alt="icon" class="img-fluid ml-6">
                  </NuxtLink>
                </li>
              </ul>
            </div>
            <div class="col-md-3 col-right">
              <NuxtLink class="btn d-flex" to="/firma/bilgileri-duzenle">
                FİRMA BİLGİLERİ
                <img
                  src="/images/icons/edit.svg"
                  alt="icon"
                  class="img-fluid"
                />
              </NuxtLink>
            </div>
          </div>
        </div>
        <form>
          <div class="top-row">
            <div class="row">
              <div class="col-md-7">
                <div class="col-left">
                  <h5>Fırsatlar</h5>
                </div>
              </div>
              <div class="col-md-5">
                <div class="col-right">
                  <h5 v-show="currentlyOfferId">Teklif Ver</h5>
                </div>
              </div>
            </div>
          </div>
          <hr />
          <div class="row">
            <div class="col-lg-7 col-md-12">
              <div class="col-left">
                <div class="accordion" id="accordionteklifler">
                  <div
                    class="card"
                    v-for="(offer, index) in offers"
                    :key="offer.offerId"
                    :style="{
                      borderWidth: offer.active ? '4px !important' : '1.5px',
                    }"
                  >
                    <div class="card-header" id="headingOne">
                      <div class="collapse-items d-flex">
                        <div
                          style="width: 100%"
                          class="collapse-items-left d-flex"
                        >
                          <div
                            style="
                              border: 1px solid #dddddd;
                              vertical-align: middle;
                              width: 50px;
                              height: 50px;
                              border-radius: 50%;
                              text-align: center;
                              padding-top: 13px;
                              font-weight: 900;
                              color: #636363;
                            "
                            class="image-holder"
                          >
                            {{ offer.nameSurname.split(" ")[0][0].toUpperCase()
                            }}{{
                              offer.nameSurname.split(" ").length > 1
                                ? (offer.nameSurname
                                    .split(" ")
                                    [
                                      offer.nameSurname.split(" ").length - 1
                                    ][0] ? offer.nameSurname
                                    .split(" ")
                                    [
                                      offer.nameSurname.split(" ").length - 1
                                    ][0].toUpperCase() : '')
                                : ""
                            }}
                          </div>
                          <div class="text-box">
                            <h4>
                              {{
                                offer.offerTypeId ===
                                "95299a76-4e07-4c62-8b1f-08d908f142de"
                                  ? "Apartman Yönetimi"
                                  : offer.offerTypeId ===
                                    "19a5c618-8a66-46a7-8b20-08d908f142de"
                                  ? "Site Yönetimi"
                                  : offer.offerTypeId ===
                                    "8beb1200-142e-4d80-8b21-08d908f142de"
                                  ? "İş Merkezi Yönetimi"
                                  : ""
                              }}
                            </h4>
                            <h6>{{ offer.nameSurname }}</h6>
                            <p>{{ offer.message }}</p>
                            <button
                              class="btn"
                              type="button"
                              data-toggle="collapse"
                              :data-target="'#collapse_' + index"
                              aria-expanded="true"
                              aria-controls="collapseOne"
                            >
                              <img
                                src="/images/Detaylar%20arrow-down.png"
                                alt=""
                                class="img-fluid"
                              />
                            </button>
                          </div>
                        </div>
                        <div class="collapse-items-right">
                          <button
                            class="btn btn-block"
                            type="button"
                            data-toggle="collapse"
                            data-target="#"
                            aria-expanded="true"
                            aria-controls="collapseOne"
                            @click="makeOffer(offer.offerId)"
                            v-if="!offer.isOfferGiven"
                          >
                            TEKLİFVER
                            <img
                              src="/images/icons/forward-arrow-icon.png"
                              alt="icon"
                              class="img-fluid"
                            />
                          </button>
                          <button
                            class="btn btn-block"
                            type="button"
                            data-toggle="collapse"
                            data-target="#"
                            aria-expanded="true"
                            aria-controls="collapseOne"
                            @click="showLastOffer(offer.offerId)"
                            style=" background: transparent;
                                    color: #706f6f;
                                    font-size: 10px;
                                    cursor: pointer;"
                            v-else
                          >
                            TEKLİFİ GÖR
                          </button>
                        </div>
                      </div>
                    </div>

                    <div
                      :id="'collapse_' + index"
                      class="collapse"
                      aria-labelledby="headingOne"
                      data-parent="#accordionteklifler"
                    >
                      <div class="card-body">
                        <ul class="d-flex">
                          <li class="d-flex">
                            <img
                              src="/images/icons/calendar.png"
                              alt="icon"
                              class="img-fluid"
                            />
                            {{ offer.date }}
                          </li>
                          <li class="d-flex">
                            <img
                              :src="
                                offer.contactType === 1
                                  ? '/images/icons/email-icon.svg'
                                  : '/images/icons/phone.png'
                              "
                              alt="icon"
                              class="img-fluid"
                            />
                            Müşteri
                            {{
                              offer.contactType === 1 ? "mail" : "telefon"
                            }}
                            ile ulaşılabilir
                          </li>
                          <li class="d-flex">
                            <img
                              src="/images/icons/map-marker-alt.png"
                              alt="icon"
                              class="img-fluid"
                            />
                            {{ offer.neighborhoodName }}, {{ offer.townName }},
                            {{ offer.cityName }}
                          </li>
                        </ul>
                        <div class="QA d-flex QA1">
                          <div class="Que">
                            <h6>Kaç bağımsız bölüm var?</h6>
                            <p>{{ offer.numberOfEpisod }}</p>
                          </div>
                          <div class="Ans">
                            <h6>Kaç blok var?</h6>
                            <p>{{ offer.blockNo }}</p>
                          </div>
                        </div>
                        <div class="QA d-flex QA2">
                          <div class="Que">
                            <h6>Hangi hizmetler gerekiyor?</h6>
                            <p
                              v-for="service in offer.offerServiceTypes"
                              :key="service.id"
                            >
                              - {{ service.name }}
                            </p>
                          </div>
                          <div class="Ans">
                            <h6>İhtiyacın detayları neler?</h6>
                            <p>{{ offer.message }}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-5 col-md-12">
              <div class="col-right">
                <div class="card" v-show="currentlyOfferId">
                  <h6>Fiyat?<span> (KDV dahil)</span></h6>
                  <div class="form-group">
                    <div class="sticky-notes">
                      <input
                        v-model="makeOfferModel.price"
                        class="form-control"
                        type="text"
                        :readonly="offerDone"
                      />
                      <span
                        ><img src="/images/icons/tag.png" alt="icon"
                      /></span>
                    </div>
                  </div>
                  <div class="form-group message-textbox">
                    <label>Mesaj</label>
                    <div class="sticky-notes">
                      <textarea
                        v-model="makeOfferModel.message"
                        class="form-control"
                        rows="4"
                        :readonly="offerDone"
                      >
Mesajınızı buraya
yazabilirsiniz.</textarea
                      >
                      <span>
                        <img
                          src="/images/icons/sticky-note.png"
                          alt="sticky-notesicon"
                      /></span>
                    </div>
                  </div>
                  <div
                    class="offer-confirm-btns d-flex justify-content-between"
                  >
                    <button
                      class="btn confirm-btn"
                      type="button"
                      @click="makeOfferSubmit"
                      v-show="!offerDone && !(funds < offerPriceInfo)"
                      v-loading="isOfferSubmitLoading"
                    >
                      TEKLİFİ GÖNDER
                      <img
                        src="/images/icons/forward-arrow-icon.png"
                        alt="icon"
                        class="img-fluid"
                      />
                    </button>
                    <button
                      class="btn cancel-btn"
                      type="button"
                      @click="makeOfferCancel"
                    >
                      {{ (funds < offerPriceInfo) && !offerDone ? 'BAKİYE YETERSİZ' : offerDone ? "KAPAT" : "İPTAL ET" }}
                    </button>
                  </div>
                  <div class="offer-price-label text-muted d-flex justify-content-between">
                    (Teklif Ücreti: {{ offerPriceInfo }} TL)
                  </div>
                  <h6 v-if="offerDone" class="mt-3">İletişim Bilgisi</h6>
                  <div v-if="offerDone" class="form-group">
                    <div class="sticky-notes">
                      <input
                        v-model="currentlyOfferContactInfo"
                        class="form-control"
                        type="text"
                        readonly
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </section>
  </div>
</template>

<script>
import { POSITION } from "vue-toastification";
import dateFormat from "dateformat";

const pageName = "Firma | Fırsatlar ve Teklifler";

export default {
  name: "companyHomePage",

  head() {
    return {
      title: this.getTitle,
    };
  },

  mounted() {
    this.checkPayment()
    this.checkIsLoggedIn()
    this.getFunds()
    this.getPriceInfo()
    window.scrollTo({ top: 0, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + " - " + this.$store.state.titleSuffix,
      funds: 0,
      offerPriceInfo: 0,
      offers: [],
      currentlyOfferId: '',
      currentlyOfferContactInfo: '',
      makeOfferModel: {
        price: "",
        message: "",
      },
      offerDone: false,
      isOfferSubmitLoading: false,
      companyInfo: {
        companyLogo: "",
        companyName: "",
        name: "",
        phoneNumber: "",
        surname: "",
        taxAdministration: "",
        taxNumber: "",
        userId: "",
        funds: 0,
      },
    };
  },

  computed: {
    getTitle() {
      return this.pageTitle;
    },
  },

  methods: {
    getFunds() {
      let _this = this

      this.$axios.get(this.$store.state.apiBaseUrl + '/Payment/Get', {
        headers: {
          Authorization:
            "Bearer " + localStorage.yonetimFirmasiAccessToken,
        },
      })
        .then(res => {
          if(!res.data.data) {
            _this.funds = 0
            return
          }

          _this.funds = res.data.data.lastAmount
        })
        .catch(err => {
          _this.funds = 0
          console.error(err)
        })
    },

    getPriceInfo() {
      let _this = this

      this.$axios.get(this.$store.state.apiBaseUrl + '/PriceInformation/Get?id=1', {
        headers: {
          Authorization:
            "Bearer " + localStorage.yonetimFirmasiAccessToken,
        }
      })
        .then(res => {
          _this.offerPriceInfo = res.data.data.price
        })
        .catch(err => {
          console.error(err)
        })
    },

    checkIsLoggedIn() {
      let _this = this;

      if (localStorage.yonetimFirmasiAccessToken) {
        this.$axios
          .get(
            this.$store.state.apiBaseUrl +
              "/User/Get?UserId=" +
              localStorage.yonetimFirmasiUserId,
            {
              headers: {
                Authorization:
                  "Bearer " + localStorage.yonetimFirmasiAccessToken,
              },
            }
          )
          .then((res) => {
            _this.$store.commit('setIsLoggedIn', true)
            _this.companyInfo = Object.assign(_this.companyInfo, res.data.data);
            _this.getOffers();
          })
          .catch((err) => {
            _this.$router.push({
              path: "/firma-girisi",
            });
          });
      } else {
        this.$router.push({
          path: "/firma-girisi",
        });
      }
    },

    getOffers() {
      let _this = this;

      this.$axios
        .post(
          this.$store.state.apiBaseUrl + "/Offer/Search",
          {
            limit: 100,
          },
          {
            headers: {
              Authorization: "Bearer " + localStorage.yonetimFirmasiAccessToken,
            },
          }
        )
        .then((res) => {
          let filteredRes = res.data.data.map((offer) => {
            return {
              ...offer,
              townName: "",
              cityName: "",
              neighborhoodName: "",
              active: false,
              date: dateFormat(offer.creationTime, "dd/mm/yyyy - HH:MM"),
            };
          });

          _this.offers = filteredRes;
          _this.getAddresses();
        })
        .catch((err) => {
          console.log(err);
        });
    },

    async getAddresses() {
      for (let i = 0; i < this.offers.length; i++) {
        this.offers[i].cityName = await this.getCity(this.offers[i].cityId)
        this.offers[i].neighborhoodName = await this.getNeighborhood(this.offers[i].neighborhoodId)
        this.offers[i].townName = await this.getTown(this.offers[i].townId)
      }
    },

    getTown(townId) {
      return this.$axios
        .get(this.$store.state.apiBaseUrl + "/Town?TownId=" + townId)
        .then((res) => {
          return res.data.data.name
        });
    },

    async getCity(cityId) {
      return await this.$axios
        .get(this.$store.state.apiBaseUrl + "/City?CityId=" + cityId)
        .then((res) => {
          return res.data.data.name
        });
    },

    getNeighborhood(neighborhoodId) {
      return this.$axios
        .get(
          this.$store.state.apiBaseUrl +
            "/Neighborhood?id=" +
            neighborhoodId
        )
        .then((res) => {
          return res.data.data.name + " Mh."
        });
    },

    makeOffer(offerId) {
      this.offerDone = false;
      this.makeOfferModel.price = ""
      this.makeOfferModel.message = ""

      this.offers.forEach((offer) => {
        offer.active = false
      });

      this.offers.find((offer) => offer.offerId === offerId).active = true
      window.scrollTo({ top: 150, behavior: "smooth" })
      this.currentlyOfferId = offerId
      this.currentlyOfferContactInfo = this.offers.find((offer) => offer.offerId === offerId).contactType === 1 ?
                                          this.offers.find((offer) => offer.offerId === offerId).email :
                                            this.offers.find((offer) => offer.offerId === offerId).telephone
    },

    showLastOffer(offerId) {
      this.offerDone = true

      const offerObj = this.offers.find(offer => offer.offerId === offerId)
      this.makeOfferModel.price = offerObj.price
      this.makeOfferModel.message = offerObj.description

      this.offers.forEach((offer) => {
        offer.active = false
      })

      this.offers.find((offer) => offer.offerId === offerId).active = true
      window.scrollTo({ top: 150, behavior: "smooth" })
      this.currentlyOfferId = offerId
      this.currentlyOfferContactInfo = offerObj.contactType === 1 ?
                                          offerObj.email :
                                            offerObj.telephone
    },

    makeOfferSubmit() {
      let _this = this;

      if(this.funds < this.offerPriceInfo) {
        this.$toast.error("HATA: Bakiye yetersiz!", {
          position: POSITION.BOTTOM_RIGHT,
        })

        return
      }

      if(!this.makeOfferModel.message || !this.makeOfferModel.price) {
        this.$toast.error("HATA: Lütfen fiyat ve mesaj girin!", {
          position: POSITION.BOTTOM_RIGHT,
        })

        return
      }

      this.isOfferSubmitLoading = true

      this.$axios
        .post(this.$store.state.apiBaseUrl + "/UserOffer", {
          userId: localStorage.yonetimFirmasiUserId,
          offerId: this.currentlyOfferId,
          description: this.makeOfferModel.message,
          price: parseFloat(this.makeOfferModel.price),
          uploadFiles: [],
        }, {
          headers: {
            Authorization: "Bearer " + localStorage.yonetimFirmasiAccessToken,
          },
        })
        .then((res) => {
          _this.offers.find(offer => offer.offerId === this.currentlyOfferId).isOfferGiven = true
          _this.getFunds()

          _this.offerDone = true

          _this.$toast.success("Başarıyla teklif verdiniz...", {
            position: POSITION.BOTTOM_RIGHT,
          });
        })
        .catch((err) => {
          _this.$toast.error("HATA: Beklenmedik bir hata oluştu! Lütfen yeterli bakiyeniz bulunduğundan emin olun.", {
            position: POSITION.BOTTOM_RIGHT,
          });
        })
        .finally(() => _this.isOfferSubmitLoading = false)
    },

    makeOfferCancel() {
      this.currentlyOfferId = "";
      this.offerDone = false;
      this.offers.forEach((offer) => {
        offer.active = false;
      });
    },

    checkPayment() {
      if(!Object.keys(this.$route.query).includes('payment')) return

      const payment = this.$route.query.payment

      if(payment === 'true') {
        this.$toast.success("Bakiyeniz başarıyla yüklendi!", {
          position: POSITION.BOTTOM_RIGHT,
        })
        return
      }

      this.$toast.error("HATA: Ödememeniz gerçekleştirilemedi! Bunun bir hata olduğunu düşünüyorsanız lütfen bankanız ile iletişime geçiniz.", {
        position: POSITION.BOTTOM_RIGHT,
      })
    }
  },
};
</script>

<style>
.offer-price-label {
  font-family: 'Roboto', sans-serif;
  font-size: 0.9em;
  padding-top: 7px;
  padding-left: 1.5vw;
}
</style>
