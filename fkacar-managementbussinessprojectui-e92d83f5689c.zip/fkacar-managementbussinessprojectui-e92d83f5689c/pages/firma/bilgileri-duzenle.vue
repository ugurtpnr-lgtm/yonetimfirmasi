<template>
  <div class="mb-company-edit-info-page-container">
    <section class="page9-main-sec">
      <div class="container">
        <div class="page9-heading">
          <div class="row">
            <div class="col-md-8 col-12 col-left d-flex">
              <div class="image-holder">
                <div
                  style="
                    border: 1px solid #dddddd;
                    vertical-align: middle;
                    width: 100px;
                    height: 100px;
                    border-radius: 50%;
                    text-align: center;
                    padding-top: 18px;
                    font-weight: 900;
                    color: #636363;
                    font-size: 2.7vw;
                    margin-right: 15px;
                  "
                  class="image-holder"
                >
                  <div class="logo-content" v-if="!companyInfo.companyLogo">
                    {{ companyInfo.companyName[0] }}
                  </div>
                  <div class="logo-content" v-else>
                    <img
                      alt="logo"
                      class="img-fluid"
                      :src="'data:image/jpeg;base64,' + companyInfo.companyLogo"
                      style="width: 50%;margin-right: 0"
                    >
                  </div>
                  <!-- {{ companyInfo.companyName[0] }} -->
                </div>
              </div>
              <ul>
                <li>
                  {{ companyInfo.companyName }}
                </li>
                <li class="d-flex align-items-center complex-li">
                  <div class="d-flex complex-div">
                    <img
                      src="/images/icons/coin.svg"
                      alt="icon"
                      class="img-fluid mr-9 .iconimg"
                    />
                    Kullanılabilir Bakiye:<span>
                      &nbsp;&nbsp;{{ funds }} ₺</span
                    >
                  </div>
                  <NuxtLink class="btn" to="/firma/bakiye-yukle/kredi-karti">
                    BAKİYE YÜKLE
                    <img src="/images/icons/forward-icon.png" alt="icon" class="img-fluid ml-6">
                  </NuxtLink>
                </li>
              </ul>
            </div>
            <div class="col-md-4 col-right">
              <NuxtLink class="btn d-flex" to="/firma/firsatlar-ve-teklifler">
                FIRSATLAR VE TEKLİFLER
                <img
                  src="/images/icons/edit.svg"
                  alt="icon"
                  class="img-fluid"
                />
              </NuxtLink>
            </div>
          </div>
        </div>

        <form>
          <div class="col-md-6">
            <div class="col-left">
              <h5>Bilgileri Düzenle</h5>

              <div class="form-group">
                <label>Firma Logonuzu Güncelleyin</label>

                <div @click="onUploadAreaClick" class="fileUpload">
                  <div v-if="!logoFilename">
                    <input
                      ref="logo-upload"
                      type="file"
                      class="upload"
                      id="logo-upload"
                      @change="onChangeUploadInput"
                    />
                    <span
                      ><img
                        src="/images/icons/upload.svg"
                        alt="upload-icon" /></span
                    ><br />
                    <span>Logo dosyasını yükleyin</span>
                  </div>
                  <div v-else>
                    {{ logoFilename }}
                  </div>
                </div>
              </div>

              <div class="form-group">
                <label>Firma Temsilcisi</label>
                <input
                  type="text"
                  class="form-control"
                  v-model="infoModel.authPersonname"
                  placeholder="Firma temsilcisi"
                />
              </div>
              <div class="form-group">
                <label> Mail adresiniz</label>
                <div class="sticky-notes">
                  <input
                    class="form-control"
                    type="text"
                    placeholder="Mail adresiniz"
                    v-model="infoModel.email"
                    name="email"
                  />
                  <span
                    ><img src="/images/icons/email-icon.svg" alt="emial-icon"
                  /></span>
                </div>
              </div>

              <div class="row taxs">
                <div class="col-md-6 col-12">
                  <div class="form-group">
                    <label>Vergi Dairesi</label>
                    <input
                      type="text"
                      class="form-control"
                      placeholder="Vergi dairesi"
                      v-model="infoModel.taxAdministration"
                      disabled
                    />
                  </div>
                </div>

                <div class="col-md-6 col-12">
                  <div class="form-group">
                    <label>Vergi No</label>
                    <input
                      type="text"
                      class="form-control"
                      placeholder="Vergi numarası"
                      v-model="infoModel.taxNumber"
                      disabled
                    />
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label> Telefon Numaranız</label>
                <div class="sticky-notes">
                  <input
                    class="form-control"
                    type="text"
                    placeholder="(5xx) xxx xxxx"
                    name="email"
                    v-model="infoModel.phoneNumber"
                  />
                  <span
                    ><img src="/images/icons/phone-icon.svg" alt="phone-icon"
                  /></span>
                </div>
              </div>
              <div class="form-group">
                <label >Hizmet Vermek İstediğiniz Lokasyonlar</label>
                <select
                  class="form-control"
                  style="height: 53px;border: 1px solid #280B65;background: rgba(40, 11, 101, 0.03);"
                  v-model="serviceLocationCity"
                  @change="addServiceLocation"
                >
                  <option selected value="">--- SEÇİNİZ ---</option>
                  <option
                    v-for="city in cities"
                    :key="city.id"
                    :value="city.id"
                  >{{ city.name }}
                  </option>
                </select>
                <div
                  class="service-locations-box"
                >
                  <p
                    v-for="location in serviceLocations"
                    :key="location.id"
                    @click="removeServiceLocation(location.id)"
                  >
                    {{ location.name }}
                  </p>
                </div>
                <p style="font-size: 13px;margin-top: 3px" class="text-muted text-sm p-1">Lokasyonlarınız yukarıdaki kutucukta listelenmiştir. Eğer varsa, listeden çıkartmak istediğiniz lokasyonun üzerine tıklayabilirsiniz.</p>
              </div>
              <button @click="updateInfos" type="button" class="btn mt-3">
                GÜNCELLE
                <img
                  src="/images/icons/submit-arrow.png"
                  alt="submit-arrow"
                  class="img-fluid"
                />
              </button>

              <h6>Şifrenizi Değiştirin</h6>
              <div class="row codes">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Şifreniz</label>
                    <input
                      type="password"
                      class="form-control"
                      placeholder="*********"
                      v-model="infoModel.password"
                    />
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Şifreniz (Tekrar)</label>
                    <input
                      type="password"
                      class="form-control"
                      placeholder="*********"
                      v-model="infoModel.passwordAgain"
                    />
                  </div>
                </div>
              </div>
              <button type="button" class="btn mt-3" @click="updatePassword">
                GÜNCELLE
                <img
                  src="/images/icons/submit-arrow.png"
                  alt="submit-arrow"
                  class="img-fluid"
                />
              </button>
            </div>
          </div>
        </form>
      </div>
    </section>
  </div>
</template>

<script>
import { POSITION } from "vue-toastification";

const pageName = "Firma | Bilgileri Düzenle";

export default {
  name: "companyEditInfoPage",

  head() {
    return {
      title: this.getTitle,
    };
  },

  mounted() {
    this.getCities()
    this.checkIsLoggedIn()
    this.getFunds()
    window.scrollTo({ top: 0, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + " - " + this.$store.state.titleSuffix,
      funds: 0,
      logoFilename: "",
      serviceLocationCity: '',
      cities: [],
      serviceLocations: [],
      companyInfo: {
        companyLogo: "",
        companyName: "",
        name: "",
        phoneNumber: "",
        surname: "",
        taxAdministrationId: "",
        taxNumber: "",
        userId: "",
        funds: 0,
        email: "",
        cityIdList: ''
      },
      infoModel: {
        companyLogo: "",
        companyName: "",
        name: "",
        phoneNumber: "",
        surname: "",
        taxAdministration: "",
        taxNumber: "",
        userId: "",
        funds: 0,
        email: "",
        password: "",
        passwordAgain: "",
      },
    };
  },

  computed: {
    getTitle() {
      return this.pageTitle;
    },
  },

  methods: {
    getFunds() {
      let _this = this

      this.$axios.get(this.$store.state.apiBaseUrl + '/Payment/Get', {
        headers: {
          Authorization:
            "Bearer " + localStorage.yonetimFirmasiAccessToken,
        },
      })
        .then(res => {
          if(!res.data.data) {
            _this.funds = 0
            return
          }

          _this.funds = res.data.data.lastAmount
        })
        .catch(err => {
          _this.funds = 0
          console.error(err)
        })
    },

    checkIsLoggedIn() {
      let _this = this;
      if (localStorage.yonetimFirmasiAccessToken) {
        this.$axios
          .get(
            this.$store.state.apiBaseUrl +
              "/User/Get?UserId=" +
              localStorage.yonetimFirmasiUserId,
            {
              headers: {
                Authorization:
                  "Bearer " + localStorage.yonetimFirmasiAccessToken,
              },
            }
          )
          .then((res) => {
            _this.companyInfo = Object.assign(_this.companyInfo, res.data.data);
            _this.infoModel = Object.assign(_this.infoModel, res.data.data);
            _this.infoModel.authPersonname =
              _this.infoModel.name + " " + _this.infoModel.surname;
            _this.getTaxAdmin(_this.companyInfo.taxAdministrationId)
            _this.generateServiceLocations(_this.companyInfo.cityIdList)
            _this.infoModel.companyLogo = new FormData()
            _this.infoModel.companyLogo.append('CompanyLogo', '')
          })
          .catch((err) => {
            if(err) {
              console.log('Authorization error: ' + err)
                _this.$router.push({
                path: "/firma-girisi",
              });
            }
          });
      } else {
        this.$router.push({
          path: "/firma-girisi",
        });
      }
    },

    getCities() {
      let _this = this

      this.$axios.post(this.$store.state.apiBaseUrl + '/City', {})
          .then(res =>  {
            _this.cities = res.data.data
          })
    },

    updateInfos() {
      let _this = this;

      const formData = this.infoModel.companyLogo
      formData.append('Id', localStorage.yonetimFirmasiUserId)
      formData.append('Name', this.infoModel.authPersonname.split(" ")[0])
      formData.append('Surname', this.infoModel.authPersonname.split(" ")[1])
      formData.append('PhoneNumber', this.infoModel.phoneNumber)
      formData.append('TaxAdministrationId', this.companyInfo.taxAdministrationId)
      formData.append('TaxNumber', this.infoModel.taxNumber)
      formData.append('CompanyName', this.companyInfo.companyName)

      this.serviceLocations.forEach(location => {
        formData.append('CityIdList', location.id)
      })

      /*
      * {
            id: localStorage.yonetimFirmasiUserId,
            name: this.infoModel.authPersonname.split(" ")[0],
            surname: this.infoModel.authPersonname.split(" ")[1],
            phoneNumber: this.infoModel.phoneNumber,
            taxAdministrationId: this.companyInfo.taxAdministrationId,
            taxNumber: this.infoModel.taxNumber,
            companyLogo: this.infoModel.companyLogo ? this.infoModel.companyLogo : this.companyInfo.companyLogo,
            companyName: this.companyInfo.companyName,
            cityIdList: this.serviceLocations.map(location => location.id),
          }
      * */

      this.$axios
        .post(
          this.$store.state.apiBaseUrl + "/User/Update/Update",
          formData,
          {
            headers: {
              Authorization: "Bearer " + localStorage.yonetimFirmasiAccessToken
            },
          }
        )
        .then((res) => {
          _this.$toast.success("Bilgiler güncellendi.", {
            position: POSITION.BOTTOM_RIGHT,
          })
          _this.companyInfo.companyLogo = res.data.data.companyLogo
        })
        .catch((err) => {
          _this.$toast.error("HATA: Beklenmedik bir hata oluştu!", {
            position: POSITION.BOTTOM_RIGHT,
          });
        });
    },

    updatePassword() {
      let _this = this;

      if (this.infoModel.password !== this.infoModel.passwordAgain) {
        this.$toast.error("HATA: Şifreler birbiriyle eşleşmiyor!", {
          position: POSITION.BOTTOM_RIGHT,
        });
        return;
      }

      this.$axios
        .post(
          this.$store.state.apiBaseUrl + "/Account/UpdatePasswordEmail",
          {
            authenticationInformationId:
              localStorage.yonetimFirmasiAuthenticationInformationId,
            password: this.infoModel.password,
          },
          {
            headers: {
              Authorization: "Bearer " + localStorage.yonetimFirmasiAccessToken,
            },
          }
        )
        .then((res) => {
          _this.$toast.success("Şifre güncellendi.", {
            position: POSITION.BOTTOM_RIGHT,
          });
        })
        .catch((err) => {
          _this.$toast.error("HATA: Beklenmedik bir hata oluştu!", {
            position: POSITION.BOTTOM_RIGHT,
          });
        });
    },

    onUploadAreaClick() {
      this.$refs["logo-upload"].click();
    },

    async onChangeUploadInput(val) {
      this.logoFilename = val.target.files[0].name;
      /*this.infoModel.companyLogo = await this.toBase64(
        this.$refs["logo-upload"].files[0]
      );*/

      this.infoModel.companyLogo.append('CompanyLogo', this.$refs["logo-upload"].files[0])
    },

    toBase64(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = (error) => reject(error);
      });
    },

    fileToByteArray(file) {
        return new Promise((resolve, reject) => {
            try {
                let reader = new FileReader();
                let fileByteArray = [];
                reader.readAsArrayBuffer(file);
                reader.onloadend = (evt) => {
                    if (evt.target.readyState == FileReader.DONE) {
                        let arrayBuffer = evt.target.result,
                            array = new Uint8Array(arrayBuffer);
                        for (let i = 0; i < array.length; i++) {
                            fileByteArray.push(array[i]);
                        }
                    }
                    resolve(fileByteArray);
                }
            }
            catch (e) {
                reject(e);
            }
        })
    },

    addServiceLocation() {
      this.serviceLocations.push({
        id: parseInt(this.serviceLocationCity),
        name: this.cities.find(city => city.id === parseInt(this.serviceLocationCity)).name
      })

      this.serviceLocationCity = ''
    },

    removeServiceLocation(locationId) {
      this.serviceLocations = this.serviceLocations.filter(location => location.id !== locationId)
    },

    getTaxAdmin(taxAdminId) {
      let _this = this

      this.$axios.get(this.$store.state.apiBaseUrl + '/TaxAdministration?id=' + taxAdminId )
          .then(res =>  {
            _this.infoModel.taxAdministration = res.data.data.name
          })
    },

    generateServiceLocations(cityIdList) {
      let _this = this

      if(!this.cities.length) {
        setTimeout(() => _this.generateServiceLocations(cityIdList), 1000)
        return
      }

      cityIdList.forEach((cityId) => {
        this.serviceLocations.push({
          id: cityId,
          name: _this.cities.find(city => city.id === cityId).name
        })
      })
    }
  },
};
</script>

<style scoped>
.service-locations-box {
  background: rgba(40, 11, 101, 0.03);
  border: 1px solid #280B65;
  border-radius: 4px;
  padding: 26px 16px;
  width: 100%;
  height: 200px;
  margin-top: 20px;
  overflow-y: auto;
}

.service-locations-box > p {
  width: 100%;
}

.service-locations-box > p:hover {
  background: #e1dcea;
  cursor: pointer;
}
</style>
