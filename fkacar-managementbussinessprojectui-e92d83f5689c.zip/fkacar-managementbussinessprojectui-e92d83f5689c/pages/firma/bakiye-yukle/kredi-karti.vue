<template>
  <div class="mb-company-deposit-cc-page-container">
    <section class="page10-main-sec">
                <div class="container">
                  <div class="page9-heading">
                    <div class="row">
                      <div class="col-md-9 col-12 d-flex">
                        <div class="image-holder">
                          <div
                            style="
                    border: 1px solid #dddddd;
                    vertical-align: middle;
                    width: 100px;
                    height: 100px;
                    border-radius: 50%;
                    text-align: center;
                    padding-top: 18px;
                    font-weight: 900;
                    color: #636363;
                    font-size: 2.7vw;
                    margin-right: 15px;
                  "
                            class="image-holder"
                          >
                            <div class="logo-content" v-if="!companyInfo.companyLogo">
                              {{ companyInfo.companyName[0] }}
                            </div>
                            <div class="logo-content" v-else>
                              <img
                                alt="logo"
                                class="img-fluid"
                                :src="'data:image/jpeg;base64,' + companyInfo.companyLogo"
                                style="width: 50%;margin-right: 0"
                              >
                            </div>
                            <!-- {{ companyInfo.companyName[0] }} -->
                          </div>
                        </div>
                        <ul>
                          <li>
                            {{ companyInfo.companyName }}
                          </li>
                          <li class="d-flex align-items-center complex-li">
                            <div class="d-flex complex-div">
                              <img
                                src="/images/icons/coin.svg"
                                alt="icon"
                                class="img-fluid mr-9 .iconimg"
                              />
                              Kullanılabilir Bakiye:<span
                            >&nbsp;&nbsp;&nbsp;&nbsp;{{ funds }} ₺</span
                            >
                            </div>
                            <NuxtLink class="btn" to="/firma/bakiye-yukle/kredi-karti">
                              BAKİYE YÜKLE
                              <img src="/images/icons/forward-icon.png" alt="icon" class="img-fluid ml-6">
                            </NuxtLink>
                          </li>
                        </ul>
                      </div>
                      <div class="col-md-3 col-right">
                        <NuxtLink class="btn d-flex" to="/firma/bilgileri-duzenle">
                          FİRMA BİLGİLERİ
                          <img
                            src="/images/icons/edit.svg"
                            alt="icon"
                            class="img-fluid"
                          />
                        </NuxtLink>
                      </div>
                    </div>
                  </div>
                   <form>
                       <div class="row">
                    <div class="col-md-12 ">
                        <div class="col-left">
                            <h5>Bakiye Yükle</h5>
                       <div class="forward-btns">
                             <div class="row ">

                               <div class="col-6">
                                    <NuxtLink class="btn colored-bg cc-button" to="/firma/bakiye-yukle/kredi-karti">
                                       KREDİ KARTI
                                       <img src="/images/icons/forward-arrow-icon.png" alt="submit-arrow" class="img-fluid">
                                     </NuxtLink>

                                 </div>
                                 <div class="col-6">
                                    <NuxtLink class="btn plane-bg cc-button d-none" to="/firma/bakiye-yukle/havale">
                                       HAVALE/EFT
                                       <img src="/images/icons/submit-arrow.png" alt="submit-arrow" class="img-fluid">
                                     </NuxtLink>
                                 </div>

                             </div>
                             </div>

                        </div><hr>
                        </div>

                         <div class="card-logos d-flex container mb-4">
                           <img alt="card payment logos" class="cc-logos" src="/images/icons/iyzico-payment-logo.svg" />
                         </div>
                        <div class="col-md-12 " v-if="!threeDHtmlContent">
                            <div class="col-left">
                             <h5>
                                Yüklenecek Miktar
                             </h5>
                             <div class="four-sm-btns">
                             <div class="row ">
                                 <div class="col-sm-3 col-6">
                                    <button
                                      type="button"
                                      :class="{ btn: true, 'colored-bg': amount === 40, 'rates-high-bg': amount !== 40 }"
                                      @click="amount = 40"
                                    >
                                      40₺
                                    </button>
                                 </div>
                                 <div class="col-sm-3 col-6">
                                   <button
                                     type="button"
                                     :class="{ btn: true, 'colored-bg': amount === 80, 'rates-high-bg': amount !== 80 }"
                                     @click="amount = 80"
                                   >
                                      80₺
                                    </button>
                                 </div>
                                 <div class="col-sm-3 col-6">
                                   <button
                                     type="button"
                                     :class="{ btn: true, 'colored-bg': amount === 100, 'rates-high-bg': amount !== 100 }"
                                     @click="amount = 100"
                                   >
                                      100₺
                                    </button>
                                 </div>
                                 <div class="col-sm-3 col-6">
                                   <button
                                     type="button"
                                     :class="{ btn: true, 'colored-bg': amount === 500, 'rates-high-bg': amount !== 500 }"
                                     @click="amount = 500"
                                   >
                                      500₺
                                    </button>
                                 </div>
                             </div>
                             </div>



                              <div class="form-group">
                                <label >Şehir</label>
                                <input
                                  type="text"
                                  class="form-control"
                                  placeholder="Şehir (fatura için)"
                                  v-model="ccModel.city"
                                >
                              </div>
                              <div class="form-group">
                                <label >Fatura Adresi</label>
                                <input
                                  type="text"
                                  class="form-control"
                                  placeholder="Fatura adresi"
                                  v-model="ccModel.billingAddress"
                                >
                              </div>
                                 <div class="form-group mt-5">
                                     <label >Kart Sahibi Adı Soyadı</label>
                                     <input
                                       type="text"
                                       class="form-control"
                                       placeholder="Kart üzerindeki isim"
                                       v-model="ccModel.name"
                                       autocomplete="cc-name"
                                       x-autocompletetype="cc-name"
                                       name="name"
                                     >

                                   </div>
                                 <div class="form-group">
                                     <label>  Kart Numaranız</label>
                                     <div class="sticky-notes">
                                     <input
                                       class="form-control"
                                       type="text"
                                       placeholder="5544 5544 6699 8887"
                                       v-mask="'#### #### #### ####'"
                                       v-model="ccModel.number"
                                       autocomplete="cc-number"
                                       x-autocompletetype="cc-number"
                                       name="cc-number"
                                     >
                                     <span><img src="/images/icons/credit-card-front.png" alt="credit-card-icon"></span></div>

                               </div>
                              <div class="credit-card-row">
                              <div class="row ">
                                    <div class="col-sm-6 col-12">
                                         <div class="form-group">
                                             <label >AA/YY</label>
                                             <input
                                               type="text"
                                               class="form-control"
                                               placeholder="10/21"
                                               v-mask="'## / ##'"
                                               v-model="ccModel.exp"
                                               autocomplete="cc-exp"
                                               x-autocompletetype="cc-exp"
                                               name="cc-exp"
                                             >

                                           </div>
                                           </div>

                                <div class="col-sm-6 col-12">
                                         <div class="form-group">
                                             <label >CVC</label>
                                             <div class="sticky-notes">
                                             <input
                                               type="text"
                                               class="form-control"
                                               placeholder="215"
                                               v-mask="'###'"
                                               v-model="ccModel.cvc"
                                               autocomplete="cc-csc"
                                               x-autocompletetype="cc-csc"
                                               name="cvv2"
                                             >
                                             <span><img src="/images/icons/credit-card.png" alt="credit-card-icon"></span>
                                            </div>
                                           </div>
                                         </div>
                                         </div>
                                         </div>
                                         <div class="end-btn">
                         <button @click="payment" v-loading="isPaymentButtonLoading" type="button" class="btn">ÖDEME YAP
                             <img src="/images/icons/submit-arrow.png" alt="submit-arrow" class="img-fluid">
                         </button>
                         </div>

                         </div>
                        </div>
                         <div class="col-12">
                           <div :style="threeDStyle" v-if="threeDHtmlContent" v-append="threeDHtmlContent" class="three-d" />
                         </div>
                       </div>
                   </form>
             </div>
        </section>
  </div>
</template>

<script>
import {POSITION} from "vue-toastification";

const pageName = 'Bakiye Yükle | Kredi Kartı'

export default {
  name: 'companyDepositCCPage',

  head() {
    return {
      title: this.getTitle
    }
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
      funds: 0,
      amount: 40,
      isPaymentButtonLoading: false,
      threeDHtmlContent: '',
      companyInfo: {
        companyLogo: "",
        companyName: "",
        name: "",
        phoneNumber: "",
        surname: "",
        taxAdministration: "",
        taxNumber: "",
        userId: "",
        funds: 0,
      },
      ccModel: {
        name: '',
        number: '',
        exp: '',
        cvc: '',
        billingAddress: '',
        city: ''
      },
      threeDStyle: {
        height: '70vh'
      }
    }
  },

  mounted() {
    this.checkIsLoggedIn()
    this.getFunds()
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },

  watch: {
    threeDHtmlContent(val) {
      if(val)
        this.checkPaymentResult()
    }
  },

  methods: {
    getFunds() {
      let _this = this

      this.$axios.get(this.$store.state.apiBaseUrl + '/Payment/Get', {
        headers: {
          Authorization:
            "Bearer " + localStorage.yonetimFirmasiAccessToken,
        },
      })
        .then(res => {
          if(!res.data.data) {
            _this.funds = 0
            return
          }

          _this.funds = res.data.data.lastAmount
        })
        .catch(err => {
          _this.funds = 0
          console.error(err)
        })
    },

    checkIsLoggedIn() {
      let _this = this;

      if (localStorage.yonetimFirmasiAccessToken) {
        this.$axios
          .get(
            this.$store.state.apiBaseUrl +
            "/User/Get?UserId=" +
            localStorage.yonetimFirmasiUserId,
            {
              headers: {
                Authorization:
                  "Bearer " + localStorage.yonetimFirmasiAccessToken,
              },
            }
          )
          .then((res) => {
            _this.$store.commit('setIsLoggedIn', true)
            _this.companyInfo = Object.assign(_this.companyInfo, res.data.data);
          })
          .catch((err) => {
            _this.$router.push({
              path: "/firma-girisi",
            });
          });
      } else {
        this.$router.push({
          path: "/firma-girisi",
        });
      }
    },

    payment() {
      let _this = this

      let error = false
      Object.keys(this.ccModel).forEach(key => {
        if(!_this.ccModel[key])
          error = true
      })

      if(error) {
        _this.$toast.error("HATA: Lütfen tüm bilgileri doldurunuz!", {
          position: POSITION.BOTTOM_RIGHT,
        })
        return
      }

      this.isPaymentButtonLoading = true

      const cardNumber = this.ccModel.number.replace(/ /g, '')
      const expireMonth = this.ccModel.exp.split(' / ')[0]
      const expireYear = this.ccModel.exp.split(' / ')[1]

      this.$axios.post(this.$store.state.apiBaseUrl + '/Payment/Create', {
        country: "Türkiye",
        city: _this.ccModel.city,
        billingAddress: _this.ccModel.billingAddress,
        registrationAddress: _this.ccModel.billingAddress,
        cardHolderNameSurname: _this.ccModel.name,
        cardNumber: cardNumber,
        expireMonth: expireMonth,
        expireYear: expireYear,
        cvc: _this.ccModel.cvc,
        price: _this.amount.toString()
      }, {
        headers: {
          Authorization:
            "Bearer " + localStorage.yonetimFirmasiAccessToken,
        },
      })
        .then(res => {
          console.log(res.data)
          _this.isPaymentButtonLoading = false

          if(res.data.status === 'failure') {
            _this.$toast.error(`HATA: Bankanız ödemeye onay vermedi! Hata mesajı: ${res.data.errorMessage}`, {
              position: POSITION.BOTTOM_RIGHT,
            })

            return
          }

          _this.threeDHtmlContent = res.data.htmlContent

          /* _this.$toast.success("Bakiyeniz yüklendi, yönlendiriliyorsunuz...", {
            position: POSITION.BOTTOM_RIGHT,
          })

          setTimeout(() => _this.$router.push({
            path: "/firma/firsatlar-ve-teklifler",
          }), 3000) */
        })
        .catch(err => {
          console.error(err)
          _this.isPaymentButtonLoading = false

          _this.$toast.error("HATA: Bankanız ödemeye onay vermedi! Lütfen tüm bilgilerinizi kontrol ediniz.", {
            position: POSITION.BOTTOM_RIGHT,
          })
        })
    },

    checkPaymentResult() {

    }
  }
}
</script>
