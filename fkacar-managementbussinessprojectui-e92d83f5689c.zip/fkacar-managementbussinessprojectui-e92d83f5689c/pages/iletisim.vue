<template>
  <div class="mb-contact-page-container">
    <section class="page8-main-sec">
                <div class="container">
                   <div class="page8-heading d-flex">

                       <h6>Bize Ulaşın</h6>
                   </div>

                   <div class="row">
                       <div class="col-md-6 ">
                           <div class="col-left">



                                    <div class="form-group">
                                        <label >Ad Soyad</label>
                                        <input
                                          type="text"
                                          class="form-control  first-row-form2"
                                          placeholder="İsminiz"
                                          v-model="contactFormModel.name"
                                        >

                                      </div>
                                    <div class="form-group">
                                        <label>  Mail adresiniz</label>
                                        <div class="sticky-notes">


                                            <input
                                              class="form-control"
                                              type="text"
                                              placeholder="Mail adresiniz"
                                              name="email"
                                              v-model="contactFormModel.email"
                                            >
                                            <span><img src="/images/icons/email-icon.svg" alt="emial-icon"></span></div>

                                  </div>





                                   <div class="form-group detail-textbox">

                                        <label >Eklemek istediğiniz mesajınız</label>
                                        <div class="sticky-notes">
                                        <textarea
                                          class="form-control"
                                          rows="7"
                                          placeholder="Mesajınız"
                                          v-model="contactFormModel.message"
                                        ></textarea>
                                        <span> <img src="/images/icons/sticky-note.svg" alt="sticky-notesicon"></span>
                                        </div>
                                      </div>

                             <ul class="ul-icons">
                               <li class="d-flex">
                                 <label class="check ">
                                   <input type="checkbox" v-model="contactFormModel.kvkkAccepted">
                                   <span class="checkmark"></span>
                                 </label>
                                 <div class="text-box pt-2">
                                   <p> <NuxtLink target="_blank" to="/kisisel-verilerin-korunmasi">Kişisel Verilerin Korunması Hakkında Açıklama ve Gizlilik Politikası</NuxtLink>'nı okudum, onaylıyorum.</p>
                                 </div>
                               </li>
                             </ul>




                            <button @click="submitForm" type="button" class="btn mt-5">GÖNDERİN
                                <img src="/images/icons/paper-plane.svg" alt="submit-arrow" class="img-fluid">
                            </button>



                       </div>
                       </div>
                       <div class="col-md-6">
                           <div class="col-right" style="text-align: center;width: 100%">
                               <div class="image-holder">
                                   <img src="/images/page8-main-img.png" alt="main-img" class="img-fluid">
                               </div>
                               <ul class="pl-5">
                                   <li class="d-flex pl-4">
                                    <img src="/images/icons/email-icon.svg" alt="email-icon" class="img-fluid">

                                       <p><a href="mailto:destek@yonetimfirmasi.com" style="color:black;">destek@yonetimfirmasi.com</a></p>
                                    </li>
                                    <!--<li class="d-flex">
                                        <img src="/images/icons/phone-icon.svg" alt="email-icon" class="img-fluid">

                                           <p>0 (212) 434 44 22 </p>
                                        </li>-->
                               </ul>

                           </div>
                    </div>
                   </div>



                </div>
           </section>
  </div>
</template>

<script>
import {POSITION} from "vue-toastification";

const pageName = 'İletişim'

export default {
  name: 'contactPage',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
      contactFormModel: {
        name: '',
        email: '',
        message: '',
        kvkkAccepted: false,
      }
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },

  methods: {
    validateForm() {
      let errMsg = ''
      if(!this.contactFormModel.name) {
        errMsg = 'Ad Soyad alanı boş geçilemez!'
      }
      if(!this.contactFormModel.email) {
        errMsg = 'Mail adresiniz alanı boş geçilemez!'
      }
      if(!this.contactFormModel.message) {
        errMsg = 'Eklemek istediğiniz mesajınız alanı boş geçilemez!'
      }
      if(!this.contactFormModel.kvkkAccepted) {
        errMsg = 'Kişisel Verilerin Korunması koşullarını kabul etmelisiniz!'
      }

      if(errMsg) {
        this.$toast.error('HATA: ' + errMsg, { position: POSITION.BOTTOM_RIGHT })
        return false
      }

      return true
    },

    submitForm() {
      let _this = this
      if(!this.validateForm()) return

      this.$axios.post(this.$store.state.apiBaseUrl + '/Contact/Create', {
        nameSurname: this.contactFormModel.name,
        email: this.contactFormModel.email,
        messageContent: this.contactFormModel.message,
      })
        .then(res =>  {
          console.log(res)
        })
        .catch(err => {
          _this.$toast.error('HATA: Beklenmedik bir hata oluştu!', { position: POSITION.BOTTOM_RIGHT })
        })

      this.$toast.success('Mesajınız gönderildi. En kısa sürede size dönüş sağlayacağız...', { position: POSITION.BOTTOM_RIGHT })
      this.contactFormModel.name = ''
      this.contactFormModel.email = ''
      this.contactFormModel.message = ''
    }
  }
}
</script>
