<template>
  <div class="mb-get-offer-step-3-page-container">
    <div class="hero-page-1">
                <div class="container ">
                    <div class="row">
                        <div class="col col-6 hero-page-1-text">
                            <h1>Teklif Alın!</h1>

                        </div>
                        <div class="col col-6 hero-page-1-img ml-auto">
                            <img src="/images/hero-subpages-main-img.png" alt="subpages-hero-img" class="img-fluid">

                        </div>
                    </div>



                    </div>
                    <hr>
                    </div>
                    <section class="page-3-main-sec">
                        <div class="container">
                        <div class="row ">
                            <div class="col-md-6">
                                <div class="data-ul">

                                        <div class="col-12">
                                            <div class="form-group">
                                                <label >Ad Soyad</label>
                                                <input
                                                  type="text"
                                                  class="form-control first-row-form2"
                                                  placeholder="İsminiz"
                                                  v-model="offerModel.name"
                                                >
                                              </div>
                                            </div>


                                            <div class="col-12">
                                                <div class="form-group">
                                                    <div class="sticky-notes">
                                                      <label>  Mail adresiniz</label>
                                                <input
                                                  class="form-control"
                                                  type="text"
                                                  placeholder="Mail adresiniz"
                                                  v-model="offerModel.email"
                                                >
                                                <span><img src="/images/icons/email-icon.svg" alt="emial-icon"></span></div>
                                              </div>
                                              </div>

                                              <div class="col-12">
                                                <div class="form-group">
                                                    <div class="sticky-notes">
                                                      <label> Telefon Numaranız</label>
                                                <input
                                                  class="form-control"
                                                  type="text"
                                                  placeholder="(5xx) xxx xxxx"
                                                  v-model="offerModel.phoneNumber"
                                                >
                                                <span><img src="/images/icons/phone-icon.svg" alt="emial-icon"></span></div>
                                              </div>
                                              </div>

                                </div>
                                <h5>Sizinle nasıl iletişime
                                    geçmemizi istersiniz?</h5>
                                    <ul class="d-flex ul-checkboxes">
                                        <li>
                                            <label class="radio ">
                                                <input
                                                  type="radio"
                                                  value="1"
                                                  v-model="offerModel.contactType"
                                                >
                                               <span> E-Mail</span>
                                              <span class="checkround"></span>
                                            </label>
                                        </li>
                                        <li>
                                            <label class="radio ">
                                                <input
                                                  type="radio"
                                                  value="2"
                                                  v-model="offerModel.contactType"
                                                >
                                                <span>Telefon</span>
                                              <span class="checkround  "></span>
                                            </label>
                                        </li>
                                    </ul>

                              <div class="form-group">
                                <div class="sticky-notes detail-textbox">
                                <label >Talep Geçerlilik Süresi</label>
                                  <select
                                    class="form-control"
                                    style="height: 53px;border: 1px solid #280B65;background: rgba(40, 11, 101, 0.03);"
                                    v-model="offerModel.expirationTime"
                                  >
                                    <option value="15">15 gün</option>
                                    <option selected value="30">1 Ay</option>
                                    <option value="60">2 Ay</option>
                                    <option value="90">3 Ay</option>
                                    <option value="180">6 Ay</option>
                                  </select>
                                </div>
                                <p style="font-size: 13px;margin-top: 3px" class="text-muted text-sm p-1">Talebinizin yönetim firmalarına gösterimi seçtiğiniz sürenin sonunda durdurulacaktır</p>
                              </div>

                                    <div class="form-group detail-textbox">

                                        <label >Eklemek istediğiniz mesajınız</label>
                                        <div class="sticky-notes">
                                        <textarea
                                          class="form-control"
                                          rows="6"
                                          placeholder="Mesajınız"
                                          v-model="offerModel.message"
                                        >
                                        </textarea>
                                        <span> <img src="/images/icons/sticky-note.svg" alt="sticky-notesicon"></span>
                                        </div>
                                      </div>

                                      <ul class="ul-icons pt-2">
                                        <li class="d-flex">
                                          <label class="check ">
                                            <input type="checkbox" v-model="offerModel.kvkkAccepted">
                                            <span class="checkmark"></span>
                                          </label>
                                          <div class="text-box">
                                            <p> <NuxtLink target="_blank" to="/kisisel-verilerin-korunmasi">Kişisel Verilerin Korunması Hakkında Açıklama ve Gizlilik Politikası</NuxtLink>'nı okudum, onaylıyorum.</p>
                                          </div>
                                        </li>
                                      </ul>

                                      <div class="row">
                                        <div class="col-md-4">
                                           <div class="form-group ">
                                            <NuxtLink class="btn btn-left back-btn" to="/teklif-al/asama-2">
                                              <img src="/images/icons/left-side-arrow.png" alt="submit-arrow" class="img-fluid" style="float: left">
                                              &nbsp;&nbsp;&nbsp;&nbsp;GERİ
                                            </NuxtLink>
                                          </div>
                                        </div>
                                        <div class="col-md-8">
                                          <div class="form-group ">
                                           <!-- <NuxtLink class="btn" to="/teklif-al/basarili">
                                              FORMU GÖNDER
                                              <img src="/images/icons/forward-arrow-icon.png" alt="submit-arrow" class="img-fluid">
                                            </NuxtLink>-->
                                            <a @click="onNextBtn" class="btn">
                                              FORMU GÖNDER
                                              &nbsp;&nbsp;&nbsp;&nbsp;
                                              <img src="/images/icons/forward-arrow-icon.png" alt="submit-arrow" class="img-fluid">
                                            </a>
                                          </div>
                                        </div>
                                      </div>

                            </div>
                            <div class="col-md-6 sec3-img">
                                <img src="/images/page3-main-img.png" alt="main-img" class="img-fluid">
                            </div>
                            </div>
                            </div>
                            </section>
  </div>
</template>

<script>
import {POSITION} from "vue-toastification";

const pageName = 'Teklif Al | 3'

export default {
  name: 'getOfferStep3Page',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
      offerModel: {
        name: '',
        email: '',
        phoneNumber: '',
        contactType: '',
        message: '',
        kvkkAccepted: false,
        expirationTime: '30'
      }
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },

  methods: {
    onNextBtn() {
      let _this = this
      if(!this.validateForm()) return

      this.$store.commit('setOfferModel',
        Object.assign({}, this.offerModel, this.$store.state.offerModel))

      this.$axios.post(this.$store.state.apiBaseUrl + '/Offer', {
        offerTypeId: this.$store.state.offerModel.offerType,
        blockNo: parseInt(this.$store.state.offerModel.complexCount),
        numberOfEpisod: parseInt(this.$store.state.offerModel.independentDepartmentCount),
        apartmentName: this.$store.state.offerModel.buildingName,
        cityId: parseInt(this.$store.state.offerModel.city),
        townId: parseInt(this.$store.state.offerModel.town),
        neighborhoodId: parseInt(this.$store.state.offerModel.neighborhood),
        mainStreetName: this.$store.state.offerModel.avenue,
        streetName: this.$store.state.offerModel.street,
        numberOfPerson: parseInt(this.$store.state.offerModel.employeeCount),
        nameSurname: this.$store.state.offerModel.name,
        email: this.$store.state.offerModel.email,
        telephone: this.$store.state.offerModel.phoneNumber,
        message: this.$store.state.offerModel.message,
        contactType: parseInt(this.$store.state.offerModel.contactType),
        offerServiceTypeIdList: this.$store.state.offerModel.offerServiceType,
        expirationTime: parseInt(this.$store.state.offerModel.expirationTime)
      })
          .then(res =>  {
            console.log(res)
          })

      this.$router.push({
        path: '/teklif-al/basarili'
      })
    },

    validateForm() {
      let errMsg = ''
      if(!this.offerModel.name) {
        errMsg = 'Ad Soyad alanı boş geçilemez!'
      }
      if(!this.offerModel.email) {
        errMsg = 'Mail adresiniz alanı boş geçilemez!'
      }
      if(!this.validateEmail(this.offerModel.email)) {
        errMsg = 'Mail adresiniz hatalı, lütfen kontrol ediniz!'
      }
      if(!this.offerModel.phoneNumber) {
        errMsg = 'Telefon numaranız alanı boş geçilemez!'
      }
      if(!this.offerModel.contactType) {
        errMsg = 'İletişim tercihi seçeneklerinden birini seçmelisiniz!'
      }
      if(!this.offerModel.kvkkAccepted) {
        errMsg = 'Kişisel Verilerin Korunması koşullarını kabul etmelisiniz!'
      }

      if(errMsg) {
        this.$toast.error('HATA: ' + errMsg, { position: POSITION.BOTTOM_RIGHT })
        return false
      }

      return true
    },

    validateEmail(email) {
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
  }
}
</script>

<style scoped>
.back-btn {
  padding: 12px 28px 12px 17px !important;
  font-style: normal !important;
  font-weight: bold !important;
  font-size: 20px !important;
  line-height: 27px !important;
  border: 1px solid #868686 !important;
  box-sizing: border-box !important;
  border-radius: 12px !important;
  color: #868686 !important;
  background: transparent !important;
}

.back-btn img {
  margin-left: -10px !important;
}
</style>
