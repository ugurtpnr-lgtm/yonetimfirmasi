<template>
  <div class="mb-get-offer-step-2-page-container">
    <div class="hero-page-1">
                <div class="container ">
                    <div class="row">
                        <div class="col col-6 hero-page-1-text">
                            <h1>Teklif Alın!</h1>

                        </div>
                        <div class="col col-6 hero-page-1-img ml-auto">
                            <img src="/images/hero-subpages-main-img.png" alt="subpages-hero-img" class="img-fluid">

                        </div>
                    </div>



                    </div>
                    <hr>
                    </div>

                    <section class="page-2-main-sec">
                        <div class="container">
                        <div class="row ">
                            <div class="col-md-8">
                                <ul class="ul-icons">
                                    <li class="d-flex">
                                        <label class="check ">
                                            <input type="checkbox"  value="9d9c2676-1de8-4a9a-8f95-08d908f142e6" v-model="offerServiceType">
                                          <span class="checkmark"></span>
                                        </label>
                                        <img src="/images/icons/page2-icon1.png" alt="icon-1" class="img-fluid ">
                                        <div class="text-box">
                                            <h6>Profesyonel Yöneticilik</h6>
                                               <p> KMK uyarınca tüm yöneticilik görevleri, muhasebe, bakım onarım, hukuki danışmanlık</p>
                                        </div>
                                    </li>
                                    <li class="d-flex">
                                        <label class="check ">
                                            <input type="checkbox" value="09eef912-22bc-4800-8f96-08d908f142e6" v-model="offerServiceType">
                                          <span class="checkmark"></span>
                                        </label>
                                        <img src="/images/icons/page2-icon2.png" alt="icon-2" class="img-fluid ">
                                        <div class="text-box">
                                            <h6>Muhasebe Hizmeti </h6>
                                                <p>  Aidat takip, tahsilat ve muhasebe hizmetleri</p>

                                        </div>
                                    </li>
                                    <li class="d-flex">
                                        <label class="check ">
                                            <input type="checkbox" value="a009ffa4-0f11-4e71-8f97-08d908f142e6" v-model="offerServiceType">
                                          <span class="checkmark"></span>
                                        </label>
                                        <img src="/images/icons/page2-icon3.png" alt="icon-3" class="img-fluid ">
                                        <div class="text-box">
                                           <h6> Personel Yönetimi </h6>
                                             <p> Personel sevk, idaresi ve maaş, sgk takip işlemleri</p>
                                        </div>
                                    </li>
                                    <li class="d-flex">
                                        <label class="check ">
                                            <input type="checkbox" value="ed0882e8-090b-4663-8f98-08d908f142e6" v-model="offerServiceType">
                                          <span class="checkmark"></span>
                                        </label>
                                        <img src="/images/icons/page2-icon4.png" alt="icon-4" class="img-fluid ">
                                        <div class="text-box">
                                            <h6>Bakım-Onarım Hizmeti</h6>
                                           <p>Elektrik, sıhhi tesisat, kazan, bahçe vb.</p>
                                        </div>
                                    </li>
                                    <li class="d-flex">
                                        <label class="check ">
                                            <input type="checkbox" value="f00de516-f344-40e9-8f99-08d908f142e6" v-model="offerServiceType">
                                          <span class="checkmark"></span>
                                        </label>
                                        <img src="/images/icons/page2-icon5.png" alt="icon-5" class="img-fluid ">
                                        <div class="text-box">
                                           <h6> Hukiki Danışmanlık</h6>
                                               <p>Avukatlık Hizmetleri</p>
                                        </div>
                                    </li>
                                </ul>
                                <ul class="ul-btn">
                                    <li>
                                <div class="col-auto">
                                    <div class="form-group ">
                                      <NuxtLink class="btn btn-left" to="/teklif-al/asama-1">
                                        <img src="/images/icons/left-side-arrow.png" alt="submit-arrow" class="img-fluid">
                                        GERİ
                                      </NuxtLink>
                                    </div>
                                  </div>
                                  </li>
                                  <li>
                                  <div class="col-auto">
                                    <div class="form-group ">
                                      <!--<NuxtLink class="btn btn-right" to="/teklif-al/asama-3">
                                        İLERİ
                                        <img src="/images/icons/submit-arrow.png" alt="submit-arrow" class="img-fluid">
                                      </NuxtLink>-->
                                      <a @click="onNextBtn" class="btn btn-right">
                                        İLERİ
                                        <img src="/images/icons/submit-arrow.png" alt="submit-arrow" class="img-fluid">
                                      </a>
                                    </div>
                                  </div>
                                  </li>
                                  </ul>
                        </div>
                        <div class="col-md-4 img-main">
                            <img src="/images/page2-main-sec-img.png" alt="main-img" class="img-fluid">
                        </div>
                        </div>
                        </div>
                    </section>
  </div>
</template>

<script>
import {POSITION} from "vue-toastification";

const pageName = 'Teklif Al | 2'

export default {
  name: 'getOfferStep2Page',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
      offerServiceType: [],
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },

  methods: {
    onNextBtn() {
      if(!this.validateForm()) return

      this.$store.commit('setOfferModel',
        Object.assign({}, {offerServiceType: this.offerServiceType}, this.$store.state.offerModel))

      this.$router.push({
        path: '/teklif-al/asama-3'
      })
    },

    validateForm() {
      let errMsg = ''
      if(!this.offerServiceType.length) {
        errMsg = 'En az 1 adet hizmet seçmelisiniz!'
      }

      if(errMsg) {
        this.$toast.error('HATA: ' + errMsg, { position: POSITION.BOTTOM_RIGHT })
        return false
      }

      return true
    }
  }
}
</script>
