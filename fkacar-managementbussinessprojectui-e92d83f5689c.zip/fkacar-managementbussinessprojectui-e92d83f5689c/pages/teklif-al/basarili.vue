<template>
  <div class="mb-get-offer-success-page-container">
    <div class="page5-main-sec">
                <div class="container">
                <div class="card ">
                    <div class="image-holder">
                    <img
                      class="card-img img-fluid"
                      src="/images/page5-main-img.png"
                      alt="Card image cap"
                      style="margin-left:30%"
                    >
                    </div>
                    </div>
                    <div class="text-box">
                        <h5>Teşekkürler,</h5>
                        <p>
                            Formunuz bize ulaştı. Size en kısa sürede<br>
                                  <span>tekliflerle</span> geri dönüş sağlayacağız.
                        </p>
                    </div>
            </div>
            </div>
  </div>
</template>

<script>
const pageName = 'Teklif Al | Başarılı'

export default {
  name: 'getOfferSuccessPage',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 200, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },
}
</script>
