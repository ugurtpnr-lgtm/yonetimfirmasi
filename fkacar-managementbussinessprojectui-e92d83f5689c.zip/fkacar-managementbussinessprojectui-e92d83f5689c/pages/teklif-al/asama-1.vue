<template>
  <div class="mb-get-offer-step-1-page-container">
    <div class="hero-page-1">
                <div class="container ">
                    <div class="row">
                        <div class="col col-6 hero-page-1-text">
                            <h1>Teklif Alın!</h1>

                        </div>
                        <div class="col col-6 hero-page-1-img ml-auto">
                            <img src="/images/hero-subpages-main-img.png" alt="subpages-hero-img" class="img-fluid">

                        </div>
                    </div>



                    </div>
                    <hr>
                    </div>
                   <section class="page-1-main-sec">
                       <div class="container">
                       <div class="row">
                           <div class="col-md-8">
                               <ul class="row">
                                   <li  class="col-md-4 col-sm-4 col-6 pt-15">
                                       <img src="/images/icons/appartment -icon.png" alt="appartment-icon" class="image-fluid">
                                       <label class="radio">
                                        <input type="radio" id="building-radio" value="95299a76-4e07-4c62-8b1f-08d908f142de" v-model="offerModel.offerType">
                                        Apartman
                                      <span class="checkround"></span>
                                    </label>

                                   </li>
                                   <li class="col-md-4 col-sm-4 col-6">
                                    <img src="/images/icons/site-icon.png " alt="site-icon" class="image-fluid">
                                    <label class="radio ">
                                     <input type="radio" checked="checked" id="complex-radio" value="19a5c618-8a66-46a7-8b20-08d908f142de" v-model="offerModel.offerType">
                                     Site
                                   <span class="checkround"></span>
                                 </label>

                                </li>
                                <li class="col-md-4 col-sm-4 col-12 pt-6">
                                    <img src="/images/icons/market-icon.png " alt="market-icon" class="image-fluid">
                                    <label class="radio">
                                     <input type="radio"  id="business-center-radio" value="8beb1200-142e-4d80-8b21-08d908f142de" v-model="offerModel.offerType">
                                     İş Merkezi
                                   <span class="checkround"></span>
                                 </label>

                                </li>
                               </ul>
                               <form>
                                   <div class="row page-1-form-row">
                                       <div class="col-sm-4 col-md-6 col-12">
                                        <div class="form-group">
                                            <label >Blok Sayısı</label>
                                            <input v-model="offerModel.complexCount" type="number" class="form-control  first-row-form" placeholder="5" >
                                          </div>
                                        </div>
                                        <div class="col-sm-4 col-md-6 col-12">
                                          <div class="form-group ">
                                            <label >Bağımsız Bölüm Sayısı</label>
                                            <input v-model="offerModel.independentDepartmentCount" type="number" class="form-control first-row-form " placeholder="436">
                                          </div>
                                       </div>
                                       <div class="col-md-12 col-sm-10 col-12">
                                        <div class="form-group">
                                            <label >Apartman / Site İsmi</label>
                                            <input v-model="offerModel.buildingName" type="text" class="form-control  first-row-form2" placeholder="Myia Bahçe Sitesi" >
                                          </div>
                                        </div>
                                        <div class="col-sm-4 col-md-6 col-12">
                                            <div class="form-group ">
                                                <label>İl</label>
                                                <select
                                                  class="form-control"
                                                  style="height: 53px"
                                                  v-model="offerModel.city"
                                                  @change="getTowns"
                                                >
                                                    <option selected value="">--- SEÇİNİZ ---</option>
                                                    <option
                                                      v-for="city in cities"
                                                      :key="city.id"
                                                      :value="city.id"
                                                    >{{ city.name }}
                                                    </option>

                                                  </select>
                                            </div>
                                         </div>
                                         <div class="col-sm-4 col-md-6 col-12">
                                            <div class="form-group ">
                                                <label>İlçe</label>
                                                <select
                                                  class="form-control"
                                                  style="height: 53px"
                                                  v-model="offerModel.town"
                                                  @change="getNeighborhoods"
                                                >
                                                    <option selected value="">--- SEÇİNİZ ---</option>
                                                    <option
                                                        v-for="town in towns"
                                                        :key="town.id"
                                                        :value="town.id"
                                                    >{{ town.name }}
                                                    </option>

                                                  </select>
                                            </div>
                                         </div>
                                         <div class="col-sm-4 col-md-6 col-12">
                                            <div class="form-group ">
                                                <label>Mahalle</label>
                                                <select
                                                  class="form-control"
                                                  style="height: 53px"
                                                  v-model="offerModel.neighborhood"
                                                >
                                                    <option selected value="">--- SEÇİNİZ ---</option>
                                                    <option
                                                        v-for="neighborhood in neighborhoods"
                                                        :key="neighborhood.id"
                                                        :value="neighborhood.id"
                                                    >{{ neighborhood.name }}
                                                    </option>

                                                  </select>
                                            </div>
                                         </div>
                                        <div class="col-sm-4 col-md-6 col-12">
                                            <div class="form-group ">
                                              <label >Cadde</label>
                                              <input type="text" class="form-control" placeholder="4534" v-model="offerModel.avenue">
                                            </div>
                                         </div>
                                         <div class="col-sm-4 col-md-6 col-12">
                                            <div class="form-group ">
                                              <label >Sokak</label>
                                              <input type="text" class="form-control" placeholder="5424" v-model="offerModel.street">
                                            </div>
                                         </div>
                                         <div class="col-sm-4 col-md-6 col-12"></div>
                                         <div class="col-sm-4 col-md-6 col-12">
                                            <div class="form-group ">
                                                <label>Çalışan Sayısı</label>
                                                <input type="number" class="form-control" placeholder="5424" v-model="offerModel.employeeCount">
                                            </div>
                                         </div>
                                         <div class="col-sm-4 col-md-6 col-12"></div>
                                         <div class="col-sm-4 col-md-6 col-12"></div>
                                         <div class=" col-sm-4 col-6">
                                            <div class="form-group ">
                                              <!--<NuxtLink class="btn" to="/teklif-al/asama-2">
                                                 İLERİ
                                                 <img src="/images/icons/submit-arrow.png" alt="submit-arrow" class="img-fluid">
                                               </NuxtLink>-->
                                              <a @click="onNextBtn" class="btn">
                                                İLERİ
                                                <img src="/images/icons/submit-arrow.png" alt="submit-arrow" class="img-fluid">
                                              </a>
                                            </div>
                                          </div>

                                   </div>
                               </form>

                           </div>


                           <div class="col-md-4 side-img">
                               <img src="/images/page-1-main-img.png" alt="main-img" class="img-fluid">
                           </div>
                       </div>
                    </div>

                   </section>
  </div>
</template>

<script>
import {POSITION} from "vue-toastification";

const pageName = 'Teklif Al | 1'

export default {
  name: 'getOfferStep1Page',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
    this.getCities()
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
      cities: [],
      towns: [],
      neighborhoods: [],
      offerModel: {
        offerType: '',
        complexCount: 0,
        independentDepartmentCount: 0,
        buildingName: '',
        city: '',
        town: '',
        neighborhood: '',
        avenue: '',
        street: '',
        employeeCount: 0,
      }
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },

  methods: {
    getCities() {
      let _this = this

      this.$axios.post(this.$store.state.apiBaseUrl + '/City', {})
          .then(res =>  {
            _this.cities = res.data.data
          })
    },

    getTowns() {
      let _this = this

      this.$axios.post(this.$store.state.apiBaseUrl + '/Town', {
        cityId: this.offerModel.city
      })
          .then(res =>  {
            _this.towns = res.data.data
          })
    },

    getNeighborhoods() {
      let _this = this

      this.$axios.post(this.$store.state.apiBaseUrl + '/Neighborhood', {
        townId: this.offerModel.town
      })
          .then(res =>  {
            _this.neighborhoods = res.data.data
          })
    },

    onNextBtn() {
      if(!this.validateForm()) return

      this.$store.commit('setOfferModel',
        Object.assign({}, this.offerModel, this.$store.state.offerModel))

      this.$router.push({
        path: '/teklif-al/asama-2'
      })
    },

    validateForm() {
      let errMsg = ''
      if(!this.offerModel.offerType) {
        errMsg = 'Apartman, Site yada İş Merkezi seçeneklerinden herhangi birini seçmelisiniz!'
      }
      if(!this.offerModel.complexCount) {
        errMsg = 'Blok Sayısı alanı boş geçilemez!'
      }
      if(!this.offerModel.independentDepartmentCount) {
        errMsg = 'Bağımsız Bölüm Sayısı alanı boş geçilemez!'
      }
      if(!this.offerModel.buildingName) {
        errMsg = 'Apartman / Site İsmi alanı boş geçilemez!'
      }
      if(!this.offerModel.city) {
        errMsg = 'Şehir alanı boş geçilemez!'
      }
      if(!this.offerModel.town) {
        errMsg = 'İlçe alanı boş geçilemez!'
      }
      if(!this.offerModel.neighborhood) {
        errMsg = 'Mahalle alanı boş geçilemez!'
      }
      if(!this.offerModel.street) {
        errMsg = 'Sokak alanı boş geçilemez!'
      }

      if(errMsg) {
        this.$toast.error('HATA: ' + errMsg, { position: POSITION.BOTTOM_RIGHT })
        return false
      }

      return true
    }
  }
}
</script>
