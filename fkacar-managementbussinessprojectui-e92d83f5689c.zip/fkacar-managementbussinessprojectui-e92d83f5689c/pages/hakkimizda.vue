<template>
  <div id="about-page-container">
    <div class="mb-get-offer-step-2-page-container">
      <div class="hero-page-1">
        <div class="container ">
          <div class="row">
            <div class="col-sm-12">
              YonetimFirması, 2021 yılında basit ama çok güçlü bir soruyla yola çıktı:
              Kaliteli hizmet verenler yönetim firmalarına nasıl kolayca ulaşabilirim?
              Semtimde yaşayan en iyi hizmet veren yönetim firmalarını sokak sokak dolaşmadan ya da tanıdıklara sormadan bulmanın bir yolu olmalı!

              Bu büyük ihtiyaçtan yola çıkan platformumuz, üstün teknolojisi, kaliteli profesyonelleri ve gerçek müşteri yorumları sayesinde hızla büyüdü.
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
const pageName = 'Hakkımızda'

export default {
  name: 'AboutPage',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },
}
</script>

<style>
#about-page-container {
  height: 47vh;
}

.hero-page-1 {
  background: none !important;
}
</style>
