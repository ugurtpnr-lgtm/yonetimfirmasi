<template>
  <div class="mb-register-page-container">
    <div class="hero-page-1">
                <div class="container ">
                    <div class="row">
                        <div class="col col-6 hero-page-1-text">
                            <h1>Üye Ol</h1>

                        </div>
                        <div class="col col-6 hero-page-1-img ml-auto">
                            <img src="/images/page7-head-img.png" alt="subpages-hero-img" class="img-fluid">

                        </div>
                    </div>



                    </div>
                    <hr>
                    </div>
                    <section class="page7-main-sec">
                        <div class="container">
                        <div class="row ">
                            <div class="col-md-6">

                                        <div class="col-12">
                                            <div class="form-group">
                                                <label >Firma Adı</label>
                                                <input
                                                  type="text"
                                                  class="form-control  first-row-form2"
                                                  placeholder="Yönetim firmanız"
                                                  v-model="registerModel.companyName"
                                                >
                                              </div>
                                            </div>

                                            <ul class="d-flex">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label >Vergi Dairesi</label>
                                                        <select
                                                          class="form-control"
                                                          style="height: 53px;border: 1px solid #280B65;background: rgba(40, 11, 101, 0.03);"
                                                          v-model="registerModel.taxAdministration"
                                                        >
                                                          <option selected value="">--- SEÇİNİZ ---</option>
                                                          <option
                                                            v-for="taxAdmin in taxAdmins"
                                                            :key="taxAdmin.id"
                                                            :value="taxAdmin.id"
                                                          >{{ taxAdmin.name }}
                                                          </option>
                                                        </select>
                                                      </div>
                                                    </div>

                                                <div class="col-6">
                                                    <div class="form-group">
                                                        <label >Vergi No</label>
                                                        <input
                                                          type="number"
                                                          class="form-control"
                                                          placeholder="Vergi Numaranız"
                                                          v-model="registerModel.taxNumber"
                                                          @input="maxLengthCheck(10, 'taxNumber')"
                                                        >
                                                      </div>
                                                    </div>



                                            </ul>
                              <ul class="d-flex">
                                <div class="col-sm-12">
                                  <div class="form-group">
                                    <label >Hizmet Vermek İstediğiniz Lokasyonlar</label>
                                    <select
                                      class="form-control"
                                      style="height: 53px;border: 1px solid #280B65;background: rgba(40, 11, 101, 0.03);"
                                      v-model="serviceLocationCity"
                                      @change="addServiceLocation"
                                    >
                                      <option selected value="">--- SEÇİNİZ ---</option>
                                      <option
                                        v-for="city in cities"
                                        :key="city.id"
                                        :value="city.id"
                                      >{{ city.name }}
                                      </option>
                                    </select>
                                    <div
                                      class="service-locations-box"
                                    >
                                      <p
                                        v-for="location in serviceLocations"
                                        :key="location.id"
                                        @click="removeServiceLocation(location.id)"
                                      >
                                        {{ location.name }}
                                      </p>
                                    </div>
                                    <p style="font-size: 13px;margin-top: 3px" class="text-muted text-sm p-1">Lokasyonlarınız yukarıdaki kutucukta listelenmiştir. Eğer varsa, listeden çıkartmak istediğiniz lokasyonun üzerine tıklayabilirsiniz.</p>
                                  </div>
                                </div>
                              </ul>
                                            <ul class="d-flex">

                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label >Soyadınız</label>
                                                        <input
                                                          type="text"
                                                          class="form-control"
                                                          placeholder="Soyadınız"
                                                          v-model="registerModel.surname"
                                                        >
                                                      </div>
                                                    </div>


                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label >Adınız</label>
                                                        <input
                                                          type="text"
                                                          class="form-control"
                                                          placeholder="Adınız"
                                                          v-model="registerModel.name"
                                                        >
                                                      </div>
                                                    </div>

                                            </ul>

<ul>

                                            <li>

                                            <div class="col-12">
                                                <div class="form-group">
                                                    <div class="sticky-notes">
                                                      <label>  Mail adresiniz</label>
                                                <input
                                                  class="form-control"
                                                  type="text"
                                                  placeholder="Mail adresiniz"
                                                  v-model="registerModel.email"
                                                >
                                                <span><img src="/images/icons/email-icon.svg" alt="emial-icon"></span></div>
                                              </div>
                                              </div>
                                              </li>
                                              <li>
                                              <div class="col-12">
                                                <div class="form-group">
                                                    <div class="sticky-notes">
                                                      <label> Cep Telefon Numaranız</label>
                                                <input
                                                  class="form-control"
                                                  type="text"
                                                  placeholder="(5xx) xxx xxxx"
                                                  v-model="registerModel.phoneNumber"
                                                  v-mask="'(###) ### ## ##'"
                                                >
                                                <span><img src="/images/icons/phone-icon.svg" alt="emial-icon"></span></div>
                                                  <p style="font-size: 13px;margin-top: 3px" class="text-muted text-sm p-1">Lütfen telefon numaranızı başında 0 olmadan yazınız. Yalnızca cep telefonu numaranızı yazınız.</p>
                                              </div>
                                              </div>
                                    </li>
                                </ul>


                                <ul class="d-flex">

                                    <div class="col-md-6">
                                        <div class="form-group">
                                          <label >Şifreniz</label>
                                            <input
                                              type="password"
                                              class="form-control"
                                              placeholder="*********"
                                              v-model="registerModel.password"
                                              @keyup.enter="onRegister"
                                            >
                                          </div>
                                        </div>


                                    <div class="col-md-6">
                                        <div class="form-group">
                                          <label >Şifreniz (Tekrar)</label>
                                            <input
                                              type="password"
                                              class="form-control"
                                              placeholder="*********"
                                              v-model="registerModel.passwordAgain"
                                              @keyup.enter="onRegister"
                                            >
                                          </div>
                                        </div>

                                </ul>

                              <p style="font-size: 13px;margin-top: -20px" class="text-muted text-sm p-3">
                                Şifreniz en az 1 büyük harf, 1 küçük harf, 1 rakam ve 1 sembol (! . , ^ # + $ % & ( ) * ? - _) içermelidir ve en az 8 karakter uzunluğunda olmalıdır.
                              </p>

                              <ul class="ul-icons">
                                <li class="d-flex">
                                  <label class="check ">
                                    <input type="checkbox" v-model="registerModel.kvkkAccepted">
                                    <span class="checkmark"></span>
                                  </label>
                                  <div class="text-box pt-4">
                                    <p> <NuxtLink target="_blank" to="/kisisel-verilerin-korunmasi">Kişisel Verilerin Korunması Hakkında Açıklama ve Gizlilik Politikası</NuxtLink>'nı okudum, onaylıyorum.</p>
                                  </div>
                                </li>
                              </ul>

                                      <div class="col-md-6 mt-5">
                                        <a @click="onRegister" class="btn">
                                          ÜYE OL
                                          <img src="/images/icons/submit-arrow.png" alt="submit-arrow" class="img-fluid">
                                        </a>
                                      </div>

                            </div>
                            <div class="col-md-6 sec7-img">
                                <img src="/images/page7-main-sec-img.png" alt="main-img" class="img-fluid">
                            </div>
                            </div>
                            </div>
                    </section>
  </div>
</template>

<script>
import {POSITION} from "vue-toastification";

const pageName = 'Üye Ol'

export default {
  name: 'registerPage',

  head() {
    return {
      title: this.getTitle,
    }
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
      serviceLocationCity: '',
      serviceLocations: [],
      cities: [],
      taxAdmins: [],
      registerModel: {
        companyName: '',
        taxAdministration: '',
        taxNumber: '',
        surname: '',
        name: '',
        email: '',
        phoneNumber: '',
        password: '',
        passwordAgain: '',
        kvkkAccepted: false,
      }
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
    this.getCities()
    this.getTaxAdmins()
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },

  methods: {
    onRegister() {
      let _this = this
      if(!this.validateForm()) return

      this.$axios.post(this.$store.state.apiBaseUrl + '/Account/SignUp', {
        email: this.registerModel.email,
        password: this.registerModel.password,
        name: this.registerModel.name,
        surname: this.registerModel.surname,
        companyName: this.registerModel.companyName,
        phoneNumber: this.registerModel.phoneNumber.replace('(', '').replace(')', '').replace(/ /g, ''),
        taxAdministrationId: this.registerModel.taxAdministration,
        taxNumber: this.registerModel.taxNumber,
        companyLogo: null,
        cityIdList: this.serviceLocations.map(location => location.id),
        roleId: '00000000-0000-0000-0000-000000000002'
      })
        .then(res => {
          // _this.$toast.success('Kaydınız tamamlandı. SMS doğrulaması gerekmektedir. Lütfen bekleyiniz...', { position: POSITION.BOTTOM_RIGHT })
          _this.$toast.success('Kaydınız tamamlandı. Lütfen bekleyiniz...', { position: POSITION.BOTTOM_RIGHT })
          setTimeout(() => {
            _this.$router.push({
                path: '/firma-girisi'
            })

            // activate it to sms verification
            /* _this.$router.push({
                path: '/sms-dogrulama'
            }) */
          }, 3000)
        })
        .catch(err => {
          console.log(err)
          _this.$toast.error('HATA: Lütfen bilgilerizi kontrol ediniz!', { position: POSITION.BOTTOM_RIGHT })
        })
    },

    validateForm() {
      let _this = this
      let errMsg = ''
      if(!this.registerModel.companyName) {
        errMsg = 'Firma Adı alanı boş geçilemez!'
      }
      if(!this.registerModel.taxAdministration) {
        errMsg = 'Vergi Dairesi alanı boş geçilemez!'
      }
      if(!this.registerModel.taxNumber) {
        errMsg = 'Vergi No alanı boş geçilemez!'
      }
      if(this.registerModel.taxNumber.length < 10) {
        errMsg = 'Vergi numaranız 10 haneli olmalıdır!'
      }
      if(!this.registerModel.surname) {
        errMsg = 'Soyadınız alanı boş geçilemez!'
      }
      if(!this.registerModel.name) {
        errMsg = 'Adınız alanı boş geçilemez!'
      }
      if(!this.registerModel.email) {
        errMsg = 'Mail adresiniz alanı boş geçilemez!'
      }
      if(!this.validateEmail(this.registerModel.email)) {
        errMsg = 'Mail adresiniz hatalı, lütfen kontrol ediniz!'
      }
      if(!this.registerModel.phoneNumber) {
        errMsg = 'Telefon Numaranız adresiniz alanı boş geçilemez!'
      }
      if(this.registerModel.phoneNumber.length < 10) {
        errMsg = 'Telefon Numaranız çok kısa, lütfen kontrol ediniz!'
      }
      if(!this.registerModel.kvkkAccepted) {
        errMsg = 'Kişisel Verilerin Korunması koşullarını kabul etmelisiniz!'
      }
      if(!this.registerModel.password) {
        errMsg = 'Şifreniz alanı boş geçilemez!'
      }
      if(this.registerModel.password !== this.registerModel.passwordAgain) {
        errMsg = 'Şifreleriniz birbiriyle eşleşmiyor!'
      }
      if(this.registerModel.password.length < 8) {
        errMsg = 'Şifreniz 8 karakterden daha kısa olamaz!'
      }
      if(!this.serviceLocations.length) {
        errMsg = 'Hizmet Vermek İstediğiniz Lokasyonlar alanı boş geçilemez!'
      }

      const symbols = ['!','.',',','^','#','+','$','%','&','(',')','*','?','-','_']

      let numberPass = false
      for(let i = 0; i < this.registerModel.password.length; i++) {
        const char = this.registerModel.password[i]
        if(this.checkCharType(char) === 'N')
          numberPass = true
      }

      let letterPass = false
      for(let i = 0; i < this.registerModel.password.length; i++) {
        const char = this.registerModel.password[i]
        if(this.checkCharType(char) === 'U' || this.checkCharType(char) === 'L')
          letterPass = true
      }

      let upperCasePass = false
      for(let i = 0; i < this.registerModel.password.length; i++) {
        const char = this.registerModel.password[i]
        if(this.checkCharType(char) === 'U')
          upperCasePass = true
      }

      let lowerCasePass = false
      for(let i = 0; i < this.registerModel.password.length; i++) {
        const char = this.registerModel.password[i]
        if(this.checkCharType(char) === 'L')
          lowerCasePass = true
      }

      let symbolPass = false
      symbols.forEach(symbol => {
        if(_this.registerModel.password.includes(symbol))
          symbolPass = true
      })

      if(!numberPass) {
        errMsg = 'Şifreniz en az bir rakam içermelidir!'
      }
      if(!symbolPass) {
        errMsg = 'Şifreniz en az bir sembol içermelidir!'
      }
      if(!letterPass) {
        errMsg = 'Şifreniz en az bir harf içermelidir!'
      }
      if(!upperCasePass) {
        errMsg = 'Şifreniz en az bir büyük harf içermelidir!'
      }
      if(!lowerCasePass) {
        errMsg = 'Şifreniz en az bir küçük harf içermelidir!'
      }

      if(errMsg) {
        this.$toast.error('HATA: ' + errMsg, { position: POSITION.BOTTOM_RIGHT })
        return false
      }

      return true
    },

    validateEmail(email) {
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    },

    maxLengthCheck(maxLength, formKey) {
      if (this.registerModel[formKey].length > parseInt(maxLength))
        this.registerModel[formKey] = this.registerModel[formKey].slice(0, parseInt(maxLength))
    },

    checkCharType (charToCheck) {
        var returnValue = "O";
        var charCode = charToCheck.charCodeAt(0);

        if(charCode >= "A".charCodeAt(0) && charCode <= "Z".charCodeAt(0)){

            returnValue = "U";

        }else if (charCode >= "a".charCodeAt(0) &&
                    charCode <= "z".charCodeAt(0) ){
            returnValue = "L";
        }else if (charCode >= "0".charCodeAt(0) &&
                charCode <= "9".charCodeAt(0)  ) {
            returnValue = "N";
        }
        return returnValue;
    },

    getCities() {
      let _this = this

      this.$axios.post(this.$store.state.apiBaseUrl + '/City', {})
          .then(res =>  {
            _this.cities = res.data.data
          })
    },

    getTaxAdmins() {
      let _this = this

      this.$axios.post(this.$store.state.apiBaseUrl + '/TaxAdministration', {})
          .then(res =>  {
            _this.taxAdmins = res.data.data
          })
    },

    addServiceLocation() {
      this.serviceLocations.push({
        id: parseInt(this.serviceLocationCity),
        name: this.cities.find(city => city.id === parseInt(this.serviceLocationCity)).name
      })

      this.serviceLocationCity = ''
    },

    removeServiceLocation(locationId) {
      this.serviceLocations = this.serviceLocations.filter(location => location.id !== locationId)
    }
  }
}
</script>

<style scoped>
.service-locations-box {
  background: rgba(40, 11, 101, 0.03);
  border: 1px solid #280B65;
  border-radius: 4px;
  padding: 26px 16px;
  width: 100%;
  height: 200px;
  margin-top: 20px;
  overflow-y: auto;
}

.service-locations-box > p {
  width: 100%;
}

.service-locations-box > p:hover {
  background: #e1dcea;
  cursor: pointer;
}
</style>
