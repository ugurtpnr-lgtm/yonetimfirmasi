<template>
  <div class="mb-forgotpass-page-container">
    <section class="page6-main-sec" style="margin-top:0">
                <div class="container">
                   <div class="page6-heading d-flex">
                       <img src="/images/icons/account-icon.png" alt="acount-icon" class="img-fluid">
                       <h6>Yönetim Firması<span> Girişi</span></h6>
                   </div>

                   <div class="row">
                       <div class="col-md-6 ">
                           <div class="col-left">
                           <ul>
                            <li>

                                <div class="col-12">
                                    <div class="form-group">
                                        <label>  Mail adresiniz</label>
                                        <div class="sticky-notes">


                                            <input v-model="email" class="form-control" type="text" placeholder="info@firma.com.tr" name="email">
                                            <span><img src="/images/icons/email-icon.svg" alt="emial-icon"></span></div>

                                  </div>
                                  </div>
                                  </li>
                                  <li  >
                        </li>
                           </ul>
                          <div class="col-left-submit">
                            <!--<NuxtLink class="btn" to="/firma/firsatlar-ve-teklifler">
                               GİRİŞ YAP
                               <img src="/images/icons/sign-in.svg" alt="submit-arrow" class="img-fluid">
                            </NuxtLink>-->
                            <a
                              class="btn"
                              @click="resetPassword"
                            >
                              ŞİFREMİ SIFIRLA
                              <img src="/images/icons/sign-in.svg" alt="submit-arrow" class="img-fluid">
                            </a>
                          </div>


                       </div>
                       </div>
                       <div class="col-md-6">
                           <div class="col-right">
                           <div class="text-box">
                               <p>Bir Profesyonel<br>
                                    Yönetim Firması <br>
                                    için Müşteriye<br>
                                     Ulaşmanın<br>
                                En Kolay Yolu!</p>

                             <NuxtLink class="btn" to="/firma-girisi">
                               GİRİŞ YAP
                             </NuxtLink>
                          </div>
                           </div>
                    </div>
                   </div>



                </div>
    </section>
  </div>
</template>

<script>
const pageName = 'Şifremi Unuttum'
import { POSITION } from "vue-toastification"

export default {
  name: 'forgotPasswordPage',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
      email: '',
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },

  methods: {
    resetPassword() {
      let _this = this

      this.$axios.post(this.$store.state.apiBaseUrl + '/Account/ForgetPassword', {
        email: this.email
      })
      .then(res => {
        _this.$toast.success('Başarılı, şifrenizi sıfırlayabilmeniz için size bir E-Posta gönderdik.', { position: POSITION.BOTTOM_RIGHT })
      })
      .catch(err => {
        _this.$toast.error('HATA: Lütfen bilgilerizi kontrol ediniz!', { position: POSITION.BOTTOM_RIGHT })
      })
    }
  }
}
</script>
