<template>
  <div class="mb-login-page-container">
    <section class="page6-main-sec">
                <div class="container">
                   <div class="page6-heading d-flex">
                       <img src="/images/icons/account-icon.png" alt="acount-icon" class="img-fluid">
                       <h6>Yönetim Firması<span> Girişi</span></h6>
                   </div>

                   <div class="row">
                       <div class="col-md-6 ">
                           <div class="col-left">
                           <ul>
                            <li>

                                <div class="col-12">
                                    <div class="form-group">
                                        <label>  Mail adresiniz</label>
                                        <div class="sticky-notes">


                                            <input @keyup.enter="onLogin" v-model="email" class="form-control" type="text" placeholder="info@firma.com.tr" name="email">
                                            <span><img src="/images/icons/email-icon.svg" alt="emial-icon"></span></div>

                                  </div>
                                  </div>
                                  </li>
                                  <li  >
                                  <div class="col-12">
                                    <div class="form-group">
                                        <label> Şifreniz</label>
                                        <div class="sticky-notes">

                                    <input
                                      v-model="password"
                                      class="form-control"
                                      :type="passwordInputType"
                                      placeholder="*********"
                                      @keyup.enter="onLogin"
                                    >
                                    <span
                                      @click="showPassword"
                                      style="cursor:pointer"
                                    >
                                      <img src="/images/icons/eye.svg" alt="eye-icon">
                                    </span>
                                   </div>

                                  </div>
                                  </div>
                        </li>
                           </ul>
                             <NuxtLink to="/sifremi-unuttum">
                               <p>Şifremi Unuttum</p>
                             </NuxtLink>
                          <div class="col-left-submit">
                            <!--<NuxtLink class="btn" to="/firma/firsatlar-ve-teklifler">
                               GİRİŞ YAP
                               <img src="/images/icons/sign-in.svg" alt="submit-arrow" class="img-fluid">
                            </NuxtLink>-->
                            <a @click="onLogin" class="btn">
                              GİRİŞ YAP
                              <img src="/images/icons/sign-in.svg" alt="submit-arrow" class="img-fluid">
                            </a>
                          </div>


                       </div>
                       </div>
                       <div class="col-md-6">
                           <div class="col-right">
                           <div class="text-box">
                               <p>Bir Profesyonel<br>
                                    Yönetim Firması <br>
                                    için Müşteriye<br>
                                     Ulaşmanın<br>
                                En Kolay Yolu!</p>

                             <NuxtLink class="btn" to="/uye-ol">
                               ÜYE OL
                               <img src="/images/icons/user-plus.svg" alt="user-icon" class="img-fluid">
                             </NuxtLink>
                          </div>
                           </div>
                    </div>
                   </div>



                </div>
           </section>
  </div>
</template>

<script>
const pageName = 'Firma Girişi'
import { POSITION } from "vue-toastification"

export default {
  name: 'loginPage',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
    this.checkIsLoggedIn()
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
      email: '',
      password: '',
      passwordInputType: 'password'
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },

  methods: {
    onLogin() {
      let _this = this

      this.$axios.post(this.$store.state.apiBaseUrl + '/Account/SignIn', {
        email: this.email,
        password: this.password
      })
        .then(res => {
          _this.$toast.success('Giriş başarılı. Lütfen bekleyiniz...', { position: POSITION.BOTTOM_RIGHT })

          localStorage.yonetimFirmasiAccessToken = res.data.token
          localStorage.yonetimFirmasiRefreshToken = res.data.refreshToken
          localStorage.yonetimFirmasiTokenExpiration = res.data.expiration
          localStorage.yonetimFirmasiUserId = res.data.userId
          localStorage.yonetimFirmasiAuthenticationInformationId = res.data.authenticationInformationId
          _this.$store.commit('setIsLoggedIn', true)

          setTimeout(() => {
            _this.$router.push({
                path: '/firma/firsatlar-ve-teklifler'
            })
          }, 3000)
        })
        .catch(err => {
          console.log(err)
          _this.$toast.error('HATA: Bilgilerinizi yanlış girmiş olabilirsiniz veya üyeliğiniz henüz onaylanmamış olabilir. Detaylı bilgi için müşteri temsilcimiz ile iletişime geçebilirsiniz.', { position: POSITION.BOTTOM_RIGHT })
        })
    },

    showPassword() {
      this.passwordInputType = this.passwordInputType === 'password' ? 'text' : 'password'
    },

    checkIsLoggedIn() {
      let _this = this

      if(localStorage.yonetimFirmasiAccessToken) {
        this.$axios.get(this.$store.state.apiBaseUrl + '/User/Get?UserId=' + localStorage.yonetimFirmasiUserId, {
            headers: {
              Authorization: 'Bearer ' + localStorage.yonetimFirmasiAccessToken,
            }
        })
          .then(res =>  {
            _this.$store.commit('setIsLoggedIn', true)
            _this.$router.push({
                path: '/firma/firsatlar-ve-teklifler'
            })
          })
      }
    }
  }
}
</script>
