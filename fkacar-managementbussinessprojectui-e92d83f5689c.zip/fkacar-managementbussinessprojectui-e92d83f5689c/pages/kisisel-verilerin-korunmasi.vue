<template>
  <div id="KVKK-page-container">
    <div class="mb-get-offer-step-2-page-container">
      <div class="hero-page-1">
        <div class="container ">
          <div class="row">
            <div class="col-sm-12">
              <div class="protection-of-personal-data-main"><h1 align="center"><strong>KİŞİSEL VERİLERİN KORUNMASI HAKKINDA AÇIKLAMA VE GİZLİLİK POLİTİKASI</strong></h1><p>&nbsp;</p><p>YonetimFirmasi'na <strong>("YonetimFirmasi.com")</strong> aktarılan
                kişisel verilerin korunması konusundaki temel bilgilere aşağıda yer verilmiştir. <strong>YonetimFirmasi.com, 6698 sayılı
                Kişisel Verilerin Korunması Kanunu ("KVKK") m. 10'dan doğan aydınlatma yükümlülüğünü
                yerine getirmek amacıyla aşağıdaki açıklamaları müşterilerimizin ve web-sitemizi ve/veya mobil
                uygulamalarımızı kullanan 3. kişilerin dikkatine sunar. YonetimFirmasi.com işbu Kişisel Verilerin Korunması Hakkında
                Açıklama
                metnini yürürlükteki mevzuatta yapılabilecek değişiklikler çerçevesinde her
                zaman güncelleme hakkını saklı tutar.</strong></p><h2><strong>1) YonetimFirmasi.com'un kişisel verileri toplamasının yasal dayanağı nedir?</strong></h2><p>&nbsp;</p><p>Müşterilerimizin kişisel verilerinin kullanılması konusunda çeşitli kanunlarda düzenlemeler
                bulunmaktadır. En başta KVKK ile kişisel verilerin korunması esasları belirlenmiştir. Ayrıca 6563 Sayılı
                Elektronik Ticaretin Düzenlenmesi Hakkında Kanun da kişisel verilerin korunmasına ilişkin hüküm içermektedir.
                5237 Sayılı Türk Ceza Kanunu hükümleri yoluyla da kişisel verilerin korunması için bazı
                hallerde cezai yaptırımlar öngörülmüştür.</p><p>Diğer yandan, 6502 sayılı Tüketicinin Korunması Hakkında Kanun ve Mesafeli Sözleşmeler Yönetmeliği'nden
                doğan yükümlülüklerimizin ifası amacıyla verilerin toplanması ve kullanılması
                gerekmektedir.</p><h2><strong>2) YonetimFirmasi.com kişisel verilerin toplanmasında hangi yöntemleri kullanıyor?</strong></h2><p>&nbsp;</p><p>www.YonetimFirmasi.com web sitesinden veya mobil uygulamalardan işlem yapan müşterilerimizin verdikleri veriler,
                müşterilerimizin
                rızaları ve mevzuat hükümleri uyarınca YonetimFirmasi.com tarafından işlenmektedir.</p><p>YonetimFirmasi.com'a ait olan www.YonetimFirmasi.com web sitesi çerez (cookie) kullanan bir sitedir. çerez;
                kullanılmakta olan cihazın internet tarayıcısına ya da sabit diskine depolanarak söz konusu cihazın tespit
                edilmesine olanak tanıyan, çoğunlukla harf ve sayılardan oluşan bir dosyadır.</p><p>www.YonetimFirmasi.com ziyaretçilerine daha iyi hizmet verebilmek amacıyla ve yasal yükümlülüğü
                çerçevesinde, işbu Kişisel Verilerin Korunması Hakkında Açıklama metninde belirlenen amaçlar
                ve kapsam dışında kullanılmamak kaydı ile gezinme bilgilerinizi toplayacak, işleyecek, üçüncü
                kişilerle paylaşacak ve güvenli olarak saklayacaktır.</p><p>www.YonetimFirmasi.com çerezleri; günlük dosyaları, boş gif dosyaları ve/veya üçüncü
                taraf kaynakları yoluyla topladığı bilgileri tercihlerinizle ilgili bir özet oluşturmak amacıyla depolar.
                www.YonetimFirmasi.com size özel tanıtım yapmak, promosyonlar ve pazarlama teklifleri sunmak, web sitesinin veya
                mobil uygulamanın içeriğini size göre iyileştirmek ve/veya tercihlerinizi belirlemek amacıyla; site
                üzerinde gezinme bilgilerinizi ve/veya site üzerindeki kullanım geçmişinizi
                izleyebilmektedir.</p><p>www.YonetimFirmasi.com çevrimiçi ve çevrimdışı olarak toplanan bilgiler gibi farklı yöntemlerle
                veya farklı zamanlarda site üzerinde sizden toplanan bilgileri eşleştirebilir ve bu bilgileri üçüncü
                taraflar gibi başka kaynaklardan alınan bilgilerle birlikte kullanabilir.</p><p>www.YonetimFirmasi.com mobil uygulamasında oturum çerezleri ve kalıcı çerezler kullanmaktadır. Oturum
                kimliği çerezi, tarayıcınızı kapattığınızda sona erer. Kalıcı çerez ise sabit diskinizde uzun bir
                süre kalır. İnternet tarayıcınızın "yardım" dosyasında verilen talimatları izleyerek veya
                "www.allaboutcookies.org"
                veya "www.youronlinechoices.eu" adresini ziyaret ederek kalıcı çerezleri kaldırabilir ve hem
                oturum çerezlerini hem de kalıcı çerezleri reddedebilirsiniz. Kalıcı çerezleri veya oturum
                çerezlerini reddederseniz, web sitesini, mobil uygulamayı kullanmaya devam edebilirsiniz fakat web
                sitesinin, mobil uygulamanın tüm işlevlerine erişemeyebilirsiniz veya erişiminiz sınırlı olabilir.</p><h2 id="cerezler_nasil_kullanilmaktadir"><strong>3) İnternet Sitesi çerezleri Nasıl
                Kullanılmaktadır?</strong></h2><p>&nbsp;</p><p>YonetimFirmasi.com'a ait olan www.YonetimFirmasi.com web sitesi çerez (cookie) kullanan bir sitedir. çerez;
                kullanılmakta olan cihazın internet tarayıcısına ya da sabit diskine depolanarak söz konusu cihazın tespit
                edilmesine olanak tanıyan, çoğunlukla harf ve sayılardan oluşan bir dosyadır.</p><p>www.YonetimFirmasi.com çerezleri; günlük dosyaları, boş gif dosyaları ve/veya üçüncü
                taraf kaynakları yoluyla topladığı bilgileri tercihlerinizle ilgili bir özet oluşturmak amacıyla
                depolar.</p><p>Oturum çerezleri (session cookies) ve kalıcı çerezler (persistent cookies) olmak üzere
                sitelerimiz genelinde iki tür çerez kullanmaktayız. Oturum çerezleri geçici çerezler
                olup sadece tarayıcınızı kapatıncaya kadar geçerlidirler. Kalıcı çerezler siz silinceye veya süreleri
                doluncaya (bu şekilde çerezlerin cihazında ne kadar kalacağı, çerezlerin "kullanım ömürlerine"
                bağlı olacaktır) kadar sabit diskinizde kalırlar.</p><p>www.YonetimFirmasi.com çerezleri; yaptığınız tercihleri hatırlamak ve web sitesi/mobil uygulama kullanımınızı
                kişiselleştirmek için kullanır. Bu kullanım parolanızı kaydeden ve web sitesi/mobil uygulama oturumunuzun
                sürekli açık kalmasını sağlayan, böylece her ziyaretinizde birden fazla kez parola girme
                zahmetinden kurtaran çerezleri ve web sitesi/mobil uygulamaya daha sonraki ziyaretlerinizde sizi
                hatırlayan ve tanıyan çerezleri içerir.</p><p>www.YonetimFirmasi.com web sitesine nereden bağlandığınız, web sitesi/mobil uygulama üzerinde hangi içeriği
                görüntülediğiniz ve ziyaretinizin süresi gibi web sitesini/mobil uygulamayı nasıl
                kullandığınızın ölçümlenmesi dahil olmak üzere web sitesini/mobil uygulamayı nasıl
                kullandığınızı tespit etmek için kullanır.</p><p>www.YonetimFirmasi.com web sitesi çerezleri ayrıca; arama motorlarını, web sitesi, mobil uygulamasını ve/veya
                web sitesinin reklam verdiği internet sitelerini ziyaret ettiğinizde ilginizi çekebileceğini düşündüğü
                reklamları size sunabilmek için "reklam teknolojisini" devreye sokmak amacıyla kullanabilir.
                Reklam teknolojisi, size özel reklamlar sunabilmek için web sitesine/mobil uygulamaya ve web
                sitesinin reklam verdiği web sitelerine/mobil uygulamalarına yaptığınız önceki ziyaretlerle ilgili
                bilgileri kullanır. Bu reklamları sunarken, web sitesinin sizi tanıyabilmesi amacıyla tarayıcınıza benzersiz bir
                üçüncü taraf çerezi yerleştirilebilir. YonetimFirmasi.com ayrıca Google, Inc. tarafından
                sağlanan bir web analizi hizmeti olan Google Analytics kullanmaktadır. Google Analytics, çerezleri
                kullanıcıların web sitesini, mobil uygulamayı ve/veya mobil sitesini nasıl kullandıklarını istatistiki
                bilgiler/raporlar ile analiz etmek amacıyla kullanır. Google Analytics kullanımı hakkında daha fazla bilgi için
                (reddetme seçenekleri dahil), şu adresi ziyaret edebilirsiniz:
                http://www.google.com/intl/tr/policies/privacy/#infocollect</p><p>Mobil uygulamada çerez yerine ilgili uygulamanın SDK'sı (Software Development Kit) kullanılmaktadır.</p><p>Aşağıdaki yöntemleri kullanarak çerezlere izin verme ve reddetme imkanını kullanabilirsiniz:</p><table><tbody><tr><td>Google Chrome</td><td>:</td><td>Tarayıcınızın adres bölümünde yer alan, "kilit işareti"ni tıklayarak, "çerezler"
                sekmesinden çerezlere izin verebilir veya engelleyebilirsiniz.</td></tr><tr><td>Internet Explorer</td><td>:</td><td>Tarayıcınızın sağ üst bölümünde yer alan "Araçlar" bölümünden
                güvenlik sekmesini tıklayarak "izin ver" veya "izin verme" şeklinde
                çerezleri yönetebilirsiniz.</td></tr><tr><td>Mozilla Firefox</td><td>:</td><td>Tarayıcınızın sağ üst köşesinde yer alan "menüyü aç" sekmesini
                tıklayınız. "Seçenekler" görselini tıklayarak "Gizlilik ve Güvenlik"
                butonunu kullanarak çerezleri yönetebilirsiniz.</td></tr><tr><td>Opera</td><td>:</td><td>Tarayıcınızın "Tercihler" bölümünde "Gelişmiş"i seçerek
                "çerezler" bölümünden çerez yönetimini yapabilirsiniz.</td></tr><tr><td>Safari</td><td>:</td><td>Telefonunuzun "Ayarlar" bölümünden "safari" sekmesini seçip,
                "Gizlilik ve Güvenlik" Bölümünden tüm çerez yönetiminizi
                yapabilirsiniz.</td></tr></tbody></table><p>&nbsp;</p><p>Yukarıdaki seçeneklerin yanı sıra; tüm çerezler hakkında bilgi sahibi olmak ve çerez yönetimi
                için: https://www.allaboutcookies.org, https://www.youronlinechoices.eu/ adresini ziyaret edebilirsiniz,
                veya "Privacy Badger" uygulamasını kullanabilirsiniz (https://www.eff.org/tr/privacybadger). Kalıcı çerezleri
                veya oturum çerezlerini reddederseniz, web sitesini, mobil uygulamayı ve mobil sitesini kullanmaya devam
                edebilirsiniz fakat web sitesinin, mobil uygulamanın ve mobil sitesinin tüm işlevlerine erişemeyebilirsiniz
                veya erişiminiz sınırlı olabilir.</p><p>YonetimFirmasi.com'da yer alan çerezlere ilişkin bilgiler aşağıdaki tablolarda yer almaktadır:</p><table><thead><tr><th>Cookie Service Provider</th><th>Cookie İsmi</th><th>Cookie Amacı</th><th>Cookie Tipi</th><th>Cookie Süresi</th></tr></thead><tbody><tr><td>Google</td><td>_ga</td><td>Analytics cihaz bilgisi - Google Tag Manager sisteminde yer alan uygulamarın kullanması için</td><td>Persistent Cookie</td><td>2 Yıl</td></tr><tr><td>Google</td><td>_gaexp</td><td>AB testleri hakkında bilgileri tutan cookie - Google Tag Manager sisteminde yer alan uygulamarın
                kullanması için</td><td>Persistent Cookie</td><td>85 Gün</td></tr><tr><td>Google</td><td>_gid</td><td>Kullanıcı tanımlama için</td><td>Persistent</td><td>1 Gün</td></tr><tr><td>Yandex</td><td>_ym_isad</td><td>Reklam engelleme tespiti için</td><td>Persistent Cookie</td><td>2 Gün</td></tr><tr><td>Yandex</td><td>_ym_uid</td><td>Kullanıcıları tanımlama için</td><td>Persistent Cookie</td><td>1 Yıl</td></tr><tr><td>YonetimFirmasi.com</td><td>AbTesting</td><td>A/B Test yönetimi için kullanılan değer bu cookiede saklanmaktadır.</td><td>Persistent Cookie</td><td>2 Yıl</td></tr><tr><td>YonetimFirmasi.com</td><td>WebAbTesting</td><td>Coklu A/B Test yönetimi için kullanılan değerler bu cookiede saklanmaktadır.</td><td>Persistent Cookie</td><td>2 Yıl</td></tr><tr><td>YonetimFirmasi.com</td><td>COOKIE_CookieLawInformationPermission</td><td>Kişisel veri politikalarımıza ait izinler bu cookiede saklanmaktadır.</td><td>Non Persistent Cookie</td><td>Tarayıcı oturum süresi boyunca</td></tr><tr><td>YonetimFirmasi.com</td><td>COOKIE_Popup</td><td>Kullanıcıya gösterilen popuplar ile ilgili teknik veriler bu cookiede saklanmaktadır.</td><td>Persistent Cookie</td><td>1 Saat</td></tr><tr><td>YonetimFirmasi.com</td><td>COOKIE_TY.Entrance</td><td>Login olmuş kullanıcıya ait bilgilerin saklandığı cookiedir.</td><td>Persistent Cookie</td><td>1 Ay</td></tr><tr><td>YonetimFirmasi.com</td><td>COOKIE_TY.FirstVisit</td><td>Kullanıcının ilk ziyaret bilgisinin saklandığı cookiedir.</td><td>Persistent Cookie</td><td>1 Ay</td></tr><tr><td>YonetimFirmasi.com</td><td>COOKIE_TY.UserAlreadyLogged</td><td>Kullanıcının hali hazırda login olup olmadığı bilgisinin saklandığı cookiedir.</td><td>Non Persistent Cookie</td><td>Tarayıcı oturum süresi boyunca</td></tr><tr><td>YonetimFirmasi.com</td><td>COOKIE_uic</td><td>Login olmuş kullanıcıya ait access token olmayan demografik bilgilerinin saklandığı cookiedir.</td><td>Persistent Cookie</td><td>30 Dakika</td></tr><tr><td>YonetimFirmasi.com</td><td>COOKIE_UserAlreadyLogged</td><td>Kullanıcının hali hazırda login olup olmadığı bilgisinin saklandığı cookiedir.</td><td>Non Persistent Cookie</td><td>Tarayıcı oturum süresi boyunca</td></tr><tr><td>YonetimFirmasi.com</td><td>COOKIE_UserTypeStatus</td><td>Kullanıcıların statulerinin saklandığı cookiedir.</td><td>Persistent Cookie</td><td>12 Saat</td></tr><tr><td>YonetimFirmasi.com</td><td>hvtb</td><td>Bir kullanıcının daha önce YonetimFirmasi.com'u ziyaret edip etmediği bilgisini veriyor</td><td>Persistent Cookie</td><td>2 Yıl</td></tr><tr><td>YonetimFirmasi.com</td><td>pid</td><td>Kalıcı olarak kullanıcıya verilen ID nin saklandığı cookiedir.</td><td>Persistent Cookie</td><td>1 Yıl 354 Gün</td></tr><tr><td>YonetimFirmasi.com</td><td>sid</td><td>Kullanıcıya ait session ID değerinin saklandığı cookiedir.</td><td>Persistent Cookie</td><td>30 Dakika</td></tr><tr><td>YonetimFirmasi.com</td><td>SiteHash</td><td>Cookielere ait hash bilgisinin saklandığı cookiedir.</td><td>Persistent Cookie</td><td>7 Gün</td></tr><tr><td>YonetimFirmasi.com</td><td>VisitorTypeStatus</td><td>Ziyaretçilerin statulerinin saklandığı cookiedir.</td><td>Persistent Cookie</td><td>Tarayıcı oturum süresi boyunca</td></tr><tr><td>Qualaroo</td><td>ki_r</td><td>Kişinin siteye indiği referrer cookiesi, document.referrer'dan gelir.</td><td>Persistent Cookie</td><td>5 Yıl</td></tr><tr><td>Qualaroo</td><td>ki_t</td><td>Anket zaman damgaları ve görüntüleme sayılarının bulunduğu cookiedir.</td><td>Persistent Cookie</td><td>5 Yıl</td></tr><tr><td>YonetimFirmasi.com</td><td>NSC_QDJUFTU-IUUQT-XXX.USFOEZPM.DPN</td><td>Netscalerda tüm gruplarda aynı session üzerinden ilerlemek için sticky session
                bilgisinin saklandığı cookiedir.</td><td>Session Cookie</td><td>Tarayıcı oturum süresi boyunca</td></tr><tr><td>Marketing</td><td>utmCampaign30dtemp2</td><td>Kullanıcı ziyaret kanalı kayıt bilgisini 30 gün tutmak</td><td>Persistent Cookie</td><td>1 Ay</td></tr><tr><td>Marketing</td><td>utmCampaignGO5d</td><td>Kullanıcı ziyaret kanalı kayıt bilgisini affiliate kampanyaları için 5 gün tutmak</td><td>Persistent Cookie</td><td>5 Gün</td></tr><tr><td>Marketing</td><td>utmCampaignLT30d</td><td>Kullanıcı ziyaret kanalı kayıt bilgisini 3 ay tutmak</td><td>Persistent Cookie</td><td>1 Ay</td></tr><tr><td>Marketing</td><td>utmMedium30dtemp2</td><td>Kullanıcı ziyaret kanalı kayıt bilgisini 30 gün tutmak</td><td>Persistent Cookie</td><td>1 Ay</td></tr><tr><td>Marketing</td><td>utmMediumGO5d</td><td>Kullanıcı ziyaret kanalı kayıt bilgisini affiliate kampanyaları için 5 gün tutmak</td><td>Persistent Cookie</td><td>5 Gün</td></tr><tr><td>Marketing</td><td>utmSource30dtemp2</td><td>Kullanıcı ziyaret kanalı kayıt bilgisini 30 gün tutmak</td><td>Persistent Cookie</td><td>1 Ay</td></tr><tr><td>Marketing</td><td>utmSourceGO5d</td><td>Kullanıcı ziyaret kanalı kayıt bilgisini affiliate kampanyaları için 5 gün tutmak</td><td>Persistent Cookie</td><td>5 Gün</td></tr></tbody></table><p>&nbsp;</p><h2><strong>4) YonetimFirmasi.com kişisel verileri hangi amaçlarla kullanıyor?</strong></h2><p>&nbsp;</p><p>YonetimFirmasi.com, mevzuatın izin verdiği durumlarda ve ölçüde kişisel bilgilerinizi kaydedebilecek,
                saklayabilecek, güncelleyebilecek, üçüncü kişilere açıklayabilecek,
                devredebilecek, sınıflandırabilecek ve işleyebilecektir.</p><p>Kişisel verileriniz şu amaçlarla kullanılmaktadır:</p><ul style="list-style-type:disc"><li><p>web sitesi/mobil uygulamalar üzerinden alışveriş yapanın/yaptıranın kimlik bilgilerini teyit
                etmek,</p></li><li><p>iletişim için adres ve diğer gerekli bilgileri kaydetmek,</p></li><li><p>mesafeli satış sözleşmesi ve Tüketicinin Korunması Hakkında Kanun'un ilgili maddeleri
                tahtında akdettiğimiz sözleşmelerin koşulları, güncel durumu ve güncellemeler ile ilgili
                müşterilerimiz ile iletişime geçmek, gerekli bilgilendirmeleri yapabilmek,</p></li><li><p>elektronik (internet/mobil vs.) veya kağıt ortamında işleme dayanak olacak tüm kayıt ve belgeleri
                düzenlemek,</p></li><li><p>mesafeli satış sözleşmesi ve Tüketicinin Korunması Hakkında Kanun'un ilgili maddeleri
                tahtında akdettiğimiz sözleşmeler uyarınca üstlenilen yükümlülükleri ifa
                etmek,</p></li><li><p>kamu güvenliğine ilişkin hususlarda talep halinde ve mevzuat gereği kamu görevlilerine bilgi
                verebilmek,</p></li><li><p>müşterilerimize daha iyi bir alışveriş deneyimini sağlamak, "müşterilerimizin ilgi
                alanlarını dikkate alarak" müşterilerimizin ilgilenebileceği ürünlerimiz hakkında müşterilerimize
                bilgi verebilmek, kampanyaları aktarmak,</p></li><li><p>müşteri memnuniyetini artırmak, web sitesi ve/veya mobil uygulamalardan alışveriş yapan müşterilerimizi
                tanıyabilmek ve müşteri çevresi analizinde kullanabilmek, çeşitli pazarlama ve reklam
                faaliyetlerinde kullanabilmek ve bu kapsamda anlaşmalı kuruluşlar aracılığıyla elektronik ortamda
                ve/veya fiziki ortamda anketler düzenlemek,</p></li><li><p>anlaşmalı kurumlarımız ve çözüm ortaklarımız tarafından müşterilerimize öneri
                sunabilmek, hizmetlerimizle ilgili müşterilerimizi bilgilendirebilmek,</p></li><li><p>hizmetlerimiz ile ilgili müşteri şikayet ve önerilerini değerlendirebilmek,</p></li><li><p>yasal yükümlülüklerimizi yerine getirebilmek ve yürürlükteki
                mevzuattan doğan haklarımızı kullanabilmek,</p></li></ul><h2><strong>5) YonetimFirmasi.com kişisel verilerinizi nasıl koruyor?</strong></h2><p>&nbsp;</p><p>YonetimFirmasi.com ile paylaşılan kişisel veriler, YonetimFirmasi.com gözetimi ve kontrolü altındadır. YonetimFirmasi.com, yürürlükteki
                ilgili mevzuat hükümleri gereğince bilginin gizliliğinin ve bütünlüğünün
                korunması amacıyla gerekli organizasyonu kurmak ve teknik önlemleri almak ve uyarlamak konusunda veri
                sorumlusu sıfatıyla sorumluluğu üstlenmiştir. Bu konudaki yükümlülüğümüzün
                bilincinde olarak veri gizliliğini konu alan uluslararası ve ulusal teknik standartlara uygun surette periyodik
                aralıklarda sızma testleri yaptırılmakta ve bu kapsamda veri işleme politikalarımızı her zaman güncellediğimizi
                bilginize sunarız.</p><h2><strong>6) YonetimFirmasi.com kişisel verilerinizi paylaşıyor mu?</strong></h2><p>&nbsp;</p><p>Müşterilerimize ait kişisel verilerin üçüncü kişiler ile paylaşımı, müşterilerin
                izni çerçevesinde gerçekleşmekte ve kural olarak müşterimizin onayı olmaksızın kişisel
                verileri üçüncü kişilere aktarılmamaktadır.</p><p>Bununla birlikte, yasal yükümlülüklerimiz nedeniyle ve bunlarla sınırlı olmak üzere
                mahkemeler ve diğer kamu kurumları ile kişisel veriler paylaşılmaktadır. Ayrıca, taahhüt ettiğimiz
                hizmetleri sağlayabilmek ve verilen hizmetlerin kalite kontrolünü yapabilmek için anlaşmalı
                üçüncü kişilere kişisel veri aktarımı yapılmaktadır.</p><p>üçüncü kişilere veri aktarımı sırasında hak ihlallerini önlemek için gerekli
                teknik ve hukuki önlemler alınmaktadır. Bununla birlikte, kişisel verileri alan üçüncü
                kişinin veri koruma politikalarından dolayı ve üçüncü kişinin sorumluluğundaki risk
                alanında meydana gelen ihlallerden YonetimFirmasi.com sorumlu değildir.</p><p>Kişisel verileriniz YonetimFirmasi.com'un hissedarlarıyla, doğrudan/dolaylı yurtiçi/yurtdışı iştiraklerimize,
                faaliyetlerimizi yürütebilmek için işbirliği yaptığımız program ortağı kurum, kuruluşlarla,
                verilerin bulut ortamında saklanması hizmeti aldığımız yurtiçi/yurtdışı kişi ve kurumlarla, müşterilerimize
                ticari elektronik iletilerin gönderilmesi konusunda anlaşmalı olduğumuz yurtiçi/yurtdışındaki
                kuruluşlarla, Bankalararası Kart Merkeziyle, anlaşmalı olduğumuz bankalarla ve sizlere daha iyi hizmet
                sunabilmek ve müşteri memnuniyetini sağlayabilmek için çeşitli pazarlama faaliyetleri
                kapsamında yurtiçi ve yurtdışındaki çeşitli ajans, reklam şirketleri ve anket şirketleriyle ve
                yurtiçi/yurtdışı diğer üçüncü kişilerle ve ilgili iş ortaklarımızla
                paylaşılabilmektedir.</p><h2><strong>7) Kişisel Verilerin Korunması Kanunu'ndan doğan haklarınız nelerdir?</strong></h2><p>&nbsp;</p><p>KVKK uyarınca kişisel verilerinizin;</p><ol type="a"><li><p>a) işlenip işlenmediğini öğrenme,</p></li><li><p>b) işlenmişse bilgi talep etme,</p></li><li><p>c) işlenme amacını ve amacına uygun kullanılıp kullanılmadığını öğrenme,</p></li><li><p>d) yurt içinde / yurt dışında aktarıldığı 3. kişileri bilme,</p></li><li><p>e) eksik / yanlış işlenmişse düzeltilmesini isteme,</p></li><li><p>f) KVKK'nın 7. maddesinde öngörülen şartlar çerçevesinde silinmesini /
                yok edilmesini isteme,</p></li><li><p>g) aktarıldığı 3. kişilere yukarıda sayılan (d) ve (e) bentleri uyarınca yapılan işlemlerin
                bildirilmesini isteme,</p></li><li><p>h) münhasıran otomatik sistemler ile analiz edilmesi nedeniyle aleyhinize bir sonucun ortaya
                çıkmasına itiraz etme,</p></li><li><p>i) KVKK'ya aykırı olarak işlenmesi sebebiyle zarara uğramanız halinde zararın giderilmesini
                talep etme haklarına sahip olduğunuzu hatırlatmak isteriz.</p></li><li><p>j) Başvuru formu için lütfen bizimle iletişime geçiniz</p></li></ol><h2><strong>8) Kişisel verilerle ilgili mevzuat değişikliklerinden nasıl haberdar olabilirim?</strong></h2><p>&nbsp;</p><p>KVKK uyarınca sahip olduğunuz haklar YonetimFirmasi.com'un yükümlülükleridir. Kişisel
                verilerinizi bu bilinçle ve mevzuatın gerektirdiği ölçüde işlediğimizi, yasal
                değişikliklerin olması halinde sayfamızda yer alan bu bilgileri yeni mevzuata uygun güncelleyeceğimizi,
                yapılan güncellemeleri de bu sayfa üzerinden her zaman kolaylıkla takip edebileceğinizi size bildirmek
                isteriz.</p><h2><strong>9) Verinin güncel ve doğru tutulduğundan nasıl emin olabilirim?</strong></h2><p>&nbsp;</p><p>KVKK'nın 4. maddesi uyarınca YonetimFirmasi.com'un kişisel verilerinizi doğru ve güncel olarak tutma yükümlülüğü
                bulunmaktadır. Bu kapsamda YonetimFirmasi.com'un yürürlükteki mevzuattan doğan yükümlülüklerini
                yerine getirebilmesi için müşterilerimizin YonetimFirmasi.com'la doğru ve güncel verilerini
                paylaşması gerekmektedir. Verilerinizin herhangi bir surette değişikliğe uğraması halinde aşağıda belirtilen
                iletişim kanallarından bizimle iletişime geçerek verilerinizi güncellemenizi rica ederiz.</p><h2><strong>10) YonetimFirmasi.com'a kişisel verilerinizle ilgili soru sormak ister misiniz?</strong></h2><p>&nbsp;</p><p>Kişisel veri saklama ve imha politikamız bulunmaktadır. Bize kişisel verilerinizle ilgili her türlü
                soru ve görüşleriniz için kvkk@YonetimFirmasi.com e-posta adresinden dilediğiniz zaman
                ulaşabilirsiniz.</p></div>
            </div>
          </div>
        </div>
        </div>
      </div>
  </div>
</template>

<script>
const pageName = 'Kişisel Verilerin Korunması'

export default {
  name: 'KVKKPage',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },
}
</script>
