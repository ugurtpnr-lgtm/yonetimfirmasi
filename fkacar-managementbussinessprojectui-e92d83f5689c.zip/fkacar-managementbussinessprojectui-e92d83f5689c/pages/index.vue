<template>
  <div class="mb-container">
            <div class="hero">
                <div class="container">
                    <div  class="row">
                        <div class="col-md-5">
                            <div class="hero-text">
                                <p>YÖNETİM FİRMASI</p>
                                <h6>İhtiyaçlarınıza uygun
                                    <span>Profesyonel Yönetim
                                        Firmasını </span>bulmak
                                    artık çok kolay!</h6>
                                    <NuxtLink class="btn main-page-offer-btn" to="/teklif-al/asama-1">HEMEN TEKLİF AL</NuxtLink>
                            </div>
                        </div>
                        <div class="col-md-7 text-right">
                            <div class="image-holder">
                                <img src="/images/man-lady.png" alt="hero-img" class="image-fluid">
                                <span class="icon1">
                                    <img src="/images/hero-icon-1.png" alt="hero-icon-img" class="image-fluid">
                                </span>
                                <span class="icon2">
                                    <img src="/images/hero-icon-2.png" alt="hero-icon-img" class="image-fluid">
                                </span>
                                <span class="icon3">
                                    <img src="/images/hero-icon-3.png" alt="hero-icon-img" class="image-fluid">
                                </span>
                                <span class="icon4">
                                    <img src="/images/hero-icon-4.png" alt="hero-icon-img" class="image-fluid">
                                </span>
                                <span class="icon5">
                                    <img src="/images/hero-icon-5.png" alt="hero-icon-img" class="image-fluid">
                                </span>
                            </div>
                        </div>
                    </div>



                        </div>
                    </div>
                    <section class="sec-main">
                        <div class="container">

                     <div class="text-box">
                        <p><span class="black-span">Apartman / Site</span> yönetimi için ihtiyaçlarını belirle, hızlıca <NuxtLink to="/teklif-al/asama-1"><span class="blue-span">teklif al, </span></NuxtLink>
                            karşılaştırmalı teklifler ile sana en uygun firmayı seç, hizmete başla.</p>
                        </div>
                        </div>
                    </section>
                    <section class="sec-boxes">
                        <div class="container">
                       <div class="row d-flex">
                           <div class="col-md-4 col-sm-6">
                        <div class="sec-boxes-box">
                            <span>
                                <img src="/images/img-icon-1.png" alt="icon-1-img" class="img-fluid">
                            </span>
                            <div class="image-holder">
                                <img src="/images/box-img-1.png">

                            </div>
                            <div class="text-box">
                                <h6>İhtiyaçlarını<br>
                                    Seç</h6>
                                    <p class="mt-19">Hemen Teklif Al<br>
                                        butonuna tıkla,<br>
                                        ihtiyaçlarını seç.</p>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="sec-boxes-box">
                            <span>
                                <img src="/images/img-icon-2.png" alt="icon-1-img" class="img-fluid">
                            </span>
                            <div class="image-holder">
                                <img src="/images/box-img-2.png">

                            </div>
                            <div class="text-box">
                                <h6>Özel Fiyat<br>
                                     Teklifleri Al</h6>
                                    <p class="p-change mt-6">Profesyonel yönetim <br>
                                        firmalarına<br>
                                         ihtiyaçlarını bildirelim<br>
                                         ve sana özel teklifler<br>
                                          hazırlansın.</p>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="sec-boxes-box">
                            <span>
                                <img src="/images/img-icon-3.png" alt="icon-1-img" class="img-fluid">
                            </span>
                            <div class="image-holder">
                                <img src="/images/box-img-3.png">

                            </div>
                            <div class="text-box">
                                <h6 >Karşılaştır<br>
                                    ve Seç</h6>
                                    <p class="p-change mt-6">İhtiyaçlarına en<br>
                                         uygun teklifi seç ve<br>
                                          hizmete başla.</p>
                            </div>

                        </div>
                        </div>
                        </div>
                    </div>
                    </section>
  </div>
</template>

<script>
const pageName = 'Yönetim Firması Bul'

export default {
  name: 'indexPage',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },
}
</script>
