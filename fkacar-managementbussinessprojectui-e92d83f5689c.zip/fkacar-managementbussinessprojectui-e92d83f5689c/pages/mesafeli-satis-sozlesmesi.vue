<template>
  <div id="mss-page-container">
    <div class="mb-get-offer-step-2-page-container">
      <div class="hero-page-1">
        <div class="container ">
          <div class="row">
            <div class="col-sm-12">
              <section class="themeModules" data-bg="false" data-layout="fixed">
                <center><h3><strong>Mesafeli Satış Sözleşmesi</strong></h3></center> <br><br>
                <div class=WordSection1>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 1<br>
Giriş</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>1.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>İşbu kullanıcı sözleşmesi ve Web Sitesi’nde yer alan
diğer kurallar yonetimfirmasi.com tarafından sunulan hizmetlere ilişkin şart ve
koşulları ve Web Sitesi’nin kullanılmasına ilişkin kuralları düzenlemektedir.
Kullanıcı’nın, Web Sitesi üzerinden Hizmet Talebi veya Meslek Profili
oluştururken işbu Sözleşmeyi onayladığı veya Web Sitesi’nden yararlanmaya
başladığı andan itibaren işbu Sözleşmeye uymayı taahhüt ettiği kabul edilir.
Koşulların sizin için uygun olmaması halinde lütfen Web Sitesi’ni ve sunulan hizmetleri
kullanmayınız.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>1.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com aracılık hizmetlerinin sürekliliğini
sağlama, ileride doğacak teknik zaruretler veya mevzuata uyum sağlanması
amacıyla Sözleşmeyi Kullanıcılar aleyhine olmamak kaydıyla tek taraflı olarak
değiştirme ya da tadil etme hakkına sahiptir. Yonetimfirmasi.com, herhangi bir
değişiklik olması halinde güncel kullanım şartlarını aynı link altında yeni
tarih güncellemesi ile Web Sitesi’nde yayınlayacak, gerek görmesi halinde
elektronik posta veya mobil bildirim ile kullanıcılarına bildirilecek ve
onayına sunacaktır. Yenilenmiş güncel Sözleşme, Web Sitesi’nde yayınlandığı
andan itibaren geçerli olacak ve Web Sitesi’nin veya hizmetlerinin kullanımı o
andan itibaren yenilenmiş Sözleşme şartlarına tabi olacaktır.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 2<br>
Tanımlar</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>İşbu Sözleşme metni içerisinde;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>“yonetimfirmasi.com” Sin Erke yazılım hizmetleri Limited
Şirketi’ni,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>“Web Sitesi” https://yonetimfirmasi.com internet sitesini
ve IOS / Android tabanlı Mobil Uygulamaları,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.3.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>“Kullanıcı” Herhangi bir sebeple Web Sitesi’ni kullanan
kişileri,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.4.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>“Üye” E-posta ve/veya telefon kaydı alınarak işbu
Kullanıcı Sözleşmesi’nin kabul edilmesi koşuluna bağlı olarak kendisine
kullanıcı adı ve şifre belirleyen Kullanıcı’yı,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.5.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>“Hizmet Alan” Web Sitesi üzerinden Hizmet Verenlerce
sunulan herhangi bir hizmeti satın almak için Hizmet Talebi gönderen gerçek
veya tüzel kişi Kullanıcı’yı,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.6.&nbsp;&nbsp;</span></b><span lang=TR
                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>“Hizmet Veren” (Yönetmelik kapsamında Hizmet Sağlayıcı)
Hizmet sağlamak üzere Web Sitesi üzerinden Meslek Profili oluşturan ve işbu
Kullanıcı sözleşmesini onaylayan şahıs, kuruluş veya tüzel kişiyi (Hizmet Veren
tüzel bir kişi ise, söz konusu tanım Hizmet Veren adına hizmetleri yürüten ve
ona bağlı olarak çalışan kişileri de kapsar.),</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.7.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>“Hizmet Talebi” Hizmet Alan tarafından, bir veya daha
fazla Hizmet Veren’den Teklif almak amacıyla Web Sitesi üzerinde oluşturulan
hizmet talebi,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.8. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>“Teklif”
Hizmet Veren'in, Hizmet Alan’ın gönderdiği Hizmet Talebi’ne yanıt olarak
gönderdiği, hizmetleri belli bir süre ve belli bir ücret karşılığında sağlama
teklifini,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.9.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>&nbsp;
&nbsp; “Teklif Modeli” Hizmet Alan’ın hizmet talebini oluşturduktan sonra, bu
talebin Hizmet Verenlere yönlendirilmesiyle Hizmet Verenlerin kendi
inisiyatifleri doğrultusunda Hizmet Alan’a Teklif verdiği modeli,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.10. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>“Yonetim
firmasıyım  Profili” Hizmet Veren’in Hizmet Alan’a sunabileceği hizmetin
tanıtımını yapmak, Web Sitesi üzerinde oluşturduğu profili,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.11.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
“Teklif Verme Ücreti” Teklif Modeli’nde Hizmet Veren’in Hizmet Alan’a Teklif
verme hakkını kazanabilmesi için yonetimfirmasi.com’a ödeyeceği hizmet
bedelini,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.12. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>”Hizmet
Bedeli” Teklif Modeli’nde Hizmet Alan’ın Hizmet Talebi doğrultusunda Hizmet
Verenlerin Web Sitesi üzerinden verdiği teklifler arasından anlaştığı teklifin
bedeli, </span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.13. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>”Bakiye”
Teklif Modeli’nde Hizmet Veren’ın kendisine yönlendirilen Hizmet Taleplerine
Teklif verebilmek için ve Anlaşmaya Varılmış İş sonrası yonetimfirmasi.com’a
ödemekle yükümlü olduğu Komisyon ücretlerini ödeyebilmesi için
yonetimfirmasi.com hesabına tanımlanan bedeli</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.14. </span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>“Kullanılabilir
Bakiye”, Teklif Modeli’nde Hizmet Veren’in Teklif Ücreti ödeyerek teklif
verebileceği ve/veya iş kazandığında Komisyon Ücretini ödeyebileceği varsa
Kredi Limiti sonrası kullanabileceği mevcut bakiye bedelini,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.15. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>“Sözleşme”
İşbu Kullanıcı Sözleşmesini,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>2.16. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>“Yönetmelik”
15 Şubat 2018 günlü ve 9517 sayılı Resmî Gazete’de yayınlanan Elektronik
Ticarette Hizmet Sağlayıcı ve Aracı Hizmet Sağlayıcılar Hakkında Yönetmelik’i,</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>ifade eder.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 3<br>
yonetimfirmasi.com Tarafından Sunulan Hizmetler</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>3.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com, Hizmet Veren ve Hizmet Alan’ın
içeriklerini kendileri oluşturdukları hizmet talebi bilgilerinin, kendisine
bildirilen içeriğe uygun olarak ve işbu Sözleşme hükümleri çerçevesinde, Web
Sitesi’nde yer almasını sağlar.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>3.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com yalnızca bir platformdur, Web
Sitesi’nde yer alan hizmetlerin sahibi veya sağlayıcısı değildir. Yönetmelik’in
6/4 maddesine göre, yonetimfirmasi.com aracı hizmet sağlayıcıdır ve hizmet
sunduğu elektronik ortamı kullanan gerçek ve tüzel kişiler tarafından sağlanan
içeriği kontrol etmek, bu içerik ve içeriğe konu mal veya hizmetle ilgili
hukuka aykırı bir faaliyetin ya da durumun söz konusu olup olmadığını
araştırmakla yükümlü değildir.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>KULLANIM ŞARTLARI</span></b></p>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 4<br>
Üyelik Sistemi</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>4.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Web Sitesi’ne üyelik ücretsizdir. Üyeler, tek bir Üye
hesabı üzerinden aynı anda birden fazla Hizmet Talebi gönderebilirler.
Şifre'nin belirlenmesi ve korunması üyenin kendi sorumluluğundadır. Kullanıcı
adı ve şifresi paylaşılmamalı ve özenle korunmalıdır. Üye, hesabının kendi
kusuru nedeniyle başka kişiler tarafından kötü niyetle kullanılmasından
doğrudan sorumludur. yonetimfirmasi.com, bu sebeple ödemek zorunda kalacağı her
türlü adli/idari para cezası ve/veya tazminat için Üye’ye aynen rücu hakkına
sahiptir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>4.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Üye hesabı oluştururken Web Sitesi’ne beyan edilen isim,
adres, telefon, e-posta, vergi dairesi, gibi her türlü bilgi, güncel, doğru ve
eksiksiz olmalıdır. Söz konusu bilgilerin yanlış veya eksik olması nedeniyle
Üyelerin veya 3. kişilerin uğrayacağı zararlardan sorumluluk ilgili Üye’ye
aittir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>4.3.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Üyeliğe ilişkin kullanım hakları, kullanıcı adı ve
şifresi başkalarına devredilemez.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>4.4. </span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Eğer
Hizmet Veren’in veya Hizmet Alan’ın yonetimfirmasi.com’a ödemesi gereken tutar
bulunuyorsa bu tutarı ödemeden hesabı silinemez.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 5<br>
Hizmet Talebi Oluşturulması</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>5.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>En az 18 yaşında olan ve temyiz kudretini haiz herhangi
bir Kullanıcı, işbu Sözleşme koşulları uyarınca kayıt formunda talep edilen bilgileri
doğru ve eksiksiz olarak doldurarak bir Hizmet Talebi oluşturabilir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>5.2.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
İşbu sözleşmeyi kabul eden kullanıcılar 18 yaşından büyük olduklarını beyan ve
kabul etmiş sayılırlar. Hizmet Talebi’nde bu beyanın aksinden doğabilecek
durumlardan yonetimfirmasi.com’un sorumlu tutulamayacağını ve kendi
sorumluluklarında olduğunu kabul ve beyan ederler.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>5.3.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Geçerli bir Hizmet Talebi oluşturmak için hizmete ilişkin
gerekli bilgilerin (talep edilen işin niteliği, özelliği, kalitesi, ve işin
süresi vb.) eksiksiz, doğru ve açık olarak verilmesi ve içeriğinin işbu
Sözleşme’de belirtilen şartlara uygun olması gerekir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>5.4.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com, Hizmet Talebini kendi teknolojisini
kullanarak denetiminden geçirdikten sonra, uygun olması halinde yayımlar. Ancak
Hizmet Talebi’nin içeriğine ilişkin tüm sorumluluk Hizmet Alan’a aittir.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 6<br>
Teklif Modeli</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>6.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Hizmet Veren, kendisine gönderilen bir Hizmet Talebi için
Web Sitesi üzerinden Teklif vererek, Hizmet Talebi’nde belirtilen hizmeti
Teklif’te belirtilen fiyat üzerinden yapmayı teklif eder.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>6.2. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Verilen
Teklifler Hizmet Verenler tarafından belirtilen süre boyunca geçerli ve
bağlayıcıdır. Hizmet Veren’in belirttiği süreden önce Teklif’i geri çekmesinden
yonetimfirmasi.com’un herhangi bir sorumluluğu bulunmamaktadır.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 7<br>
Hizmet Verenler için: Teklif Modeli Değişiklik ve İptal Kuralları</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>7.1. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Anlaşılan
bir Teklif’e konu olan hizmete ilişkin her türlü değişiklik Hizmet Alan ile
birlikte Hizmet Veren tarafından ortaklaşa olarak Web Sitesi üzerinde
kararlaştırılmalıdır. Web Sitesi’nden gönderilen bir Hizmet Talebi’ne ilişkin
olarak yonetimfirmasi.com’a bildirilmeksizin, yonetimfirmasi.com’a aracılık
ücreti ödenmemesi amacıyla tarafların anlaştığı ve teklif verildiği yonetimfirmasi.com
tarafından tespit edilirse, yonetimfirmasi.com sağlanan hizmete ilişkin
Komisyon bedeline hak kazanır ve ilgili Komisyon Ücreti Hizmet Veren tarafından
yonetimfirmasi.com’a ödenir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>7.2. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>yonetimfirmasi.com,
teklif verme işlemini Hizmet Verenler için ücretli olarak sunabilir, teklif
başına veya teklifteki bedel üzerinden veya farklı bir şekilde Teklif Verme
Ücreti alabilir. Hizmet Veren, teklif verdiği hizmetler için keşif veya ek
masraf yapsa bile, teklifinin kabul edilmemesi, teklifinin Hizmet Alan
tarafından görülmemesi, Hizmet Talebi’nin iptal edilmesi veya aynı hizmet için
başka Hizmet Verenlerin de teklif vermiş olması, hiçbir şekilde Hizmet Veren’e
Teklif Verme Ücreti’nin iade edilmesi anlamına gelmemektedir.&nbsp;</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>7.3.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
yonetimfirmasi.com tarafından Hizmet Verenlerin hesabına tanımlanan hediye
kuponların maddi bir değeri yoktur ve tutar olarak iadesi Hizmet Verenler
tarafından talep edilemez. Teklif Ücreti veya Komisyon tutarları ilgili Hizmet
Veren’in önce kendi yüklediği bakiyeden, daha sonra varsayonetimfirmasi.com
tarafından yüklenen hediye kupon tutarından düşer. Hizmet Verenlerin Bakiye
iadesi istemesi durumunda, iade edilecek tutar daha önce varsa yonetimfirmasi.com
tarafından yüklenen hediye kupon miktarı düşülerek hesaplanır.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 8<br>
Hizmet Alanlar için: Teklif Modeli Değişiklik ve İptal Kuralları</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>8.1.&nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>&nbsp;yonetimfirmasi.com
Hizmet Alanlar için Hizmet Talebi oluşturmayı ücretsiz olarak sunmaktadır.
Hizmet Alan oluşturduğu bir Hizmet Talebi’ni Web Sitesi veya mail yoluyla iptal
edebilir fakat talebin içeriğinde sonradan bir değişiklik yapması mümkün
değildir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>8.2.&nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>&nbsp;Hizmet
Alanlar Hizmet Talebi’ni iptal etmek isterse, Hizmet Verenlerin ve yonetimfirmasi.com’un
bir mağduriyet yaşamaması için bunu Web Sitesi üzerinden veya mail yoluyla yonetimfirmasi.com’u
bildirmelidirler.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>8.3.&nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>&nbsp;Hizmet
Alanların Anlaşmaya Varılmış İşleri Web Sitesi üzerinden iptal etmesi mümkün
değildir, Web Sitesi üzerinde anlaşılan fakat gerçekleşmeyen işlerin bildirimi
destek@yonetimfirmasi.com mail adresine gönderilecek bir e-postayla
yapılmalıdır.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>8.4.&nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>&nbsp;Hizmet
Alanların sonradan Hizmet Taleplerini iptal etmesi, yonetimfirmasi.com’a bir
sorumluluk yüklemez ve bu konuda doğabilecek yükümlülüklerden Hizmet Alan
sorumludur.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>8.5.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
Hizmet Alanlar yonetimfirmasi.com üzerinde birden fazla Hizmet Talebi
oluşturabilirler. Buna karşın çok fazla sayıda ve arka arkaya geçersiz Hizmet
Talebi oluşturmaları durumunda yonetimfirmasi.com bu kullanıcıları sistemde
inaktif duruma getirme yoluyla kullanıcı hesaplarını askıya alma hakkını saklı
tutar.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal style='margin-top:24.0pt;margin-right:0in;margin-bottom:
24.0pt;margin-left:0in;line-height:normal;background:white'><span lang=TR
                                                                  style='font-size:12.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>&nbsp;</span></p>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 9<br>
Hizmet Verenler için Meslek Profili Oluşturma</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>9.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>En az 18 yaşında olan ve temyiz kudretini haiz herhangi
bir Kullanıcı kayıt formunda talep edilen bilgileri doğru ve eksiksiz olarak
doldurarak işbu Kullanıcı Sözleşmesi koşullarını onayladıktan sonra kabul
edilen koşul ve içeriğe uygun bir Meslek Profili oluşturup Hizmet Veren (Hizmet
Sağlayıcı) sıfatı kazanabilir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>9.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Meslek Profili oluşturmak için isim, marka, unvan,
iletişim bilgisi, vergi dairesi, vergi numarası gibi kayıt anında istenen
bilgiler eksiksiz ve açık olarak verilmelidir. Meslek Profili ile ilgili
hizmetleri vermek için gerekli izne, ruhsata, lisansa (varsa) ve nitelik,
deneyim ve kabiliyete sahip olduğunu kanıtlayacak ek belge, ehliyet, diploma,
servis yetki belgesi, ticaret sicil belgesi, oda kaydı gibi evrakın ve
referansların da girişi yapılmalıdır ve bu belgelerin aslı veya noter onaylı
sureti yonetimfirmasi.com tarafından istenildiği takdirde ibraz edilmelidir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>9.3.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Yönetmelik Madde 5/4 gereği,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>9.3.1.&nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>&nbsp;yonetimfirmasi.com
üzerinden hizmet satışı yapan ve <b>tacir veya esnaf olan</b> hizmet sağlayıcı,
şu bilgileri eksiksiz olarak bulundurmak zorundadır: (i) Ticaret unvanı,
işletme adı veya tescilli marka adı bilgilerinden en az biri. (ii) Tebligata
elverişli KEP adresi. (iii) Esnaflar için vergi kimlik numarası, tacirler için
MERSİS numarası. (iv) Merkez adresi ve onaylanmış telefon numarasının&nbsp; yonetimfirmasi.com’da
bulunduğuna ilişkin bilgi.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>9.3.2.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
yonetimfirmasi.com üzerinden hizmet satışı yapan ve <b>tacir veya esnaf olmayan</b>
hizmet sağlayıcı, şu bilgileri eksiksiz olarak bulundurmak zorundadır: (i) Adı
ve soyadı. (ii) İkametgâhının bulunduğu il. (iii) Merkez adresi ve onaylanmış
telefon numarasının&nbsp; yonetimfirmasi.com’da bulunduğuna ilişkin bilgi.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>9.4.&nbsp;&nbsp; </span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Hizmet Veren ile ilgili şartlar ve Hizmet Veren’in
yükümlülükleri, işbu Kullanıcı Sözleşmesi’nde detaylı bir şekilde
belirtilmektedir. Hizmet sonucunda vermesi gereken evrak, fatura, fiş dahil
ancak bunlarla sınırlı olmaksızın kanuni mevzuat dahilinde sair tüm evrakı da
hizmetin ifası ile birlikte Hizmet Alan’a iletmek Hizmet Veren’in sorumluluğundadır.
yonetimfirmasi.com’un söz konusu belgelerin teminine ilişkin olarak herhangi
bir sorumluluğu bulunmamaktadır. Hizmet Veren’in kayıtlı olduğu vergi dairesine
bildireceği kazanç beyanları, kendisinin yasal sorumluluğunda ve
yükümlülüğündedir. </span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 10<br>
Meslek Profili, Hizmet Talebi ve Tekliflerin İçeriği</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>10.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Meslek Profilleri, Hizmet Talepleri ve Teklifler ve
taraflarca verilen bilgi, belge ve beyanlar (a) herhangi bir üçüncü kişinin,
telif hakkı, patent, marka gibi fikri mülkiyet haklarını veya diğer haklarını
ihlal etmeyecek; (b) yürürlükteki hiçbir kanun veya ikincil mevzuatı (ihracat
denetimi, tüketici koruma, haksız rekabet veya yanıltıcı reklama ilişkin
olanlar vb.) ihlal etmeyecek; (c) genel ahlak ve kamu düzenine aykırı, dürüst
ve doğru olmayan, aldatıcı, yanıltıcı veya üçüncü kişilerin tecrübe ve bilgi
noksanlıklarını istismar edici, can ve mal güvenliğini tehlikeye düşürücü, kamu
sağlığını bozucu, hastaları, yaşlıları, çocukları ve özürlüleri istismar edici
beyan ve tanıtım ifadeleri içermeyecek; (d) lisansa, izne veya ruhsata bağlı
ifa edilebilen hizmetlerden olup da lisanssız, izinsiz veya ruhsatsız şekilde
hizmet sağlanarak diğer lisanslı, izinli veya ruhsatlı kişi ve kurumlarla
haksız rekabet yapmayacak, (e) tescilli markaların ve/veya tescilsiz olsa bile
marka işaretlerini haksız yere kullanmayacak, hukuka aykırı olarak başka bir
firmanın bayisi, distribütörü ve yetkili servisi gibi beyanda bulunmayacak, (f)
onur kırıcı, karalayıcı, tehditkâr veya taciz edici nitelikte olmayacak; (g)
müstehcen olmayacak veya çocuk pornografisi içermeyecek ve (h) virüs, Truva atı
gibi zararlı yazılımları veya herhangi bir sistem, veri veya kişisel bilgiye
zarar vermeyi amaçlayan, zarar veren bilgisayar programcılığı uygulamalarını
içermeyecektir. Aksi halde yonetimfirmasi.com’un sorumluluğu bulunmayıp, söz
konusu sorumluluk ilgili Hizmet Veren’e veya Kullanıcı’ya aittir. Yapılan
uygulamayla ya da meslekle ilgili mevzuata aykırı bir durum olduğu takdirde yonetimfirmasi.com
Hizmet Veren profilinde değişiklik yapma, profili silme, eksiklik giderilene
kadar askıya alma ve Hizmet Veren’in Web Sitesi’ne tekrar kaydolmasını
engelleme hakkını saklı tutar.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>10.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Meslek Profilleri, Hizmet Talepleri ve Tekliflere ilişkin
her türlü sorumluluk ilgili Hizmet Veren, Hizmet Alan veya Kullanıcı’ya ait
olup yonetimfirmasi.com’un hiçbir sorumluluğu bulunmamaktadır.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 11<br>
Ödeme</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>11.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Online Ödeme Sistemi’ne yonetimfirmasi.com’un iş birliği
yaptığı ödeme kuruluşunun aracı olduğu hallerde; ödeme kuruluşu ile Hizmet Alan
ve Hizmet Veren arasındaki ilişki yonetimfirmasi.com’dan bağımsız olup ilgili
mevzuat gereği öngörülen yükümlülüklerin yerine getirilmesi ve sorumluluk
ilgili ödeme kuruluşuna aittir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>11.2.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
yonetimfirmasi.com’un, Online Ödeme Sistemi ile ödemesi yapılan hizmetlerin
ilgili Hizmet Alan’a eksik veya kusurlu ifası, Hizmet Talebi’ne uygun Hizmet
Veren bulunamaması veya hizmetin iptali halinde ilgili tutarın Hizmet Veren’e
iletilmemesi için ödeme kuruluşuna talimat verme ve/veya ilgili Hizmet Talebini
iptal etmek hakkı saklıdır.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>11.3.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Online Ödeme Sistemi için ödeme kuruluşları ile
anlaşıldığı takdirde yonetimfirmasi.com yalnızca ilgili bedellerin
ödenmesi/iadesi için ilgili kuruluşa gerekli talimatları iletmekle yükümlüdür.
İlgili ödeme kuruluşu tarafından Kullanıcı bilgisi ve gerekli diğer tüm
bilgilerin saklanması ve güvenli bir şekilde tutulması ve yapılan işlemlerin
güvenli bir şekilde gerçekleştirilmesi ilgili ödeme kuruluşunun
yükümlülüğündedir.</span></p>

                  <p class=MsoNormal style='margin-top:24.0pt;margin-right:0in;margin-bottom:
24.0pt;margin-left:0in;line-height:normal;background:white'><span lang=TR
                                                                  style='font-size:12.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>&nbsp;</span></p>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 12<br>
Teklif Modeli’nde Ödeme</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>12.1.&nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>&nbsp;Hizmet
Alanlar kabul ettikleri Teklif’e ilişkin hizmet bedelini, hizmetin ifası
sonrasında Hizmet Veren’e doğrudan ödeme yaparlar. Hizmet Alanlar, ödedikleri
bedelin faturası, satış fişi veya irsaliyesini Hizmet Verenden talep etmelidir.
Hizmet Alanlar, Hizmet Veren ile yazılı sözleşme yapmalı, eğer bir ön ödeme
veya avans verecekse belgesini veya dekontunu almak ve saklamak
zorundadır.&nbsp;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>12.2. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Hizmet
Verenler,<b> </b>Online Ödeme Sistemi’ni kullanarak banka kartı kredi kartı
veya benzer bir ödeme aracı ile yonetimfirmasi.com’a tanımlı hesaplarına yonetimfirmasi.com’dan
alacakları hizmete mahsus bakiye yüklemesi yaparlar. Online Ödeme Sistemi ile
ödeme yapılan durumlarda, kartın hamili haricinde bir başkası tarafından hukuka
aykırı şekilde kullanılması halinde 23.02.2006 tarihli 5464 sayılı Banka Kartları
ve Kredi Kartları Kanunu ve 10.03.2007 tarihli ve 26458 sayılı Resmi Gazete’de
yayımlanan Banka Kartları ve Kredi Kartları Hakkında Yönetmelik hükümlerine
göre işlem yapılır.&nbsp;&nbsp;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>12.3.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Online Ödeme Sistemi kullanıldığında hizmet karşılığı
fiş/fatura veya düzenlenmesi gerekli diğer belgeler, ilgili mevzuat gereği
düzenleme yükümlülükleri bulunuyorsa ilgili Hizmet Veren tarafından düzenlenir.
Söz konusu hizmete ilişkin fatura/fiş veya diğer belgeler yonetimfirmasi.com’dan
talep edilemeyecek olup yonetimfirmasi.com yalnızca kendi verdiği hizmetlere
ilişkin olarak Komisyon Bedeli ve Teklif Verme Ücreti için Hizmet Veren’lere
fatura kesmekle yükümlüdür.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>12.4. </span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Hizmet
Veren, Bakiye’sine yaptığı yükleme ile Teklif Ücreti ödeyerek teklif verebilir.
İş kazandığında Komisyon Ücretleri bu Bakiyesi’nden tahsil edilir. yonetimfirmasi.com
Hizmet Veren’in platform aktivitelerine göre bir Kredi Limiti tanımlayabilir.
Bu Kredi Limiti ile birlikte Hizmet Veren hesabında görebileceği Kullanılabilir
Bakiye’si tutarında teklif vermeye devam edebilir. Bu durumlarda Bakiye ve/veya
Kullanılabilir Bakiye tutarı negatife (eksiye) düşebilir. Hizmet Veren
Kullanılabilir Bakiye tutarını pozitife (artıya) çıkarmadan hesabına dair
herhangi bir değişiklik ya da kapatma talebinde bulunamaz. yonetimfirmasi.com,
Kullanılabilir Bakiye’si negatif (eksi) olan ve bunu kapatmayan Hizmet Verenler
için yasal işlem başlatma hakkını saklı tutar.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal style='margin-top:24.0pt;margin-right:0in;margin-bottom:
24.0pt;margin-left:0in;line-height:normal;background:white'><span lang=TR
                                                                  style='font-size:12.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>&nbsp;</span></p>

                  <p class=MsoNormal align=right style='text-align:right;line-height:normal;
background:white'><span lang=TR style='font-size:16.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>Madde 13</span></p>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Hizmet
Bedeli İadesi / Cayma Hakkının Kullanılması</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>13.1.&nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>&nbsp;Teklif
Modeli’nde Hizmet Alan, hizmetin ifa edilmemiş olması ve hizmete başlanmamış
olması şartıyla, Hizmet Veren ile anlaşamamaları durumunda herhangi bir gerekçe
göstermeksizin ve cezai şart ödemeksizin sözleşmeden cayma hakkına sahiptir.
Hizmet Bedeli iadesi ilgili Hizmet Veren tarafından yapılacak olup yonetimfirmasi.com’dan
talep edilemez. Hizmet Alan Web Sitesi üzerinden Hizmet Talebi’ni iptal ederek yonetimfirmasi.com’u
bu durumdan haberdar etmelidir..</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>13.2. </span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>&nbsp;&nbsp;Teklif
Modeli’nde, yonetimfirmasi.com Hizmet Veren ve Hizmet Alan arasında ödeme,
hizmet iptali, indirim veya ücret iadesi gibi konulara ilişkin doğabilecek
anlaşmazlıklarda hiçbir sorumluluk kabul etmemektedir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>a) Hizmet Talebi’nin veya Anlaşmaya Varılan İş’in usulüne
uygun şartlarda veya mücbir sebep hallerine dayalı olarak zorunlu iptali;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>b) Hizmet Talebi’nin ilgili Hizmet Veren’e iletilememesi
nedeniyle Hizmet Talebi’nin zorunlu iptali;</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>13.4.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Online Ödeme Sistemi seçeneği dışındaki ödeme vasıtaları
ile ödemesi yapılmış Hizmetlerde hizmet bedeli iadesi, Hizmet Veren tarafından
doğrudan yapılmaktadır.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='text-align:right;line-height:normal;
background:white'><span lang=TR style='font-size:16.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>Madde 14</span></p>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Hizmet
Sorumluluğu, Garanti Verilmemesi ve İlişkinin Bağımsızlığı</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.1.&nbsp;&nbsp;</span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'> Teklif Modeli’nde<b> </b>yonetimfirmasi.com’un Hizmet
Alan ile Hizmet Veren arasındaki teklif, icap, kabul, sözleşme ve ödeme
aşamalarında herhangi bir sorumluluğu bulunmamaktadır. yonetimfirmasi.com,
Hizmet Alan ve Hizmet Veren arasında uyum olacağını veya Hizmet Alan’ın
bölgesinde, Hizmet Alan’ın işini istenen zamanda ve yerde yapmaya muktedir
Hizmet Veren bulacağını ya da bulunduracağını garanti etmez. Hizmet Alanlar
Hizmet Veren hakkında gerekli araştırmayı kendileri yapmalıdırlar.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Web Sitesi aracılığı ile Hizmet Verenler’den alınacak
hizmetlere ilişkin her türlü sorumluluk Hizmet Verenlere aittir. yonetimfirmasi.com’un
hiçbir sorumluluğu bulunmaz.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.3.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com, Hizmet Veren'i veya hizmetlerini
tasdik veya tavsiye etmez, çalışma performansını ya da verilen hizmetlerin
sonucu veya kalitesini garanti etmez. yonetimfirmasi.com, Üye oylamaları ve Üye
yorumları gibi sistem içindeki bazı algoritmalar aracılığıyla Hizmet Veren’ler
arasında bir sıralama, derecelendirme ve kategorilendirme yapabilir, bazı
Hizmet Veren’leri kullanıcılar tarafından çokça beğenilmiş, tercih/tavsiye
edilmiş veya memnun kalınmış olması sebebiyle ön plana çıkarabilir. Ancak söz
konusu durum, yonetimfirmasi.com’un vermiş olduğu bir tasdik veya garanti
anlamına gelmemektedir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.4.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com, Hizmet Veren ve Hizmet Alan
arasındaki ilişkiden sorumlu olmayıp, Hizmet Veren’in sağlayacağı hizmet
sırasında veya herhangi bir zamanda Hizmet Alan veya 3. kişilere vereceği
zararlardan yonetimfirmasi.com’un hiçbir sorumluluğu bulunmamaktadır..&nbsp;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.5.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com Hizmet Verenlerin güvenilirliği,
ilgili hizmeti sağlamak için uygun ve yetkin olduğu, hizmetlerin verilmesi veya
zamanında verilmesi, güvenli ve hatasız olması, hizmet kullanımından elde
edilecek sonuçların yeterliliği veya güvenilirliği veya hizmet kalitesinin
beklentilere cevap vermesi gibi konularında hiçbir garanti veya taahhütte
bulunmamaktadır. </span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.6.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com, herhangi bir sorumluluğu
bulunmamasına rağmen, Hizmet Veren’lerin sağladığı hizmetlerin doğru ve tam
olarak ifasını sağlamak için elinden gelen gayreti sarf edecektir. Ancak,
Hizmet Veren’lerin ağır ihmal veya kusuru nedeniyle Hizmet Alan’ları ve 3. kişileri
herhangi bir şekilde zarara uğratması ve/veya bu konudaki dava ve takiplerin yonetimfirmasi.com’a
yönelmesi halinde, yonetimfirmasi.com, tüm zararlar ve ayrıca yargı giderleri,
para cezaları ve avukatlık ücretleri için Hizmet Veren’e rücu veyahut yonetimfirmasi.com’daki
hak ve alacaklarından takas / mahsup etme hakkını saklı tutmaktadır.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.7.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
yonetimfirmasi.com, Hizmet Veren’lerin belirlenen tarih ve saatte hizmetin
ifası için Hizmet Alan’a anlaşılan işe gitmemesi veya başlamaması durumunda
Hizmet Veren’e farklı şekillerde yaptırımlar uygulama hakkını saklı tutar. Bu
yaptırımlar, Hizmet Veren profilinde değişiklik yapma, profili silme, eksiklik
giderilene kadar askıya alma ve Hizmet Veren’in Web Sitesi’ne tekrar
kaydolmasını engelleme ve tazminat talebini kapsayabilir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.8.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Hizmet Veren tarafından Meslek Profilinde belirtilen
bilgi veya beyanatların doğruluğu Hizmet Veren tarafından taahhüt edilmektedir,
yonetimfirmasi.com’un hiçbir sorumluluğu bulunmaz.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.9. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Hizmete
ilişkin olarak yürürlükteki mevzuat kapsamında temin etmesi gereken her türlü
izin, onay, kontrol belgesi, ruhsat vb. belgeye ilişkin sorumluluk Hizmet
Verenlere ait olup, aksi takdirde doğabilecek her türlü idari, hukuki ve cezai
sorumluluk Hizmet Veren’e aittir. yonetimfirmasi.com’un ve 3. kişilerin bu
nedenle uğradığı ve/veya uğrayacağı zararlardan sorumluluk ve her türlü zararın
tazmin yükümlülüğü Hizmet Verenlere aittir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.10. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>yonetimfirmasi.com
Hizmet Alan’a ulusal, yerel veya diğer resmi dairelerden ya da üçüncü
şahıslardan gelen bilginin doğru, hatasız veya güncel olduğunu ya da Hizmet
Alan’ın söz konusu bilgiyi kontrol ettiği tarihte güncel ve aktüel olduğunu
beyan veya taahhüt etmemektedir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.11. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Hizmet
Veren ile Hizmet Alan arasında yapılacak hizmet sözleşmelerinden kaynaklanacak
her türlü vergi, resim, harç, ödeme ve benzeri yükümlülüklerden taraflar
doğrudan kendileri sorumludur. yonetimfirmasi.com tarafından işletilen Web
Sitesi’nde listelenen hizmetler ve ürünlerden dolayı, yonetimfirmasi.com,
Tüketicinin Korunması Hakkında Kanun ve ilgili yasal mevzuat kapsamında,
satıcı, sağlayıcı, imalatçı, üretici, bayi, acente, reklamcı veya mecra
kuruluşu statüsünde değildir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.12. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>yonetimfirmasi.com,
sisteminde kayıtlı Hizmet Alanların isim, adres ve telefon numarası gibi
kişisel verilerinin Teklif oluşturulması veya ilgili hizmetin verilmesine
yönelik olarak Hizmet Verenler ile paylaşılmasından dolayı Hizmet Alan ve
Hizmet Veren(ler) arasında ortaya çıkabilecek sorunlardan veya oluşabilecek
zarardan kesinlikle sorumlu değildir. Hizmet Alan ve Hizmet Veren, işbu
sözleşme kapsamındaki hizmetlerin pazarlanması ve yerine getirilmesi için
kişisel verilerinin işlenmesine ve işbu sözleşmedeki amaçlara uygun olarak
paylaşılmasına muvafakat etmişlerdir. 6698 sayılı Kişisel Verilerin Korunması
Kanunu’nun 5(c) ve 5(f) maddelerine göre, Hizmet Alan ve Hizmet Veren’lerin
kişisel verilerinin işlenmesi ve sadece sözleşme tarafları arasında
paylaşılması, açık rıza alınmasını gerektirmemektedir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.13. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Hizmet
Alan bilgileri yonetimfirmasi.com tarafından Hizmet Veren ile hizmetin
sağlanması veya Teklif oluşturulması için paylaşılmaktadır. Bu bilgi paylaşımı
ile hizmetin sorunsuz sağlanması amaçlanmaktadır. Söz konusu bilgilerin Hizmet
Veren tarafından ayrıca Hizmet Alan’ın onayı alınmadığı hallerde reklam,
pazarlama, kişisel vb. herhangi bir durum veya amaç için kullanılması, üçüncü
kişilerle paylaşılması veya devri veya Hizmet Alan ile Hizmet Veren(ler)
arasında ortaya çıkabilecek sorunlardan veya oluşabilecek zarardan kesinlikle
sorumlu değildir.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>14.14. &nbsp;</span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>yonetimfirmasi.com
ile Hizmet Veren arasında (a) istihdam, (b) yarı zamanlı istihdam, (c)
danışmanlık, (d) yüklenicilik, (e) ortak girişim veya (f) acentelik ilişkisi
bulunmamaktadır.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 15<br>
Kullanıcılarla İlişkiler ve İşlemler (Tüm Kullanıcılar)</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>TÜM KULLANICILARA İLİŞKİN GENEL HAK VE YÜKÜMLÜLÜKLER</span></b></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>15.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Kullanıcılar, birbirleri arasındaki ilişkilerden tamamen
kendileri sorumludur.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>15.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Kullanıcı’lar birbiriyle ya da yonetimfirmasi.com
çalışanları ile iletişim kurarken, ırkçı, herhangi bir grup veya kişiye karşı
nefret söylemi, kişilik haklarına aykırı, onur kırıcı, hakaret içeren, taciz
eden veya tacizi savunan, illegal &amp; terörist faaliyetleri öven, haksız
rekabet oluşturan, tehdit edici, müstehcen, lekeleyici, cinsel taciz oluşturan
ve iftiracı nitelikte davranışlar sergileyemez, bu yönde içerikler kullanamaz.
Aksi bir durum Kullanıcı’nın haklarının sona erdirilmesi ve gerektiğinde
durumun resmi makamlara bildirilmesini gerektirebilir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>15.3.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Gerek Hizmet Veren, gerek Hizmet Alan Kullanıcılar
hakkında, hizmetin öncesi, hizmetin görülmesi ve hizmet sonrasında, herhangi
bir suç oluşturan davranışlardan dolayı bir soruşturma açılırsa veya yargılama
yapılırsa, yonetimfirmasi.com elindeki tüm bilgi ve belgeleri talep üzerine
ilgili yargı makamlarıyla paylaşacaktır.&nbsp;</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>15.4.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
Hizmet Alan veya Hizmet Veren’ler, kendileri veya bir başkası için hizmet
almadığı veya sağlamadığı halde, lehte veya aleyhte yorum yazamaz, bir
başkasının iş ürünleri, markası, ticari ünvanı ve hizmetleri hakkında haksız
rekabet yaratacak şekilde içerik yazamaz.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 16<br>
Hizmet Alan'ın Yükümlülükleri</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>16.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Hizmet Alan’ın işbu Sözleşme koşullarına uymaması
nedeniyle doğabilecek her türlü idari, hukuki ve cezai sorumluluk bizzat Hizmet
Alan’a aittir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>16.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Teklif Modeli’nde<b> </b>Hizmet Alan, Hizmet Talebi için
yalnız bir Teklifi kabul edebilir. Teklifin kabul edilmesi, Hizmet verildiği
takdirde Hizmet Veren’e ödeme yapmak için yasal olarak bağlayıcı bir anlaşma
yapıldığı anlamına gelir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>16.3.&nbsp; &nbsp;</span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Teklif Modeli’nde <b>&nbsp;</b>Hizmet Alan ve Hizmet
Veren Teklif üzerinde anlaştığında, Hizmet Alan aldığı Hizmet karşılığında
Hizmet Veren’e Teklif’te belirtilen tutarı doğrudan ödeyeceğini kabul
eder.&nbsp;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>16.4. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Hizmet
Alan, Hizmet Veren ile yaptığı sözleşmede, yonetimfirmasi.com’un hiçbir şekilde
sözleşmenin tarafı olmadığını ve sorumluluğu bulunmadığını kabul eder.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>16.5.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Hizmet Alan, kredi kartı bilgilerinin mevzuat kapsamında
izin verildiği ölçüde olmak kaydıyla, yonetimfirmasi.com’un anlaşmalı olduğu
ödeme kuruluşu sisteminde veya “ilk 6 son 4 rakamı” ile yonetimfirmasi.com
sisteminde saklanması ve sistem işleticileri ile paylaşma yetkisine sahip
olduğunu kabul eder. Anlaşmalı ödeme kuruluşu sisteminde oluşabilecek
aksaklıklardan yonetimfirmasi.com sorumlu değildir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>16.6. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Hizmet
Alan, hizmete ilişkin olarak kendisine düşen tüm vergilerden, yonetimfirmasi.com’un
gelirine bağlı oluşan vergiler hariç olmak üzere sorumludur.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>16.7. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Hizmet
Alan, bazı hizmetlerin Hizmet Veren tarafından doğru fiyatlandırma
yapılabilmesi için,, hizmetin görüleceği veya hizmetin görülmesi için keşif
yapılacak yere; Hizmet Veren veya personelinin girişine, keşif için yerin
fotoğraflarının çekilmesine izin vereceğini, bu izin bir başkasına bağlıysa bu
izni sağlayacağını kabul eder.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>16.8. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Bazı
hizmetlerin ifa edilebilmesi için resmi makamlardan veya bina yöneticilerinden
izin alınması gerekebilir. Veya bazı hizmetler, belirli gün ve saatlere bağlı
olarak ifa edilebilir. Hizmet Alan, gerekli izinleri sağlayacağını ve sadece
öngörülen gün ve saatler için hizmet alabileceğini kabul eder.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>16.8. </span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> Hizmet
Alan’ın bu işler için vergi dairesine herhangi bir bildirimde bulunmasına,
ücretten stopaj yapılmasına ve Hizmet Veren tarafından herhangi bir beyanname
verilmesine gerek bulunmamaktadır. yonetimfirmasi.com sadece kendi hizmet
komisyonuyla ilgili olarak Hizmet Alan’a fatura kesmek mükellefiyetindedir.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 17<br>
Hizmet Veren’in Yükümlülükleri</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>17.1.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
Hizmet Veren’in işbu Sözleşme koşullarına ve Hizmet Alan’a karşı üstlendiği ifa
yükümlülüklerine uymaması nedeniyle doğabilecek her türlü idari, hukuki ve
cezai sorumluluk bizzat Hizmet Veren’e aittir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>17.2</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>.
&nbsp; Teklif Modeli’nde Hizmet Veren’in Hizmet Talebi için verdiği teklif
Hizmet Alan tarafından kabul edilebilir. Teklifin kabul edilmesi, Hizmet’in
Hizmet Veren tarafından anlaşılan zamanda ve yerde yapılacağına dair yasal
anlaşma yapıldığı anlamına gelir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>17.3.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
Hizmet Veren, Hizmet Alan ile yaptığı sözleşmede, yonetimfirmasi.com’un hiçbir
şekilde sözleşmenin tarafı olmadığını ve sorumluluğu bulunmadığını kabul eder.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>17.4.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
Hizmet Veren, kredi kartı bilgilerinin mevzuat kapsamında izin verildiği ölçüde
olmak kaydıyla, yonetimfirmasi.com’un anlaşmalı olduğu ödeme kuruluşu
sisteminde veya “ilk 6 son 4 rakamı” ile yonetimfirmasi.com sisteminde
saklanması ve sistem işleticileri ile paylaşma yetkisine sahip olduğunu kabul
eder. Anlaşmalı ödeme kuruluşu sisteminde oluşabilecek aksaklıklardan yonetimfirmasi.com
sorumlu değildir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>17.5.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
Hizmet Veren’in kayıtlı olduğu vergi dairesine bildireceği kazanç beyanları,
kendisinin yasal sorumluluğunda ve yükümlülüğündedir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>17.6.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
Hizmet Veren, işin ifası sırasında veya işin ifası için gerekli iş güvenliği ve
iş sağlığına ilişkin bütün tedbirleri alacağını, kendisinin ve personelinin bu
konuda gerekli eğitimleri aldığını ve bu konudaki sorumlulukların yonetimfirmasi.com’a
ait olmadığını kabul eder.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>17.7. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Hizmet
Alan, yonetimfirmasi.com’un kusurlu olduğu haller dışında, herhangi bir maddi
veya manevi zararı için ve/veya ayıplı mal / ayıplı hizmet için Tüketici Hakem
Heyetlerine ve/veya Tüketici Mahkemelerine başvurur ve hasım olarak Hizmet
Veren yerine yonetimfirmasi.com’u gösterirse, yonetimfirmasi.com öncelikle en
iyi şekilde savunmasını yapmakla ve ilgili talebi doğru yere yönlendirmekle
mükellef olup, tüm savunmasına rağmen Hakem heyeti kararı veya Tüketici
Mahkemesi kararında Hizmet Alan lehine, yonetimfirmasi.com aleyhine bir
tazminat veya ceza çıkması durumunda, Hizmet Veren bu tazminatı / cezayı
ferileriyle birlikte (yargı ve icra harçları, gecikme faizleri ve karşı taraf
vekalet ücreti) yonetimfirmasi.com’a aynen ödeyecektir. </span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 18<br>
yonetimfirmasi.com'un Yetki ve Yükümlülükleri</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.1. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>yonetimfirmasi.com
sistemin çalışmasını geçici bir süre askıya alabilir veya tamamen durdurabilir.
Kullanıcılar, Web Sitesi'nin kullanımına ilişkin olarak yonetimfirmasi.com’a
herhangi bir kullanım ücreti ödememektedirler, söz konusu nedenle yonetimfirmasi.com’dan
sistemin durdurulması veya askıya alınması nedeniyle herhangi bir talepte
bulunmayacaklardır.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.2. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>yonetimfirmasi.com
veya iş birliği yaptığı ödeme kuruluşu güvenlik şüphesi doğuran Hizmet Alan ve
Hizmet Veren işlemlerinden dolayı ilgili Kullanıcıların kredi kartı ile online
ödeme yapma imkânını geçici bir süre askıya alabilir veya tamamen durdurabilir.
Söz konusu nedenle yonetimfirmasi.com’un Kullanıcılarına veya 3. kişilere karşı
hiçbir sorumluluğu bulunmamaktadır.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.3. &nbsp;</span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>yonetimfirmasi.com,
Web Sitesi'nin kullanılması ile oluşacak tüm verilerin fikri haklarına
sahiptir. yonetimfirmasi.com, söz konusu bilgilerle Kullanıcı bilgilerini
açıklamaksızın demografik bilgiler içeren raporlar düzenleyebilir veya bu tarz
bilgileri veya raporları kendisi kullanabilir veya bu rapor ve/veya
istatistikleri iş ortakları ile üçüncü kişilerle bedelli veya bedelsiz
paylaşabilir. Bu işlemler yonetimfirmasi.com’un gizlilik politikası hükümlerine
aykırılık teşkil etmez.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.4. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>yonetimfirmasi.com
Kullanıcılarına promosyonlar ile yeni hizmet veya projeler veya haberleri
e-posta veya push bildirim yolu ile haberdar edebilir. Kullanıcıların söz
konusu e-postaları almak istememesi halinde [destek@yonetimfirmasi.com]
adresine yazılı bildirimde bulunarak veya kendisine ulaşan ticari iletişim
kanalı üzerinden söz konusu bildirimleri almayı durdurabilir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.5. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Kullanıcılar
arasında fikri hakların ihlaline ilişkin herhangi ihtilaf olduğu takdirde yonetimfirmasi.com,
kendisine ibraz edilecek kesinleşmiş ve icra edilebilir bir mahkeme kararına
istinaden işlem yapmakla yükümlüdür. Diğer hallerde, yonetimfirmasi.com kendi
takdirinde olmak üzere işlem yapar.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.6.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Kullanıcılardan Hizmet Veren’e ilişkin olarak gelen
yorumlar/değerlendirmeler, yonetimfirmasi.com tarafından yapılacak gerekli
onay, kontrol ve düzeltme akabinde tüm Kullanıcıların görebileceği şekilde
yayınlanır. yonetimfirmasi.com’un söz konusu yorumları düzeltme, sıralama ya da
yayımlayıp yayımlamama yetkisi vardır. yonetimfirmasi.com, önceden haber
vererek veya vermeden dilediği zaman Web Sitesi’ni (veya bir kısmını) geçici
veya kalıcı olarak değiştirme veya sonlandırma hakkını saklı tutar.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.7.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Web Sitesi’nin bütünlüğünü korumak amacıyla, yonetimfirmasi.com
dilediği zaman kendi inisiyatifine dayanarak, bazı Kullanıcı’ların ve belirli
İnternet Protokolü adreslerindeki Kullanıcıların Web Sitesi’ne erişmelerini
engelleyebilir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.8.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Hizmet Veren ve Hizmet Alan, Web Sitesi’ne yüklemiş
oldukları içeriklerden 5651 sayılı Yasa’nın 4. Maddesine göre hukuki ve cezai
olarak sorumludur. İçeriklerin, yonetimfirmasi.com tarafından yayınlanmış
olması Hizmet Veren ve Hizmet Alan’ın sorumluluğunu kaldırmamaktadır.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.9. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>yonetimfirmasi.com
hizmetlerin bazılarını veya tamamını ileride ücretli veya ücretsiz yapma
hakkını saklı tutar. Bazı hizmetlerin ücretlendirme ve komisyon politikası
satın alınan veya sunulan hizmetlerin sayısı, yoğunluğu veya niceliğine göre
zaman zaman değişiklik gösterebilir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.10. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>yonetimfirmasi.com,
dilerse Kullanıcıların e-posta adresini, cep telefon numarasını ve diğer
bilgileri doğrulamak amacıyla SMS, e-posta veya diğer teknik araçlar
kullanabilir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.11. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>yonetimfirmasi.com
Üyelerin işbu Sözleşmeyi ihlal ettiğinin tespit edilmesi halinde ya da durumun
gerektirdiği ölçüde hiçbir sebep göstermek zorunda olmaksızın Web Sitesi’ni
kullanmaktan ve Üyelik haklarına erişimden men edebilir, Üye’liği askıya
alabilir, geçici olarak kullanımı durdurabilir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.12. &nbsp; </span></b><span lang=TR style='font-size:
9.0pt;font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Gelir
İdaresi Başkanlığı’nca getirilen yasal düzenlemeye uygun olarak yonetimfirmasi.com’da
e-fatura ve e-arşiv fatura uygulamalarına geçilmiştir. E-fatura kullanıcısı
olmayan Kullanıcı’ların e-arşiv faturaları elektronik ortamda oluşturulacak ve
elektronik ortamda muhafaza edilecektir. Elektronik ortamda oluşturulan
faturalar ile ilgili bildirim en geç 7 gün içerisinde Kullanıcı’ların mail
adreslerine yapılacak ve faturalar PDF formatında e-posta yolu ile
gönderilecektir. Elektronik ortamda oluşturulan faturalar, tüm resmi makam ve
merciler nezdinde yasal belge olarak kullanılabilir.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>18.13.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>&nbsp;&nbsp;
24 Aralık 2015 tarihli ve 29572 sayılı Resmî Gazete’de yayınlanan Vergi Usul
Kanunu Genel Tebliği’ne (Sıra No: 464) göre Aracı Hizmet Sağlayıcı olan yonetimfirmasi.com;
01.09.2021 tarihinden itibaren takvim yılının birer aylık süreleri içerisinde
gerçekleşen işlemlere ilişkin olarak; (i) Aracılık hizmetinin sağlandığı
internet adres veya adreslerini, (ii) Aracılık hizmeti verilen gerçek ya da
tüzel kişilere ait ad soyad/unvan, TCKN/VKN bilgileri ile işyeri adres
bilgilerini, (iii) Aracılık hizmeti verilenler adına gerçekleştirilen mal ve
hizmet satış/kiralama işlemlerine ilişkin her bir tahsilat tutarı ve tarihini,
Gelirler İdaresi Başkanlığı’nın BTRANS sistemi aracılığıyla elektronik ortamda
iletmekle mükelleftir.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 19<br>
Web Sitesi İçeriği</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Yürürlükteki kanunlar uyarınca yasal olarak müsaade
edildiği ölçüde,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>19.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com Web Sitesinin hatasız, kesintisiz ve
güvenli olacağını ya da Web Sitesinin ya da üzerindeki herhangi bir içerik,
arama veya bağlantının kullanımının belirli sonuçlar sağlayacağını taahhüt
etmez ve</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>19.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com, Web Sitesinden indirilen herhangi bir
dosyanın virüs ya da diğer kirli ya da bozucu özellikler taşımayacağını garanti
edemez.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>Madde 20<br>
Sorumluluk Sınırlamaları</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>20.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Yürürlükteki kanunlar uyarınca yasal olarak müsaade
edildiği sürece,yonetimfirmasi.com, Web Sitesi ya da web sitesinin kullanımıyla
ilgili olarak, herhangi bir üçüncü şahsın, Web Sitesi kullanıcılarının, reklam
verenlerin ve/veya sponsorların fiil, ihmal ve davranışlarına ilişkin sorumlu
değildir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>20.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com, Web Sitesi’nin işletiminden veya
koşullarının uygulanmasından doğan hiçbir veri kaybından sorumlu değildir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>20.3.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com koruma amaçlı makul tedbirleri
almaktadır. Ancak kendisine ait bilgisayar ağına ve bu ağdaki mevcut veri
tabanı bilgilerine yapılabilecek saldırılar sonucu Kullanıcı bilgilerinin kötü
amaçlı kişilerin eline geçmesi ve bunların kötü niyetli kullanılması halinde
doğabilecek sonuçlardan dolayı sorumluluk kabul etmez.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>20.4.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com 3. kişilerin Web Sitesi’nin kullanımı
ile ilgili davranışı sonucunda ortaya çıkan, bedensel zarar, duygusal
rahatsızlık gibi fakat bunlarla sınırlı olmamak üzere, doğrudan veya dolaylı,
maddi veya manevi her türlü zararı ve/veya bir Hizmet Veren’in verdiği
hizmetlerden veya Online Ödeme Sistemi haricinde bir Hizmet Alan’ın verilen
hizmet karşılığında Hizmet Veren’e ödeme yapmamasından dolayı doğabilecek
zararlardan sorumluluk kabul etmez.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>                                                                                                                      </span></b><span
                    lang=TR style='font-size:16.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Madde 21<br>
Telif Hakkı Politikası</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>&nbsp;</span></b></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>21.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Web Sitesi’nde sunulan görsel ve yazılı içerik, kişisel
kullanım içindir. yonetimfirmasi.com, Web Sitesi içeriğinde yer alan bütün alan
adı, logo, grafik, ses, ikon, tasarım, metin, imge, html kodu, diğer kodlar,
demonstratif, yazılı, elektronik, grafik veya makinede okunabilir şekilde
sunulan teknik veriler, uygulanan satış sistemi, iş metodu ve iş modeli de
dahil tüm materyallerin (“Materyaller”) ve bunlara ilişkin fikri ve sınai
mülkiyet haklarının sahibi veya lisans sahibidir ve yasal koruma altındadır.
Aksi belirtilmedikçe ticari ya da kişisel amaçlarla izinsiz veya kaynak
göstermeksizin kullanılamaz. Kullanıcı’nın kendi resmi ve portföyü hariç olmak
üzere, bu sitede yer alan herhangi bir unsuru diğer bir mecrada veya internet
sitesinde yayınlaması yasaktır.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>21.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Bu sayfaların tasarımında ve veri tabanı oluşturulmasında
kullanılan yazılımın hakkı yonetimfirmasi.com’a aittir. Bahsi geçen yazılımın
kopyalanması veya kullanılması, kullanılan yazılımların ve teknolojilerin
tersine mühendislik işlemlerine tâbi tutulması kesinlikle yasaktır.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>21.3.&nbsp;&nbsp;</span></b><span lang=TR
                                                        style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com’a iletilen tüm yorum ve eleştirilerin
telif hakları yonetimfirmasi.com’a aittir. yonetimfirmasi.com söz konusu
yorumlar üzerinde çeşitli değişiklikler yapmak, yorumları silmek veya tamamen
kaldırmak hakkını saklı tutar ve yorumların bazılarını yayımlamayabilir. yonetimfirmasi.com,
kullanım şartları, gizlilik prensipleri ve geçerli yasal düzenlemelere bağlı
kalmak kaydıyla, kullanıcı hesabına bağlı olan bütün bilgiler, yorum ve
eleştirileri kendi pazarlama faaliyetleri ile ilgili olarak kullanma hakkını
saklı tutar.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>                                                                                                                                  </span></b><span
                    lang=TR style='font-size:16.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Madde 22<br>
Web Sitesi Üzerindeki İçerik</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>&nbsp;</span></b></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>22.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Web Sitesi vasıtasıyla yayınlanan, fikir, tavsiye,
açıklama, inceleme, teklif veya diğer bilgi ya da içerik, ilgili yazarlara
aittir. Bahsi geçen içerikten tamamen söz konusu yazarlar sorumludur. Yonetimfirmasi.com
(i) Web Sitesi üzerindeki herhangi bir bilginin doğruluğu, bütünlüğü veya
faydasını garanti etmez veya (ii) Web Sitesi üzerinde gösterilen, herhangi bir
şahısça verilmiş fikir, tavsiye veya açıklamanın doğruluğu veya güvenilirliğini
kabul, tasdik etmez veya sorumluluk kabul etmez.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>22.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Web Sitesi yonetimfirmasi.com kontrolü altında olmayan
başka internet sitelerine bağlantı veya referans içerebilir. yonetimfirmasi.com,
bu sitelerin içerikleri veya içerdikleri diğer bağlantılardan sorumlu değildir.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>22.3.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com, Web Sitesi üzerinde yasadışı veya
yasak olacak türden içeriği, Web Sitesi’nden kaldırma ve söz konusu
ihlalcilerin üyeliğini sonlandırma hakkını saklı tutar. Bu hüküm, sayılanlarla
sınırlı olmamakla birlikte aşağıdaki türden içeriği kapsar:</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• Irkçılık, herhangi bir grup veya kişiye karşı nefret ve
fiziksel zararı teşvik eden içerik gibi, diğer Kullanıcıya açıkça saldırıcı
nitelikte olan veya hakaret içeren;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• Diğer Kullanıcıyı taciz eden veya tacizi savunan;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• “Önemsiz posta”, “zincir mektup” veya istenmeyen toplu
posta veya “spamming” iletimi içeren;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• Yanlış veya yanıltıcı olduğunu bildiğiniz bilgileri
teşvik eden;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• İllegal faaliyetleri teşvik eden veya başkası hakkında
kötüleyici ifadeler kullanan, haksız rekabet oluşturan, tehdit edici,
müstehcen, lekeleyici ve iftiracı nitelikte davranışları teşvik eden;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• Korsan bilgisayar programları veya linklerin verilmesi,
üretim esnasında konulmuş kopya korumalı cihazları atlatmaya yönelik bilgi
verilmesi veya korsan resim, ses veya video dosyaları verilmesi veya korsan
resim, ses veya video dosyalarına bağlantı verilmesi gibi, başka birinin
telifli eserinin yasadışı veya yetkisiz kopyalanmasını teşvik eden;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• Yasaklı veya şifre erişimli sayfalar veya saklı sayfa
ya da görüntüler içeren (başka bir erişilebilir siteden link olarak
verilmeyenler);</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• 18 yaşın altındaki bireyleri sömüren cinsel veya şiddet
içerikli malzemeler sağlayan veya 18 yaş altındaki bir bireyden kişisel
bilgiler talep eden;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• Yasadışı silahların üretimi veya alımı, başka birinin mahremiyetinin
ihlal edilmesi veya bilgisayar virüsleri verilmesi veya oluşturulması gibi
yasadışı faaliyetler hakkında öğretici bilgiler sağlayan;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• Ticari veya kanun dışı amaçlarla başkalarından şifre
veya kişisel tanımlayıcı bilgi talep eden;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• Önceden yazılı onayımız olmadan yarışmalar, çekilişler,
takas, reklam ve saadet zinciri gibi ticari faaliyet ve/veya satışlar içeren;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• Başkalarına ait kişisel bilgileri kayıt eden, yayan,
kötüye kullanan,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• 3. Şahısların marka ve patent gibi, fikri ve sınai
haklarını ihlal eden,</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• Haksız ticaret uygulamalarına yer veren ve rekabeti
sınırlayan, ve</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><span lang=TR
                                                                                       style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>• Ulusal ve/veya yerel tüketici koruma kanunlarını ihlal
eden.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>22.4.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
Kullanıcı,&nbsp;yonetimfirmasi.com&nbsp;üzerinde oluşturmuş olduğu profil
içeriklerinin çeşitli arama motorları tarafından indeksleneceğini, arama
sitelerinin arama sonuç ekranlarında görüntülenebileceğini ve üçüncü kişi /
kurumlar tarafından görüleceğini, profilde paylaştığı bilgilerin herhangi bir
hukuka aykırılık içermesi durumunda bizzat kendisinin sorumlu olacağını peşinen
kabul eder.&nbsp;</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>                                                                                                                      </span></b><span
                    lang=TR style='font-size:16.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Madde 23<br>
Hizmet Alan’ların Tüketici Sıfatıyla Hakları</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>&nbsp;</span></b></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>23.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Ticari veya mesleki olmayan amaçlarla hareket eden gerçek
veya tüzel kişi Hizmet Alanlar, 6502 sayılı Tüketicinin Korunması Hakkındaki Kanun
gereğince Tüketici sayılır.&nbsp;</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>23.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Tüketici sıfatına sahip Hizmet Alan, Hizmet Verenin ifa
ettiği işler ile ilgili ayıplı mal ve ayıplı hizmet konusunda, Hizmet Veren’i
muhatap göstererek, malın veya hizmetin değerine göre Tüketici Hakem
Heyetlerine veya Tüketici Mahkemelerine başvurabilir. Böyle bir durumda, yonetimfirmasi.com
Hizmet Verene ilişkin iletişim bilgilerini ilgili hakem heyetlerine veya
Tüketici Mahkemelerine sunabilir.&nbsp;</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>23.3.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com’un sunmuş olduğu yonetimfirmasi.com
Garantisi koşulları saklıdır.&nbsp;</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>                                                                                                          </span></b><span
                    lang=TR style='font-size:16.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Madde 24<br>
Uyuşmazlıkların Çözümü ve Yetkili Mahkeme</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>&nbsp;</span></b></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>&nbsp;</span></b></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>24.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>İşbu Sözleşme Türkiye Cumhuriyeti kanunlarına tabidir.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>24.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Taraflar, işbu Sözleşme’nin tatbik ve tefsirinden doğacak
her türlü uyuşmazlıkları önce kendi aralarında sulhen halletmeye gayret
ederler. Sulhen halledilemeyen uyuşmazlıkların çözümü için İstanbul (Cağlayan)
Mahkeme ve İcra Müdürlükleri’nin münhasıran yetkili olduğunu kabul ve beyan
ederler.</span></p>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><span lang=TR style='font-size:16.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>&nbsp;</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>                                                                                                          </span></b><span
                    lang=TR style='font-size:16.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Madde 25<br>
Bilgilerin Saklanması ve Delil Sözleşmesi</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>&nbsp;</span></b></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>&nbsp;</span></b></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>25.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>yonetimfirmasi.com sisteminde kayıtlı kullanıcı
bilgileri, teklifleri, yorum/değerlendirmeleri vb. en az üç (3) yıl boyunca
saklanır.</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>25.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Taraflar bu Sözleşme’den doğabilecek uyuşmazlıklarda yonetimfirmasi.com’un
ticari defter ve kayıtları ile yonetimfirmasi.com sistemlerinde saklanan
verileri her türlü uyuşmazlıkta 6100 Sayılı HMK’nın 193. Maddesi gereği kesin
delil kabul edeceğini beyan, kabul ve taahhüt ederler.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>25.3.</span></b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'> &nbsp;
Herhangi bir uyuşmazlıkta, uyuşmazlık konusu vakıaları ispata elverişli görüntü
veya ses kaydı gibi veriler ile elektronik ortamdaki veriler ve bunlara benzer
bilgi taşıyıcıları HMK’nın 199. Maddesi gereği belge niteliğindedir.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal align=right style='margin-bottom:0in;text-align:right;
line-height:normal;background:white'><b><span lang=TR style='font-size:9.0pt;
font-family:"Times New Roman",serif;color:#524A58;letter-spacing:.75pt'>                                                                                                                      </span></b><span
                    lang=TR style='font-size:16.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Madde 26<br>
Sözleşmenin İhlali ve Feshi</span></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>&nbsp;</span></b></p>

                  <p class=MsoNormal style='line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>26.1.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Kullanıcıların işbu Sözleşme hükümlerine aykırı
davranması sonucunda oluşacak durumlarda, kullanıcılar yonetimfirmasi.com’un ve
3. Kişilerin uğrayacağı her türlü zararı karşılamakla sorumludur. yonetimfirmasi.com
Sözleşme’nin ihlal edildiğini tespit ettiği takdirde işbu Sözleşme’den doğan
talep haklarına halel gelmeksizin işbu Sözleşmeyi derhal tek taraflı olarak
fesih edebilir, sözleşmeyi askıya alabilir, geçici olarak sınırlandırabilir
veya diğer yaptırımları uygulayabilir.</span></p>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><b><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>26.2.&nbsp;&nbsp; </span></b><span lang=TR
                                                         style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Taraflar işbu Sözleşme’yi diledikleri zaman sona
erdirebileceklerdir. Sözleşme’nin feshi anında tarafların birbirlerinden olan
alacak hakları etkilenmez.</span></p>

                  <div class=MsoNormal align=center style='margin-top:24.0pt;margin-right:0in;
margin-bottom:24.0pt;margin-left:0in;text-align:center;line-height:normal;
background:white'><span lang=TR style='font-size:12.0pt;font-family:"Times New Roman",serif;
color:#524A58;letter-spacing:.75pt'>

<hr size=1 width="100%" align=center>

</span></div>

                  <p class=MsoNormal style='margin-bottom:0in;line-height:18.0pt;background:white'><span
                    lang=TR style='font-size:9.0pt;font-family:"Times New Roman",serif;color:#524A58;
letter-spacing:.75pt'>Bu Sözleşme Web Sitesi kullanılmaya devam edildiği ve
Kullanıcılara yonetimfirmasi.com tarafından yeni bir sözleşme sunulmadığı
sürece yürürlükte kalacaktır.</span></p>

                  <p class=MsoNormal><span lang=TR style='font-family:"Times New Roman",serif'>&nbsp;</span></p>

                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
const pageName = 'Mesafeli Satış Sözleşmesi'

export default {
  name: 'mssPage',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },
}
</script>
