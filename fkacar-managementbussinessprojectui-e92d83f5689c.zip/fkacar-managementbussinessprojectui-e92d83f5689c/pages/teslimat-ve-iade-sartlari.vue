<template>
  <div id="refund-page-container">
    <div class="mb-get-offer-step-2-page-container">
      <div class="hero-page-1">
        <div class="container ">
          <div class="row">
            <div class="col-sm-12">
              <strong>Teslimat ve İade Şartları</strong> <br><br>
              <section id="content" class="page-content page-cms page-cms-1"><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">1.Kullanmakta olduğunuz web sitesi üzerinden elektronik ortamda sipariş verdiğiniz takdirde, size sunulan ön bilgilendirme formunu ve mesafeli satış sözleşmesini kabul etmiş sayılırsınız.</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">2.Alıcılar, satın aldıkları ürünün satış ve teslimi ile ilgili olarak 6502 sayılı Tüketicinin Korunması Hakkında Kanun ve Mesafeli Sözleşmeler Yönetmeliği (RG:27.11.2014/29188) hükümleri ile yürürlükteki diğer yasalara tabidir.&nbsp;</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">3.YonetimFirmasi.com'da fiziksel ürün satışı yapılmamaktadır, dolayısı ile herhangi bir sevkiyat masrafı yoktur.</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">4.Satın alınan her bir ürün, 30 günlük yasal süreyi aşmamak kaydı ile&nbsp; alıcının gösterdiği adresteki kişi ve/veya kuruluşa teslim edilir. Bu süre içinde ürün teslim edilmez ise,&nbsp; Alıcılar sözleşmeyi sona erdirebilir.&nbsp;</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">5.Satın alınan ürün, eksiksiz ve siparişte belirtilen niteliklere uygun ve varsa garanti belgesi, kullanım klavuzu gibi belgelerle teslim edilmek zorundadır.&nbsp;</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">6.Satın alınan ürünün satılmasının imkansızlaşması durumunda, satıcı bu durumu öğrendiğinden itibaren 3 gün içinde yazılı olarak alıcıya bu durumu bildirmek zorundadır. 14 gün içinde de toplam bedel Alıcı’ya iade edilmek zorundadır.&nbsp;</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;"></p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">SATIN ALINAN ÜRÜN BEDELİ ÖDENMEZ İSE:&nbsp;</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">7.Alıcı, satın aldığı ürün bedelini ödemez veya banka kayıtlarında iptal ederse, Satıcının ürünü teslim yükümlülüğü sona erer.</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;"></p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">KREDİ KARTININ YETKİSİZ KULLANIMI İLE YAPILAN ALIŞVERİŞLER:&nbsp;</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">8.Ürün teslim edildikten sonra, alıcının ödeme yaptığı kredi kartının yetkisiz kişiler tarafından haksız olarak kullanıldığı tespit edilirse ve satılan ürün bedeli ilgili banka veya finans kuruluşu tarafından Satıcı'ya ödenmez ise, Alıcı, sözleşme konusu ürünü 3 gün içerisinde nakliye gideri SATICI’ya ait olacak şekilde SATICI’ya iade etmek zorundadır.&nbsp;</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;"></p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">ÖNGÖRÜLEMEYEN SEBEPLERLE ÜRÜN SÜRESİNDE TESLİM EDİLEMEZ İSE:&nbsp;</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">9.Satıcı’nın öngöremeyeceği mücbir sebepler oluşursa ve ürün süresinde teslim edilemez ise, durum Alıcı’ya bildirilir. Alıcı, siparişin iptalini, ürünün benzeri ile değiştirilmesini veya engel ortadan kalkana dek teslimatın ertelenmesini talep edebilir. Alıcı siparişi iptal ederse; ödemeyi nakit ile yapmış ise iptalinden itibaren 14 gün içinde kendisine nakden bu ücret ödenir. Alıcı, ödemeyi kredi kartı ile yapmış ise ve iptal ederse, bu iptalden itibaren yine 14 gün içinde ürün bedeli bankaya iade edilir, ancak bankanın alıcının hesabına 2-3 hafta içerisinde aktarması olasıdır.&nbsp;</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;"></p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">ALICININ ÜRÜNÜ KONTROL ETME YÜKÜMLÜLÜĞÜ:&nbsp;</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">10.Alıcı, sözleşme konusu mal/hizmeti teslim almadan önce muayene edecek; ezik, kırık, ambalajı yırtılmış vb. hasarlı ve ayıplı mal/hizmeti kargo şirketinden teslim almayacaktır. Teslim alınan mal/hizmetin hasarsız ve sağlam olduğu kabul edilecektir. ALICI , Teslimden sonra mal/hizmeti özenle korunmak zorundadır. Cayma hakkı kullanılacaksa mal/hizmet kullanılmamalıdır. Ürünle birlikte Fatura da iade edilmelidir.</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;"></p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">CAYMA HAKKI:</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">11.ALICI; satın aldığı ürünün kendisine veya gösterdiği adresteki kişi/kuruluşa teslim tarihinden itibaren 14 (on dört) gün içerisinde, SATICI’ya aşağıdaki iletişim bilgileri üzerinden bildirmek şartıyla hiçbir hukuki ve cezai sorumluluk üstlenmeksizin ve hiçbir gerekçe göstermeksizin malı reddederek sözleşmeden cayma hakkını kullanabilir.</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;"></p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">CAYMA HAKKININ SÜRESİ:</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;"></p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">13.Alıcı, satın aldığı eğer bir hizmet&nbsp; ise, bu 14 günlük süre sözleşmenin imzalandığı tarihten itibaren başlar. Cayma hakkı süresi sona ermeden önce, tüketicinin onayı ile hizmetin ifasına başlanan hizmet sözleşmelerinde cayma hakkı kullanılamaz.&nbsp;</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">14.Cayma hakkının kullanımından kaynaklanan masraflar ALICI’ ya aittir.</p><p style="margin-top:0px;margin-bottom:1rem;font-size:.9375rem;color:#7a7a7a;font-family:'Noto Sans', sans-serif;text-align:justify;">15.Cayma hakkının kullanılması için 14 (ondört) günlük süre içinde SATICI' ya iadeli taahhütlü posta, faks veya eposta ile yazılı bildirimde bulunulması ve ürünün işbu sözleşmede düzenlenen "Cayma Hakkı Kullanılamayacak Ürünler" hükümleri çerçevesinde kullanılmamış olması şarttır.&nbsp;</p></section>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
const pageName = 'Teslimat ve İade Şartları'

export default {
  name: 'refundPage',

  head() {
    return {
      title: this.getTitle
    }
  },

  mounted() {
    window.scrollTo({ top: 0, behavior: "smooth" })
  },

  data() {
    return {
      pageTitle: pageName + ' - ' + this.$store.state.titleSuffix,
    }
  },

  computed: {
    getTitle() {
      return this.pageTitle
    }
  },
}
</script>

<style>
#refund-page-container {
  min-height: 47vh;
}

.hero-page-1 {
  background: none !important;
}
</style>
